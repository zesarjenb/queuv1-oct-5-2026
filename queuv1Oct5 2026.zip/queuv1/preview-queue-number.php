<?php
// staff/preview-queue-number.php - AJAX endpoint for queue number preview
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$clinic_id = isset($_GET['clinic_id']) ? (int)$_GET['clinic_id'] : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';
$time = isset($_GET['time']) ? $_GET['time'] : '';

if (!$clinic_id || !$date || !$time) {
    echo json_encode(['error' => 'Missing parameters']);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

$queue_number = $queueManager->previewAppointmentQueueNumber($clinic_id, $date, $time);

echo json_encode([
    'success' => true,
    'queue_number' => $queue_number,
    'clinic_id' => $clinic_id,
    'date' => $date,
    'time' => $time
]);
?>