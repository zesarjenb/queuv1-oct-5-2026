<?php
// debug-patient-queue.php - Check patient queue status

require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$patient_id = 218; // CHANGE THIS

echo "<h2>🔍 Patient Queue Debug</h2>";

// Check queue entries
$query = "SELECT id, queue_number, clinic_id, status, registered_at 
          FROM queue_entries 
          WHERE patient_id = :patient_id 
          ORDER BY registered_at";
$stmt = $db->prepare($query);
$stmt->bindParam(':patient_id', $patient_id);
$stmt->execute();
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Queue Entries:</h3>";
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Queue #</th><th>Clinic ID</th><th>Status</th><th>Registered At</th></tr>";
foreach ($entries as $entry) {
    echo "<tr>";
    echo "<td>" . $entry['id'] . "</td>";
    echo "<td>" . $entry['queue_number'] . "</td>";
    echo "<td>" . $entry['clinic_id'] . "</td>";
    echo "<td>" . $entry['status'] . "</td>";
    echo "<td>" . $entry['registered_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check journey
$journey = $db->prepare("SELECT * FROM patient_journey WHERE patient_id = :patient_id");
$journey->bindParam(':patient_id', $patient_id);
$journey->execute();
$journey_result = $journey->fetch(PDO::FETCH_ASSOC);

echo "<h3>Journey:</h3>";
echo "<pre>";
print_r($journey_result);
echo "</pre>";
?>