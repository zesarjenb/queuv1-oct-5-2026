<?php
// email-templates/registration-confirmation.php
// Camp Evangelista Station Hospital

function getRegistrationEmailTemplate($patient, $queue_info, $clinic_name = null) {
    $hospital_name = "Camp Evangelista Station Hospital";
    $hospital_address = "Camp Evangelista, Cagayan de Oro City";
    $hospital_phone = "(088) 123-4567";
    
    $patient_name = $patient['first_name'] . ' ' . $patient['last_name'];
    $queue_number = $queue_info['queue_number'] ?? 'N/A';
    $transaction_token = $queue_info['transaction_token'] ?? '';
    $priority_level = $queue_info['priority_level'] ?? 'PR3';
    $registered_date = date('F d, Y');
    $registered_time = date('h:i A');
    
    // Priority label
    $priority_labels = [
        'PR1' => 'Military Personnel (Priority 1)',
        'PR2' => 'Priority Patient (PWD/Senior/Pregnant)',
        'PR3' => 'Regular Patient'
    ];
    $priority_display = $priority_labels[$priority_level] ?? 'Regular Patient';
    
    // Clinic journey display
    $journey_display = '';
    if ($patient['patient_type'] == 'military') {
        $journey_display = 'You will be queued for ALL clinics in order of least congestion.';
    } elseif ($clinic_name) {
        $journey_display = 'You have been queued for: <strong>' . htmlspecialchars($clinic_name) . '</strong>';
    } else {
        $journey_display = 'No clinic assigned yet.';
    }
    
    $tracking_url = "http://" . $_SERVER['HTTP_HOST'] . "/patient-portal/track-queue.php?token=" . urlencode($transaction_token);
    
    return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration Confirmation</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #1a3a5c 0%, #0f172a 100%);
            color: white;
            padding: 30px 25px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .header p {
            margin: 8px 0 0 0;
            opacity: 0.8;
            font-size: 13px;
        }
        .content {
            padding: 30px 25px;
        }
        .content h2 {
            color: #1a3a5c;
            font-size: 18px;
            margin-top: 0;
            border-bottom: 2px solid #e8edf5;
            padding-bottom: 12px;
        }
        .queue-number-box {
            background: #f0f7ff;
            border: 2px dashed #4A90E2;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            margin: 20px 0;
        }
        .queue-number-box .number {
            font-size: 36px;
            font-weight: 800;
            color: #1a3a5c;
            font-family: 'Courier New', monospace;
            letter-spacing: 2px;
        }
        .queue-number-box .label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin: 20px 0;
        }
        .info-item {
            background: #f8fafc;
            padding: 12px 15px;
            border-radius: 8px;
        }
        .info-item .label {
            font-size: 11px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .info-item .value {
            font-size: 15px;
            font-weight: 600;
            color: #1a3a5c;
            margin-top: 4px;
        }
        .token-box {
            background: #fff8e1;
            border: 1px solid #ffd54f;
            border-radius: 8px;
            padding: 12px 15px;
            margin: 15px 0;
        }
        .token-box .token {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            font-weight: 700;
            color: #e65100;
            word-break: break-all;
        }
        .token-box .label {
            font-size: 11px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .journey-box {
            background: #e8f5e9;
            border-left: 4px solid #2e7d32;
            padding: 12px 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        .journey-box .label {
            font-size: 11px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .btn {
            display: inline-block;
            background: #4A90E2;
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            margin: 10px 0;
        }
        .btn:hover {
            background: #3A7BC8;
        }
        .footer {
            background: #f8fafc;
            padding: 20px 25px;
            text-align: center;
            font-size: 12px;
            color: #999;
            border-top: 1px solid #e8edf5;
        }
        .footer a {
            color: #4A90E2;
            text-decoration: none;
        }
        @media (max-width: 480px) {
            .info-grid {
                grid-template-columns: 1fr;
            }
            .queue-number-box .number {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏥 {$hospital_name}</h1>
            <p>{$hospital_address}</p>
        </div>
        
        <div class="content">
            <h2>✅ Registration Confirmed</h2>
            
            <p style="color: #444; font-size: 15px; line-height: 1.6;">
                Dear <strong>{$patient_name}</strong>,
            </p>
            <p style="color: #444; font-size: 14px; line-height: 1.6;">
                Thank you for registering at <strong>{$hospital_name}</strong>. 
                Your outpatient record has been successfully created.
            </p>
            
            <div class="queue-number-box">
                <div class="label">Your Queue Number</div>
                <div class="number">{$queue_number}</div>
                <div style="margin-top: 5px; font-size: 13px; color: #666;">
                    Priority: <strong>{$priority_display}</strong>
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-item">
                    <div class="label">Patient Name</div>
                    <div class="value">{$patient_name}</div>
                </div>
                <div class="info-item">
                    <div class="label">MRN</div>
                    <div class="value">{$patient['mrn']}</div>
                </div>
                <div class="info-item">
                    <div class="label">Date</div>
                    <div class="value">{$registered_date}</div>
                </div>
                <div class="info-item">
                    <div class="label">Time</div>
                    <div class="value">{$registered_time}</div>
                </div>
            </div>
            
            <div class="journey-box">
                <div class="label">📋 Journey Plan</div>
                <div style="margin-top: 5px; font-size: 14px; color: #1a3a5c;">
                    {$journey_display}
                </div>
            </div>
            
            <div class="token-box">
                <div class="label">🔑 Private Tracking Token</div>
                <div class="token">{$transaction_token}</div>
                <div style="font-size: 11px; color: #888; margin-top: 4px;">
                    Keep this token private. Use it to track your queue status.
                </div>
            </div>
            
            <div style="text-align: center; margin: 20px 0;">
                <a href="{$tracking_url}" class="btn" target="_blank">
                    📍 Track Your Queue Status
                </a>
            </div>
            
            <div style="background: #fff3e0; border-left: 4px solid #ff9800; padding: 12px 15px; border-radius: 4px; margin: 15px 0;">
                <p style="margin: 0; font-size: 13px; color: #555;">
                    <strong>📌 Important:</strong> Please wait for your number to be called. 
                    You can check your queue position anytime using the link above.
                </p>
            </div>
        </div>
        
        <div class="footer">
            <p>
                <strong>Camp Evangelista Station Hospital</strong><br>
                {$hospital_address}<br>
                Phone: {$hospital_phone}<br>
                <br>
                This is an automated message. Please do not reply to this email.
            </p>
        </div>
    </div>
</body>
</html>
HTML;
}
?>