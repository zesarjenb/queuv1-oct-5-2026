<?php
date_default_timezone_set('Asia/Manila');

class QueueManager {
    private $conn;
    private $batch_size = 20;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Generate a unique transaction token for tracking
     */
    public function generateTransactionToken() {
        $max_attempts = 3;
        for ($attempt = 1; $attempt <= $max_attempts; $attempt++) {
            $entropy = uniqid('', true) . bin2hex(random_bytes(8)) . microtime(true);
            $hash = hash('sha256', $entropy);
            $sequence = substr($hash, 0, 10);
            $token = 'TXN-' . date('Ymd') . '-' . $sequence;
            $check = $this->conn->prepare("SELECT 1 FROM queue_entries WHERE transaction_token = ? LIMIT 1");
            $check->execute([$token]);
            if (!$check->fetch()) return $token;
        }
        $microtime = round(microtime(true) * 10000);
        return 'TXN-' . date('Ymd') . '-' . $microtime . rand(10, 99);
    }
    
    /**
     * Get ALL active clinics with their current load (congestion)
     * Includes waiting, called, and in-progress patients
     */
    public function getAllClinicsWithLoad() {
        $query = "SELECT 
                    c.id, 
                    c.name, 
                    c.capacity_per_hour,
                    c.clinic_order,
                    COUNT(DISTINCT CASE 
                        WHEN q.status IN ('waiting', 'called', 'in-progress') 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as active_patients,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'waiting' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as waiting_count,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'in-progress' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as in_progress_count,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'called' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as called_count
                  FROM clinics c
                  LEFT JOIN queue_entries q ON c.id = q.clinic_id
                  WHERE c.is_active = 1
                  GROUP BY c.id
                  ORDER BY active_patients ASC, waiting_count ASC, c.clinic_order ASC, c.id ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get the least congested clinic (excluding specified clinics)
     */
    public function getLeastCongestedClinic($exclude_clinic_ids = []) {
        $query = "SELECT 
                    c.id, 
                    c.name, 
                    c.capacity_per_hour,
                    COUNT(DISTINCT CASE 
                        WHEN q.status IN ('waiting', 'called', 'in-progress') 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as active_patients,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'waiting' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as waiting_count
                  FROM clinics c
                  LEFT JOIN queue_entries q ON c.id = q.clinic_id
                  WHERE c.is_active = 1";
        
        if (!empty($exclude_clinic_ids)) {
            $exclude_list = implode(',', array_map('intval', $exclude_clinic_ids));
            $query .= " AND c.id NOT IN ($exclude_list)";
        }
        
        $query .= " GROUP BY c.id 
                    ORDER BY active_patients ASC, waiting_count ASC, c.clinic_order ASC, c.id ASC 
                    LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get ALL clinics sorted by congestion (least congested first)
     * Used for military patients to build their journey
     */
    public function getAllClinicsByCongestion($exclude_clinic_ids = []) {
        $query = "SELECT 
                    c.id, 
                    c.name, 
                    c.capacity_per_hour,
                    c.clinic_order,
                    COUNT(DISTINCT CASE 
                        WHEN q.status IN ('waiting', 'called', 'in-progress') 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as active_patients,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'waiting' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as waiting_count,
                    COUNT(DISTINCT CASE 
                        WHEN q.status = 'in-progress' 
                        AND DATE(q.registered_at) = CURDATE() 
                        THEN q.patient_id 
                    END) as in_progress_count
                  FROM clinics c
                  LEFT JOIN queue_entries q ON c.id = q.clinic_id
                  WHERE c.is_active = 1";
        
        if (!empty($exclude_clinic_ids)) {
            $exclude_list = implode(',', array_map('intval', $exclude_clinic_ids));
            $query .= " AND c.id NOT IN ($exclude_list)";
        }
        
        $query .= " GROUP BY c.id 
                    ORDER BY active_patients ASC, 
                              waiting_count ASC, 
                              c.clinic_order ASC, 
                              c.id ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Store a patient's clinic journey
     */
    public function storePatientJourney($patient_id, $clinics) {
        // Clear any existing journey for today
        $clear = "DELETE FROM patient_journey WHERE patient_id = :patient_id AND DATE(created_at) = CURDATE()";
        $clear_stmt = $this->conn->prepare($clear);
        $clear_stmt->bindParam(':patient_id', $patient_id);
        $clear_stmt->execute();
        
        $journey_clinics = json_encode($clinics);
        $insert = "INSERT INTO patient_journey (patient_id, clinic_sequence, current_index, status, created_at) 
                   VALUES (:patient_id, :clinic_sequence, 0, 'pending', NOW())";
        $insert_stmt = $this->conn->prepare($insert);
        $insert_stmt->bindParam(':patient_id', $patient_id);
        $insert_stmt->bindParam(':clinic_sequence', $journey_clinics);
        $insert_stmt->execute();
    }
    
    /**
     * Get the next clinic from journey
     */
    public function getNextClinicFromJourney($patient_id) {
        $query = "SELECT id, clinic_sequence, current_index FROM patient_journey 
                  WHERE patient_id = :patient_id AND status = 'pending'
                  ORDER BY id DESC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();
        $journey = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$journey) return null;
        
        $clinics = json_decode($journey['clinic_sequence'], true);
        $current_index = $journey['current_index'];
        
        if ($current_index >= count($clinics)) {
            // Mark journey as completed
            $update = "UPDATE patient_journey SET status = 'completed' WHERE id = :journey_id";
            $update_stmt = $this->conn->prepare($update);
            $update_stmt->bindParam(':journey_id', $journey['id']);
            $update_stmt->execute();
            return null;
        }
        
        $next_clinic_id = $clinics[$current_index];
        
        // Advance the journey
        $update = "UPDATE patient_journey SET current_index = current_index + 1 WHERE id = :journey_id";
        $update_stmt = $this->conn->prepare($update);
        $update_stmt->bindParam(':journey_id', $journey['id']);
        $update_stmt->execute();
        
        return $next_clinic_id;
    }
    
    /**
     * Get patient's current journey
     */
public function getPatientJourney($patient_id) {
    // Get any pending journey regardless of date
    $query = "SELECT * FROM patient_journey 
              WHERE patient_id = :patient_id AND status = 'pending' 
              ORDER BY id DESC LIMIT 1";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':patient_id', $patient_id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);

    
    // If no journey today, check for any pending journey (from previous days)
    if (!$journey) {
        $query = "SELECT * FROM patient_journey 
                  WHERE patient_id = :patient_id AND status = 'pending' 
                  ORDER BY id DESC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();
        $journey = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    return $journey;
}
    
    /**
     * Get completed clinics for a patient today
     */
public function getCompletedClinics($patient_id) {
    // Get completed clinics from ANY day (not just today)
    $stmt = $this->conn->prepare("SELECT DISTINCT clinic_id FROM queue_entries 
                                  WHERE patient_id = :patient_id AND status = 'completed'");
    $stmt->bindParam(':patient_id', $patient_id);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
    
    public function getCurrentBatch() {
        $current_hour = date('Y-m-d H:00:00');
        $next_hour = date('Y-m-d H:00:00', strtotime('+1 hour'));
        $query = "SELECT COUNT(DISTINCT patient_id) as count FROM queue_entries WHERE batch_hour = :batch_hour";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':batch_hour', $current_hour);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $current_count = $result ? $result['count'] : 0;
        $remaining_slots = $this->batch_size - $current_count;
        return [
            'current_hour' => $current_hour,
            'next_hour' => $next_hour,
            'current_count' => $current_count,
            'remaining_slots' => $remaining_slots,
            'is_full' => $remaining_slots <= 0,
            'batch_number' => date('H')
        ];
    }
    
    public function generateQueueNumber($priority, $batch_hour) {
        $prefix = '';
        switch($priority) {
            case 'PR1': $prefix = 'M'; break;
            case 'PR2': $prefix = 'P'; break;
            case 'PR3': $prefix = 'R'; break;
        }
        $batch = date('H', strtotime($batch_hour));
        $query = "SELECT COUNT(DISTINCT patient_id) as count FROM queue_entries WHERE batch_hour = :batch_hour";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':batch_hour', $batch_hour);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $sequence = str_pad(($row['count'] ?? 0) + 1, 3, '0', STR_PAD_LEFT);
        return $prefix . '-' . $batch . '-' . $sequence;
    }
    
    public function determinePriority($patient) {
        if ($patient['patient_type'] == 'military') return 'PR1';
        elseif ($patient['is_pwd'] == 1 || $patient['is_senior'] == 1 || $patient['is_pregnant'] == 1) return 'PR2';
        else return 'PR3';
    }
    
    /**
     * Initial queue entry – generates NEW queue number
     * This should ONLY be called ONCE per patient journey
     */
    public function addToQueue($patient_id, $clinic_id, $appointment_time = null, $force_batch_hour = null) {
        $clinic_check = $this->conn->prepare("SELECT id FROM clinics WHERE id = ? AND is_active = 1");
        $clinic_check->execute([$clinic_id]);
        if (!$clinic_check->fetch(PDO::FETCH_ASSOC)) {
            return ['success' => false, 'error' => 'Clinic is currently closed'];
        }

        $query = "SELECT * FROM patients WHERE id = :patient_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$patient) return ['success' => false, 'error' => 'Patient not found'];
        
        $priority = $this->determinePriority($patient);
        if ($force_batch_hour) {
            $batch_hour = $force_batch_hour;
        } else {
            $batch_info = $this->getCurrentBatch();
            $batch_hour = $batch_info['is_full'] ? $batch_info['next_hour'] : $batch_info['current_hour'];
        }
        
        $queue_number = $this->generateQueueNumber($priority, $batch_hour);
        $transaction_token = $this->generateTransactionToken();
        $appointment_type = $appointment_time ? 'appointment' : 'walk-in';
        
        $insert = "INSERT INTO queue_entries 
                  (queue_number, transaction_token, patient_id, priority_level, clinic_id, 
                   appointment_type, appointment_time, batch_hour, registered_at, token_created_at) 
                  VALUES 
                  (:queue_number, :transaction_token, :patient_id, :priority, :clinic_id, 
                   :appointment_type, :appointment_time, :batch_hour, NOW(), NOW())";
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(':queue_number', $queue_number);
        $stmt->bindParam(':transaction_token', $transaction_token);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->bindParam(':priority', $priority);
        $stmt->bindParam(':clinic_id', $clinic_id);
        $stmt->bindParam(':appointment_type', $appointment_type);
        $stmt->bindParam(':appointment_time', $appointment_time);
        $stmt->bindParam(':batch_hour', $batch_hour);
        if ($stmt->execute()) {
            return [
                'success' => true,
                'queue_number' => $queue_number,
                'transaction_token' => $transaction_token,
                'priority' => $priority,
                'batch_hour' => $batch_hour,
                'batch_number' => date('H', strtotime($batch_hour)),
                'queue_entry_id' => $this->conn->lastInsertId()
            ];
        }
        return ['success' => false, 'error' => 'Database error'];
    }
    
    /**
     * Add patient to next clinic - REUSES existing queue number and token
     * PREVENTS duplicates by checking if already queued
     * CRITICAL: Queue number stays the SAME throughout the journey
     */
    public function addToNextClinic($patient_id, $clinic_id) {
        $clinic_check = $this->conn->prepare("SELECT id FROM clinics WHERE id = ? AND is_active = 1");
        $clinic_check->execute([$clinic_id]);
        if (!$clinic_check->fetch(PDO::FETCH_ASSOC)) {
            return ['success' => false, 'error' => 'Clinic is currently closed'];
        }

        // Check if patient already has a waiting/called/in-progress entry for this clinic TODAY
        $check = $this->conn->prepare("SELECT id FROM queue_entries 
                                       WHERE patient_id = ? AND clinic_id = ? 
                                       AND status IN ('waiting', 'called', 'in-progress')
                                       AND DATE(registered_at) = CURDATE()");
        $check->execute([$patient_id, $clinic_id]);
        $existing_today = $check->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_today) {
            // Already queued for today - skip
            return ['success' => false, 'error' => 'Already in queue for today'];
        }
        
        // A waiting entry from a previous day belongs to an old transaction.
        // Do not move it to today or reuse its queue number.
        $old_check = $this->conn->prepare("SELECT id FROM queue_entries 
                                           WHERE patient_id = ? AND clinic_id = ? 
                                           AND status IN ('waiting', 'called', 'in-progress')
                                           AND DATE(registered_at) < CURDATE()");
        $old_check->execute([$patient_id, $clinic_id]);
        $old_entry = $old_check->fetch(PDO::FETCH_ASSOC);

        // A later-day registration starts a new transaction. The old entry is
        // left untouched so its queue number remains part of its old history.
        if ($old_entry) {
            return $this->addToQueue($patient_id, $clinic_id);
        }
        
        // No existing entry - create a new one
        // Get the EXISTING queue number and token from the FIRST entry
        $existing_query = "SELECT queue_number, transaction_token, batch_hour, priority_level 
                           FROM queue_entries 
                   WHERE patient_id = :patient_id
                   AND DATE(registered_at) = CURDATE()
                   ORDER BY registered_at DESC LIMIT 1";
        $existing_stmt = $this->conn->prepare($existing_query);
        $existing_stmt->bindParam(':patient_id', $patient_id);
        $existing_stmt->execute();
        $existing = $existing_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$existing) {
            // There is no transaction for today, so create a new number/token.
            return $this->addToQueue($patient_id, $clinic_id);
        }
        
        // REUSE the same queue number and token
        $insert = "INSERT INTO queue_entries 
                  (queue_number, transaction_token, patient_id, priority_level, clinic_id, 
                   appointment_type, batch_hour, registered_at, status, token_created_at) 
                  VALUES 
                  (:queue_number, :transaction_token, :patient_id, :priority, :clinic_id, 
                   'walk-in', :batch_hour, NOW(), 'waiting', NOW())";
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(':queue_number', $existing['queue_number']);
        $stmt->bindParam(':transaction_token', $existing['transaction_token']);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->bindParam(':priority', $existing['priority_level']);
        $stmt->bindParam(':clinic_id', $clinic_id);
        $stmt->bindParam(':batch_hour', $existing['batch_hour']);
        
        if ($stmt->execute()) {
            return ['success' => true, 'queue_entry_id' => $this->conn->lastInsertId(), 'new' => true];
        }
        return ['success' => false, 'error' => 'Database insert failed'];
    }
    
    /**
     * Queue military patient for next clinic - ALWAYS uses least congested
     * Military must complete ALL clinics, but in order of least congestion
     * QUEUE NUMBER STAYS THE SAME throughout the journey
     */
    /**
 * Queue military patient for next clinic - ALWAYS uses CURRENT least congested
 * Military must complete ALL clinics, but in order of CURRENT congestion
 * QUEUE NUMBER STAYS THE SAME throughout the journey
 */
public function queueMilitaryForNextClinic($patient_id, $current_clinic_id) {
    $journey = $this->getPatientJourney($patient_id);

    // Step 1: Get clinics already completed by this patient on any day.
    $completed_clinics = $this->getCompletedClinics($patient_id);

    // Do not select another clinic where the patient is already active today.
    $active_stmt = $this->conn->prepare("SELECT clinic_id FROM queue_entries
                                         WHERE patient_id = ?
                                         AND DATE(registered_at) = CURDATE()
                                         AND status IN ('waiting', 'called', 'in-progress')");
    $active_stmt->execute([$patient_id]);
    $active_clinics = $active_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Step 2: Get ALL active clinics sorted by CURRENT congestion
    // (NOT using stored journey!)
    $all_clinics = $this->getAllClinicsByCongestion();
    
    // Step 3: Filter out completed and already active clinics.
    $available_clinics = array_filter($all_clinics, function($clinic) use ($completed_clinics, $active_clinics) {
        return !in_array($clinic['id'], $completed_clinics)
            && !in_array($clinic['id'], $active_clinics);
    });
    
    // Step 4: Re-index the array
    $available_clinics = array_values($available_clinics);
    
    // Step 5: Check if there are any clinics left
    if (empty($available_clinics)) {
        $remaining_uncompleted = array_filter($all_clinics, function($clinic) use ($completed_clinics) {
            return !in_array($clinic['id'], $completed_clinics);
        });

        if (empty($remaining_uncompleted) && $journey) {
            $update = $this->conn->prepare("UPDATE patient_journey SET status = 'completed' WHERE id = ?");
            $update->execute([$journey['id']]);
            return ['success' => false, 'error' => 'All clinics completed!', 'all_completed' => true];
        }
        return ['success' => false, 'error' => 'No eligible clinic available'];
    }
    
    // Step 6: Get the LEAST CONGESTED clinic (first one = least congested)
    $next_clinic = $available_clinics[0];
    $next_clinic_id = $next_clinic['id'];
    
    // Step 7: Get clinic name
    $clinic_stmt = $this->conn->prepare("SELECT id, name FROM clinics WHERE id = ? AND is_active = 1");
    $clinic_stmt->execute([$next_clinic_id]);
    $clinic_info = $clinic_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$clinic_info) {
        return ['success' => false, 'error' => 'Clinic not found'];
    }
    
    // Step 8: Queue patient at the current least congested clinic
    // QUEUE NUMBER IS REUSED - stays the same!
    $result = $this->addToNextClinic($patient_id, $next_clinic_id);
    
    if ($result['success']) {
        return [
            'success' => true, 
            'clinic' => $clinic_info['name'], 
            'clinic_id' => $next_clinic_id,
            'remaining_clinics' => count($available_clinics) - 1
        ];
    }
    
    return ['success' => false, 'error' => $result['error'] ?? 'Unknown error'];
}
    
    /**
     * Skip clinics in journey that have already been completed
     */
    private function skipCompletedClinicsInJourney($patient_id, $completed_clinics) {
        $journey = $this->getPatientJourney($patient_id);
        if (!$journey) return;
        
        $clinics = json_decode($journey['clinic_sequence'], true);
        $current_index = $journey['current_index'];
        
        // Find the next clinic that hasn't been completed
        $new_index = $current_index;
        while ($new_index < count($clinics) && in_array($clinics[$new_index], $completed_clinics)) {
            $new_index++;
        }
        
        // Update the journey to skip completed clinics
        $update = "UPDATE patient_journey 
                   SET current_index = :new_index 
                   WHERE id = :journey_id";
        $update_stmt = $this->conn->prepare($update);
        $update_stmt->bindParam(':new_index', $new_index);
        $update_stmt->bindParam(':journey_id', $journey['id']);
        $update_stmt->execute();
    }
    
    /**
     * Queue dependent patient for next clinic - uses their journey or least congested
     */
    public function queueDependentForNextClinic($patient_id, $current_clinic_id) {
        // Check if patient has a journey
        $journey = $this->getPatientJourney($patient_id);
        
        if ($journey) {
            $clinics = json_decode($journey['clinic_sequence'], true);
            $current_index = (int) $journey['current_index'];

            if (!is_array($clinics)) {
                $update = $this->conn->prepare("UPDATE patient_journey SET status = 'completed' WHERE id = ?");
                $update->execute([$journey['id']]);
                return ['success' => false, 'error' => 'No more clinics in journey', 'all_completed' => true];
            }

            while ($current_index < count($clinics)) {
                $next_clinic_id = (int) $clinics[$current_index];
                $clinic_stmt = $this->conn->prepare("SELECT id, name FROM clinics WHERE id = ? AND is_active = 1");
                $clinic_stmt->execute([$next_clinic_id]);
                $next_clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);

                if (!$next_clinic) {
                    $current_index++;
                    continue;
                }

                $result = $this->addToNextClinic($patient_id, $next_clinic_id);
                if ($result['success']) {
                    $update = $this->conn->prepare("UPDATE patient_journey SET current_index = ? WHERE id = ?");
                    $update->execute([$current_index + 1, $journey['id']]);
                    return ['success' => true, 'clinic' => $next_clinic['name'], 'clinic_id' => $next_clinic['id']];
                }
                return ['success' => false, 'error' => $result['error']];
            }

            $update = $this->conn->prepare("UPDATE patient_journey SET status = 'completed', current_index = ? WHERE id = ?");
            $update->execute([$current_index, $journey['id']]);
            return ['success' => false, 'error' => 'No more clinics in journey', 'all_completed' => true];
        }
        
        // ============================================
        // NO JOURNEY - Get the LEAST CONGESTED clinic
        // ============================================
        
        $completed_clinics = $this->getCompletedClinics($patient_id);
        $completed_clinics[] = $current_clinic_id;
        
        $least_congested = $this->getLeastCongestedClinic($completed_clinics);
        
        if ($least_congested) {
            $result = $this->addToNextClinic($patient_id, $least_congested['id']);
            if ($result['success']) {
                return ['success' => true, 'clinic' => $least_congested['name'], 'clinic_id' => $least_congested['id']];
            }
            return ['success' => false, 'error' => $result['error']];
        }
        
        return ['success' => false, 'error' => 'No clinic available', 'all_completed' => true];
    }
    
    /**
     * Find least congested clinic (alias for backward compatibility)
     */
    public function findLeastCongestedClinic($exclude_clinic_ids = []) {
        $result = $this->getLeastCongestedClinic($exclude_clinic_ids);
        if ($result) {
            return [$result];
        }
        return [];
    }
    
    /**
     * Get all clinics queue stats (for display)
     */
    public function getAllClinicsQueueStats() {
        return $this->getAllClinicsWithLoad();
    }
    
    public function getClinicQueue($clinic_id) {
        $query = "SELECT q.*, p.first_name, p.last_name, p.patient_type,
                         p.is_pwd, p.is_senior, p.is_pregnant,
                         TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes,
                         (SELECT COUNT(*) FROM queue_entries 
                          WHERE clinic_id = q.clinic_id AND status IN ('waiting', 'called') 
                          AND registered_at < q.registered_at) + 1 as position_in_clinic
                  FROM queue_entries q
                  JOIN patients p ON q.patient_id = p.id
                  WHERE q.clinic_id = :clinic_id AND q.status IN ('waiting', 'called', 'in-progress')
                  AND DATE(q.registered_at) = CURDATE()
                  ORDER BY FIELD(q.priority_level, 'PR1', 'PR2', 'PR3'), q.registered_at ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':clinic_id', $clinic_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function callNextPatient($clinic_id) {
        $query = "SELECT id FROM queue_entries 
                  WHERE clinic_id = :clinic_id AND status = 'waiting' AND DATE(registered_at) = CURDATE()
                  ORDER BY FIELD(priority_level, 'PR1', 'PR2', 'PR3'), registered_at ASC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':clinic_id', $clinic_id);
        $stmt->execute();
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $update = "UPDATE queue_entries SET status = 'called', called_at = NOW() WHERE id = :id";
            $updateStmt = $this->conn->prepare($update);
            $updateStmt->bindParam(':id', $row['id']);
            $updateStmt->execute();
            return $row['id'];
        }
        return null;
    }
    
    public function callPatient($queue_id) {
        $query = "SELECT * FROM queue_entries WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $queue_id);
        $stmt->execute();
        $entry = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$entry) {
            return ['success' => false, 'error' => 'Queue entry not found'];
        }
        
        $update = "UPDATE queue_entries SET status = 'called', called_at = NOW() WHERE id = :id";
        $updateStmt = $this->conn->prepare($update);
        $updateStmt->bindParam(':id', $queue_id);
        $updateStmt->execute();
        
        return ['success' => true, 'queue_id' => $queue_id, 'queue_number' => $entry['queue_number']];
    }
    
    public function getRecentAnnouncements($since_time = null) {
        if (!$since_time) {
            $since_time = date('Y-m-d H:i:s', strtotime('-5 minutes'));
        }
        
        $query = "SELECT q.queue_number, c.name AS clinic_name, q.called_at
                  FROM queue_entries q
                  JOIN clinics c ON q.clinic_id = c.id
                  WHERE q.status = 'called' AND q.called_at >= :since_time
                  ORDER BY q.called_at DESC
                  LIMIT 10";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':since_time', $since_time);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getQueueByToken($token) {
        $query = "SELECT q.*, p.first_name, p.last_name, p.patient_type, c.name as clinic_name,
                         TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes
                  FROM queue_entries q
                  JOIN patients p ON q.patient_id = p.id
                  JOIN clinics c ON q.clinic_id = c.id
                  WHERE q.transaction_token = :token ORDER BY q.registered_at ASC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getAllQueueByToken($token) {
        $query = "SELECT q.*, p.first_name, p.last_name, p.patient_type, c.name as clinic_name,
                         TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes
                  FROM queue_entries q
                  JOIN patients p ON q.patient_id = p.id
                  JOIN clinics c ON q.clinic_id = c.id
                  WHERE q.transaction_token = :token ORDER BY q.registered_at ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getQueueById($id) {
        $query = "SELECT q.*, p.first_name, p.last_name, p.mrn, c.name as clinic_name
                  FROM queue_entries q
                  JOIN patients p ON q.patient_id = p.id
                  JOIN clinics c ON q.clinic_id = c.id
                  WHERE q.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Debug: Get patient's queue entries for today
     */
    public function getPatientQueueEntries($patient_id) {
        $query = "SELECT q.*, c.name as clinic_name
                  FROM queue_entries q
                  JOIN clinics c ON q.clinic_id = c.id
                  WHERE q.patient_id = :patient_id
                  AND DATE(q.registered_at) = CURDATE()
                  ORDER BY q.registered_at ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>