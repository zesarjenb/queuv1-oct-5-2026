<?php
// includes/Cache.php - Simple caching for database queries

class Cache {
    private static $cache_dir = __DIR__ . '/../cache/';
    
    public static function init() {
        if (!file_exists(self::$cache_dir)) {
            mkdir(self::$cache_dir, 0755, true);
        }
    }
    
    public static function get($key, $ttl = 60) {
        $file = self::$cache_dir . md5($key) . '.cache';
        if (file_exists($file) && (time() - filemtime($file) < $ttl)) {
            return unserialize(file_get_contents($file));
        }
        return null;
    }
    
    public static function set($key, $data) {
        $file = self::$cache_dir . md5($key) . '.cache';
        file_put_contents($file, serialize($data));
    }
    
    public static function clear($key = null) {
        if ($key) {
            $file = self::$cache_dir . md5($key) . '.cache';
            if (file_exists($file)) unlink($file);
        } else {
            array_map('unlink', glob(self::$cache_dir . '*.cache'));
        }
    }
}