<?php
// includes/Compression.php - PHP-based GZIP compression

class Compression {
    
    /**
     * Start output buffering with GZIP compression
     * Call this at the very beginning of your PHP files
     */
    public static function start() {
        // Check if browser accepts gzip encoding
        if (self::isGzipAccepted()) {
            ob_start('ob_gzhandler');
        } else {
            ob_start();
        }
    }
    
    /**
     * Check if browser accepts gzip encoding
     */
    private static function isGzipAccepted() {
        if (isset($_SERVER['HTTP_ACCEPT_ENCODING'])) {
            return strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false;
        }
        return false;
    }
}
?>