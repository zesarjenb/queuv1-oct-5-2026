<?php
// staff/patient-queue.php - All Clinics Queue Overview
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';

session_start();

// ============================================
// AUTHENTICATION & ROLE-BASED ACCESS CONTROL
// ============================================

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Allowed roles for staff pages
$allowed_staff_roles = ['admin', 'doctor', 'nurse', 'technician', 'staff'];

if (!in_array($_SESSION['role'], $allowed_staff_roles)) {
    header('Location: ../unauthorized.php');
    exit();
}

// ============================================
// DATABASE CONNECTION
// ============================================
$database = new Database();
$db = $database->getConnection();

// ============================================
// SESSION TIMEOUT CHECK (After $db exists)
// ============================================
require_once dirname(__DIR__) . '/includes/SessionManager.php';
$sessionManager = new SessionManager($db);
if (!$sessionManager->checkTimeout()) {
    exit(); // Already redirected to login
}
$sessionManager->logActivity('Viewed patient queue page');

// Get all clinics with queue counts
$query = "SELECT 
            c.*,
            COUNT(CASE WHEN q.status IN ('waiting', 'called', 'in-progress') 
                  AND DATE(q.registered_at) = CURDATE() THEN 1 END) as current_patients,
            COUNT(CASE WHEN q.status = 'waiting' 
                  AND DATE(q.registered_at) = CURDATE() THEN 1 END) as waiting_count,
            COUNT(CASE WHEN q.status = 'in-progress' 
                  AND DATE(q.registered_at) = CURDATE() THEN 1 END) as in_progress_count,
            COUNT(CASE WHEN q.status = 'completed' 
                  AND DATE(q.registered_at) = CURDATE() THEN 1 END) as completed_today,
            AVG(CASE WHEN q.completed_at IS NOT NULL AND DATE(q.registered_at) = CURDATE() 
                THEN TIMESTAMPDIFF(MINUTE, q.registered_at, q.completed_at) END) as avg_wait_time
          FROM clinics c
          LEFT JOIN queue_entries q ON c.id = q.clinic_id
          WHERE c.is_active = 1
          GROUP BY c.id
          ORDER BY c.name";

$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_waiting = array_sum(array_column($clinics, 'waiting_count'));
$total_active = array_sum(array_column($clinics, 'in_progress_count'));
$total_completed = array_sum(array_column($clinics, 'completed_today'));
$total_patients = $total_waiting + $total_active + $total_completed;
$avg_wait = round(array_sum(array_column($clinics, 'avg_wait_time')) / max(count($clinics), 1));

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinic Queues | Staff | Camp Evangelista Hospital</title>
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="clinic-dashboard.php?clinic_id=<?php echo $_SESSION['clinic_id'] ?? 1; ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="registration.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient-queue.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-list text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">All Clinics</span>
                        </a>
                    </li>
                    <li>
                        <a href="../patient-portal/track-queue.php" target="_blank" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-search text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Portal</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- Bottom Section - Collapsible "Logged in as" -->
        <div class="p-3 border-t border-slate-300/90 dark:border-slate-700/60">
            <!-- Collapsed State (Icon only) -->
            <div class="flex items-center justify-center md:group-hover/sidebar:hidden py-2">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700">
                    <i class="fas fa-user text-base"></i>
                </div>
            </div>
            
            <!-- Expanded State (Full info) -->
            <div class="hidden md:group-hover/sidebar:flex flex-col px-3 py-3 bg-sky-50 dark:bg-sky-500/10 rounded-xl mb-3 transition-all duration-300">
                <div class="text-[0.55rem] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider">Logged in as</div>
                <div class="text-sm font-bold text-slate-800 dark:text-slate-200 truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></div>
                <div class="text-[0.6rem] font-semibold text-sky-600 dark:text-sky-400">
                    <i class="fas fa-tag"></i> Role: <?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?>
                </div>
            </div>
            
           
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Clinic Queues Overview</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">View and manage all clinic queues from one dashboard</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <!-- Dark Mode Toggle Button -->
                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <!-- Profile Dropdown -->
                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5"><?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?></p>
                        </div>
                        <div class="p-1.5">
                            <a href="profile.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-user-circle text-sm"></i>
                                <span>My Profile</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Logout?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Statistics -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-base mx-auto mb-2">
                    <i class="fas fa-users"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_patients; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Total Today</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-amber-50 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 dark:text-amber-400 text-base mx-auto mb-2">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_waiting; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Waiting</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400 text-base mx-auto mb-2">
                    <i class="fas fa-play-circle"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_active; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">In Progress</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-base mx-auto mb-2">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $total_completed; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.55rem] font-bold uppercase tracking-wider mt-1">Completed</div>
            </div>
        </div>

        <!-- Clinic Cards Grid -->
        <?php if (empty($clinics)): ?>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 text-center rounded-xl p-12 shadow-sm">
                <i class="fas fa-clinic-medical text-5xl mb-4 text-slate-300 dark:text-slate-600"></i>
                <h3 class="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-sm">No active clinics found</h3>
                <p class="text-slate-400 dark:text-slate-500 text-xs mt-1">Please check clinic configuration</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <?php foreach ($clinics as $clinic): 
                    $waiting = $clinic['waiting_count'] ?? 0;
                    $in_progress = $clinic['in_progress_count'] ?? 0;
                    $completed = $clinic['completed_today'] ?? 0;
                    $capacity = $clinic['capacity_per_hour'] ?? 10;
                    $current_load = $waiting + $in_progress;
                    $load_percentage = min(100, ($current_load / max($capacity, 1)) * 100);
                    
                    if ($load_percentage < 30) {
                        $load_class = 'low';
                        $barColor = 'bg-emerald-400 dark:bg-emerald-500';
                        $badgeText = 'Low';
                        $badgeClass = 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
                    } elseif ($load_percentage < 60) {
                        $load_class = 'medium';
                        $barColor = 'bg-amber-400 dark:bg-amber-500';
                        $badgeText = 'Moderate';
                        $badgeClass = 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400';
                    } else {
                        $load_class = 'high';
                        $barColor = 'bg-rose-400 dark:bg-rose-500';
                        $badgeText = 'High';
                        $badgeClass = 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400';
                    }
                    
                    $avg_wait = round($clinic['avg_wait_time'] ?? 0);
                ?>
                    <a href="clinic-dashboard.php?clinic_id=<?php echo $clinic['id']; ?>" class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm hover:shadow-lg hover:border-sky-500/50 transition-all overflow-hidden group block">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                            <span class="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-wider"><?php echo htmlspecialchars($clinic['name']); ?></span>
                            <span class="text-[0.55rem] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span>
                        </div>
                        
                        <div class="p-4">
                            <div class="grid grid-cols-3 gap-2 text-center">
                                <div>
                                    <div class="text-xl font-bold text-slate-900 dark:text-white font-mono <?php echo ($waiting > 10) ? 'text-rose-500' : ($waiting > 5 ? 'text-amber-500' : ''); ?>"><?php echo $waiting; ?></div>
                                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Waiting</div>
                                </div>
                                <div>
                                    <div class="text-xl font-bold text-sky-600 dark:text-sky-400 font-mono"><?php echo $in_progress; ?></div>
                                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">In Progress</div>
                                </div>
                                <div>
                                    <div class="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono"><?php echo $completed; ?></div>
                                    <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Completed</div>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <div class="flex justify-between text-[0.6rem] font-bold text-slate-400 dark:text-slate-400">
                                    <span>Capacity</span>
                                    <span><?php echo round($load_percentage); ?>%</span>
                                </div>
                                <div class="bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-0.5">
                                    <div class="h-full <?php echo $barColor; ?> rounded-full transition-all duration-500" style="width: <?php echo $load_percentage; ?>%"></div>
                                </div>
                            </div>
                            
                            <div class="mt-3 flex justify-between text-xs text-slate-500 dark:text-slate-400">
                                <span><i class="fas fa-hourglass-half mr-1"></i> Est: <?php echo $waiting * 8; ?> min</span>
                                <span><i class="fas fa-chart-line mr-1"></i> Avg: <?php echo $avg_wait; ?> min</span>
                                <span class="text-sky-500 group-hover:translate-x-1 transition-transform"><i class="fas fa-arrow-right"></i></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Summary Card -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-chart-bar text-sky-500 text-sm"></i> Hospital Summary
                </h3>
            </div>
            <div class="p-5">
                <div class="grid grid-cols-3 md:grid-cols-5 gap-4 text-center">
                    <div>
                        <div class="text-2xl font-bold text-slate-900 dark:text-white font-mono"><?php echo $total_patients; ?></div>
                        <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Total</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-amber-500 font-mono"><?php echo $total_waiting; ?></div>
                        <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Waiting</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-sky-500 font-mono"><?php echo $total_active; ?></div>
                        <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">In Progress</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-emerald-500 font-mono"><?php echo $total_completed; ?></div>
                        <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Completed</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-indigo-500 font-mono"><?php echo $avg_wait; ?><span class="text-sm font-medium text-slate-400">m</span></div>
                        <div class="text-[0.55rem] font-bold uppercase text-slate-400 dark:text-slate-400 tracking-wider">Avg Wait</div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <div class="flex justify-between text-[0.6rem] font-bold text-slate-400 dark:text-slate-400">
                        <span>Completion Rate</span>
                        <span><?php echo $total_patients > 0 ? round(($total_completed / $total_patients) * 100) : 0; ?>%</span>
                    </div>
                    <div class="bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden mt-0.5">
                        <div class="bg-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?php echo $total_patients > 0 ? ($total_completed / $total_patients) * 100 : 0; ?>%"></div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            if (themeToggleIcon) {
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
            }
        } else {
            htmlElement.classList.remove('dark');
            if (themeToggleIcon) {
                themeToggleIcon.className = 'fas fa-moon text-base';
            }
        }

        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', function() {
                if (htmlElement.classList.contains('dark')) {
                    htmlElement.classList.remove('dark');
                    if (themeToggleIcon) {
                        themeToggleIcon.className = 'fas fa-moon text-base';
                    }
                    localStorage.setItem('theme', 'light');
                } else {
                    htmlElement.classList.add('dark');
                    if (themeToggleIcon) {
                        themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                    }
                    localStorage.setItem('theme', 'dark');
                }
            });
        }

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function(e) {
                if (!profileDropdown.contains(e.target) && e.target !== profileMenuBtn && !profileMenuBtn.contains(e.target)) {
                    profileDropdown.classList.add('hidden');
                }
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            var dateEl = document.getElementById('currentDate');
            var timeEl = document.getElementById('currentTime');
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-US', options);
            if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto-dismiss alerts
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                alert.style.transition = 'all 0.4s ease-in-out';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() { alert.remove(); }, 400);
            });
        }, 5000);

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700\"><i class=\"fas fa-clock text-5xl text-rose-500 mb-5\"></i><h3 class=\"text-xl font-bold text-slate-900 dark:text-white mb-2\">Session Expired</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-5\">You have been logged out due to inactivity.</p><div class=\"w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden\"><div class=\"bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full\"></div></div></div></div>";
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in\"><i class=\"fas fa-hourglass-half text-5xl text-amber-500 mb-4\"></i><h3 class=\"text-lg font-bold text-slate-900 dark:text-white mb-1\">Session About to Expire</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-3\">You will be logged out due to inactivity.</p><p id=\"countdownText\" class=\"text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4\">2:00</p><button onclick=\"keepSessionAlive()\" class=\"w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm\"><i class=\"fas fa-mouse-pointer mr-1.5\"></i> Keep Session Active</button></div></div>";
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>