<?php
// test-journey.php - Test getPatientJourney

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Testing getPatientJourney</h2>";

require_once 'config/database.php';
require_once 'includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

// ============================================
// CHECK PATIENT JOURNEY
// ============================================
$test_patient_id = 211; // CHANGE THIS TO YOUR TEST PATIENT ID

echo "<p><strong>Testing with patient ID: " . $test_patient_id . "</strong></p>";

// Method 1: Using getPatientJourney()
$journey = $queueManager->getPatientJourney($test_patient_id);

echo "<h3>Method 1: getPatientJourney()</h3>";
if ($journey) {
    echo "✅ Journey found!<br>";
    echo "<pre>";
    print_r($journey);
    echo "</pre>";
} else {
    echo "❌ No journey found<br>";
}

// Method 2: Direct database query
echo "<h3>Method 2: Direct Database Query</h3>";
$direct = $db->prepare("SELECT * FROM patient_journey WHERE patient_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1");
$direct->execute([$test_patient_id]);
$direct_result = $direct->fetch(PDO::FETCH_ASSOC);

if ($direct_result) {
    echo "✅ Direct query found journey:<br>";
    echo "<pre>";
    print_r($direct_result);
    echo "</pre>";
} else {
    echo "❌ Direct query found NO journey<br>";
}

// Method 3: Check all journeys for this patient
echo "<h3>Method 3: All Journeys for Patient</h3>";
$all = $db->prepare("SELECT * FROM patient_journey WHERE patient_id = ? ORDER BY id DESC");
$all->execute([$test_patient_id]);
$all_results = $all->fetchAll(PDO::FETCH_ASSOC);

if ($all_results) {
    echo "✅ Found " . count($all_results) . " journey(s):<br>";
    echo "<pre>";
    print_r($all_results);
    echo "</pre>";
} else {
    echo "❌ No journeys found for this patient<br>";
}

// Method 4: Check queue entries
echo "<h3>Method 4: Queue Entries</h3>";
$queue = $db->prepare("SELECT * FROM queue_entries WHERE patient_id = ? ORDER BY registered_at ASC");
$queue->execute([$test_patient_id]);
$queue_results = $queue->fetchAll(PDO::FETCH_ASSOC);

if ($queue_results) {
    echo "✅ Found " . count($queue_results) . " queue entries:<br>";
    echo "<pre>";
    print_r($queue_results);
    echo "</pre>";
} else {
    echo "❌ No queue entries found<br>";
}
?>