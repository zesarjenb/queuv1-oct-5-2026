<?php
// config/database.php - Database configuration for both systems
// Camp Evangelista Station Hospital

class Database {
    private $host = null;
    private $db_name = null;
    private $username = null;
    private $password = null;
    private $crm_db_name = null;
    public $conn;
    public $crm_conn;

    public function __construct() {
        $this->host = getenv('DB_HOST') ?: '127.0.0.1';
        $this->db_name = getenv('DB_NAME') ?: 'hospital_queue_system';
        $this->username = getenv('DB_USERNAME') ?: 'root';
        $this->password = getenv('DB_PASSWORD') ?: '';
        $this->crm_db_name = getenv('CRM_DB_NAME') ?: 'cesh_crm';
    }
    
    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4", 
                $this->username, 
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
        }
        return $this->conn;
    }
    
    public function getCRMConnection() {
        $this->crm_conn = null;
        try {
            $this->crm_conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->crm_db_name . ";charset=utf8mb4", 
                $this->username, 
                $this->password
            );
            $this->crm_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->crm_conn->exec("set names utf8");
        } catch(PDOException $exception) {
            error_log("CRM Connection error: " . $exception->getMessage());
        }
        return $this->crm_conn;
    }
}
?>