<?php
date_default_timezone_set('Asia/Manila');
// ============================================
// ENABLE GZIP COMPRESSION (Must be first!)
// ============================================
require_once dirname(__DIR__) . '/includes/Compression.php';
Compression::start();

// patient-portal/self-register.php - Patient Self Registration
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

$error_message = '';
$registered_patient = null;
$form_data = [];

function generateUniqueMRN($db) {
    $max_attempts = 5;
    for ($attempt = 1; $attempt <= $max_attempts; $attempt++) {
        $mrn = 'MRN' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $check = $db->prepare("SELECT id FROM patients WHERE mrn = ? LIMIT 1");
        $check->execute([$mrn]);
        if (!$check->fetch()) {
            return $mrn;
        }
    }
    return 'MRN' . date('YmdHis') . rand(10, 99);
}

/**
 * Validate Philippine mobile number
 * Must be 11 digits starting with 09
 */
function validatePhilippineMobile($number) {
    // Remove all non-digit characters
    $clean = preg_replace('/[^0-9]/', '', $number);
    
    // Must be exactly 11 digits
    if (strlen($clean) !== 11) {
        return ['valid' => false, 'message' => 'Phone number must be exactly 11 digits.'];
    }
    
    // Must start with 09
    if (!preg_match('/^09[0-9]{9}$/', $clean)) {
        return ['valid' => false, 'message' => 'Phone number must start with 09 (e.g., 09123456789).'];
    }
    
    return ['valid' => true, 'cleaned' => $clean];
}

/**
 * Validate date of birth - must be at least 1 day old (not today or future)
 */
function validateDateOfBirth($dob) {
    if (empty($dob)) {
        return ['valid' => false, 'message' => 'Date of birth is required.'];
    }
    
    $dob_date = strtotime($dob);
    $today = strtotime(date('Y-m-d'));
    
    // Check if date is in the future (including today)
    if ($dob_date >= $today) {
        return ['valid' => false, 'message' => 'Date of birth cannot be today or in the future.'];
    }
    
    // Check if date is too far in the past (max 120 years)
    $min_date = strtotime('-120 years');
    if ($dob_date < $min_date) {
        return ['valid' => false, 'message' => 'Age cannot exceed 120 years.'];
    }
    
    return ['valid' => true];
}

/**
 * Validate email address
 */
function validateEmail($email) {
    if (empty($email)) return true; // Email is optional
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

$query = "SELECT * FROM clinics WHERE is_active = 1 ORDER BY clinic_order ASC, id ASC";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['self_register'])) {
    // Store form data for repopulation
    $form_data = $_POST;
    
    $required_fields = ['first_name', 'last_name', 'dob', 'gender', 'patient_type'];
    $missing = [];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $missing[] = $field;
        }
    }
    
    if (empty($missing)) {
        // Validate date of birth
        $dob_validation = validateDateOfBirth($_POST['dob']);
        if (!$dob_validation['valid']) {
            $error_message = $dob_validation['message'];
        }
        
        // Validate contact number if provided
        $contact_error = '';
        if (!empty($_POST['contact'])) {
            $phone_validation = validatePhilippineMobile($_POST['contact']);
            if (!$phone_validation['valid']) {
                $contact_error = $phone_validation['message'];
            }
        }
        
        // Validate email if provided
        $email_error = '';
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        if (!empty($email) && !validateEmail($email)) {
            $email_error = "Please enter a valid email address.";
        }
        
        if (empty($error_message) && empty($contact_error) && empty($email_error)) {
            $mrn = generateUniqueMRN($db);
            $first_name = trim($_POST['first_name']);
            $last_name = trim($_POST['last_name']);
            $dob = $_POST['dob'];
            $gender = $_POST['gender'];
            $contact = trim($_POST['contact'] ?? '');
            // Clean contact number if provided
            if (!empty($contact)) {
                $contact = preg_replace('/[^0-9]/', '', $contact);
            }
            $address = trim($_POST['address'] ?? '');
            $patient_type = $_POST['patient_type'];
            $is_pwd = isset($_POST['is_pwd']) ? 1 : 0;
            $is_senior = isset($_POST['is_senior']) ? 1 : 0;
            $is_pregnant = isset($_POST['is_pregnant']) ? 1 : 0;
            
            $query = "INSERT INTO patients 
                      (mrn, first_name, last_name, date_of_birth, gender, 
                       contact_number, email, address, patient_type, is_pwd, is_senior, is_pregnant) 
                      VALUES 
                      (:mrn, :first_name, :last_name, :dob, :gender, 
                       :contact, :email, :address, :patient_type, :is_pwd, :is_senior, :is_pregnant)";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':mrn', $mrn);
            $stmt->bindParam(':first_name', $first_name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':dob', $dob);
            $stmt->bindParam(':gender', $gender);
            $stmt->bindParam(':contact', $contact);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':address', $address);
            $stmt->bindParam(':patient_type', $patient_type);
            $stmt->bindParam(':is_pwd', $is_pwd);
            $stmt->bindParam(':is_senior', $is_senior);
            $stmt->bindParam(':is_pregnant', $is_pregnant);
            
            if ($stmt->execute()) {
                $patient_id = $db->lastInsertId();
                
               if ($patient_type == 'military') {
    // Step 1: Get Registration Clinic (ID: 1)
    $registration_clinic_id = 1;
    $registration_query = "SELECT id, name FROM clinics WHERE id = :id AND is_active = 1";
    $registration_stmt = $db->prepare($registration_query);
    $registration_stmt->bindParam(':id', $registration_clinic_id);
    $registration_stmt->execute();
    $registration_clinic = $registration_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$registration_clinic) {
        $error_message = "Registration clinic not found. Please contact administrator.";
    } else {
        // Step 2: Queue patient at Registration Clinic FIRST
        $batch_info = $queueManager->getCurrentBatch();
        $batch_hour = $batch_info['is_full'] ? $batch_info['next_hour'] : $batch_info['current_hour'];
        $queue_result = $queueManager->addToQueue($patient_id, $registration_clinic_id, null, $batch_hour);
        
        if ($queue_result['success']) {
            // Step 3: Get remaining clinics sorted by congestion (least congested first)
            $all_clinics = $queueManager->getAllClinicsByCongestion();
            
            // Filter out the Registration Clinic from remaining list
            $remaining_clinics = array_filter($all_clinics, function($clinic) use ($registration_clinic_id) {
                return $clinic['id'] != $registration_clinic_id;
            });
            
            // Re-index the array
            $remaining_clinics = array_values($remaining_clinics);
            $remaining_ids = array_column($remaining_clinics, 'id');
            
            // Store the remaining clinics in journey
            if (!empty($remaining_ids)) {
                $queueManager->storePatientJourney($patient_id, $remaining_ids);
            }
            
            $registered_patient = [
                'queue_number' => $queue_result['queue_number'],
                'transaction_token' => $queue_result['transaction_token']
            ];
            
            // ============================================
            // SEND EMAIL NOTIFICATION - MILITARY (SELF REGISTER)
            // ============================================
            if (!empty($email) && $registered_patient['queue_number']) {
                require_once dirname(__DIR__) . '/includes/SimpleEmailSender.php';
                
                $emailSender = new SimpleEmailSender();
                $patient_name = $first_name . ' ' . $last_name;
                $queue_number = $registered_patient['queue_number'];
                $transaction_token = $registered_patient['transaction_token'];
                $clinic_names = array_column($remaining_clinics, 'name');
                $clinic_name = "Registration Clinic → " . implode(" → ", $clinic_names);
                
                $emailSender->sendNotification($email, $patient_name, $queue_number, $transaction_token, $clinic_name);
            }
            
        } else {
            $error_message = "Error adding to queue: " . ($queue_result['error'] ?? 'Unknown error');
        }
    }
}
                
                else {
                    $queue_result = null;
                    $clinic_name = null;
                    
                    if (isset($_POST['clinic_id']) && !empty($_POST['clinic_id'])) {
                        $clinic_id = $_POST['clinic_id'];
                        $appointment_time = !empty($_POST['appointment_time']) ? $_POST['appointment_time'] : null;
                        $queue_result = $queueManager->addToQueue($patient_id, $clinic_id, $appointment_time);
                        
                        // Get clinic name for email
                        $clinic_query = "SELECT name FROM clinics WHERE id = :id";
                        $clinic_stmt = $db->prepare($clinic_query);
                        $clinic_stmt->bindParam(':id', $clinic_id);
                        $clinic_stmt->execute();
                        $clinic_result = $clinic_stmt->fetch(PDO::FETCH_ASSOC);
                        $clinic_name = $clinic_result['name'] ?? null;
                    }
                    
                    if ($queue_result && $queue_result['success']) {
                        $registered_patient = [
                            'queue_number' => $queue_result['queue_number'],
                            'transaction_token' => $queue_result['transaction_token']
                        ];
                        
                        // ============================================
                        // SEND EMAIL NOTIFICATION - DEPENDENT
                        // ============================================
                        if (!empty($email) && $registered_patient['queue_number']) {
                            require_once dirname(__DIR__) . '/includes/SimpleEmailSender.php';
                            
                            $emailSender = new SimpleEmailSender();
                            $patient_name = $first_name . ' ' . $last_name;
                            $queue_number = $registered_patient['queue_number'];
                            $transaction_token = $registered_patient['transaction_token'];
                            
                            $emailSender->sendNotification($email, $patient_name, $queue_number, $transaction_token, $clinic_name);
                        }
                        
                    } else {
                        $registered_patient = [
                            'queue_number' => null,
                            'transaction_token' => null
                        ];
                    }
                }
            } else {
                $error_message = "Registration failed. Please try again.";
            }
        } elseif (!empty($contact_error)) {
            $error_message = $contact_error;
        } elseif (!empty($email_error)) {
            $error_message = $email_error;
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}

if ($registered_patient && $registered_patient['transaction_token']) {
    header('Location: print-ticket.php?token=' . urlencode($registered_patient['transaction_token']));
    exit();
}

$is_dark = isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark';
if (!isset($_COOKIE['theme'])) {
    $is_dark = true;
}

// Get max date for DOB (yesterday)
$max_dob = date('Y-m-d', strtotime('-1 day'));
$min_dob = date('Y-m-d', strtotime('-120 years'));
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $is_dark ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Self Registration | Camp Evangelista Hospital</title>
              <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
  
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        html, body {
            height: 100%;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0A0F1E;
            color: #F3F4F6;
            line-height: 1.5;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        html:not(.dark) body {
            background: #F0F4F8;
            color: #1E293B;
        }

        /* Navigation Bar - Top */
        .nav-bar {
            background: #141B2B;
            border-bottom: 1px solid #2D3748;
            padding: 10px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            transition: all 0.3s ease;
            position: sticky;
            top: 0;
            z-index: 100;
            flex-shrink: 0;
        }

        html:not(.dark) .nav-bar {
            background: #FFFFFF;
            border-bottom: 1px solid #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .nav-left {
            display: flex;
            align-items: center;
        }

        .nav-left a {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .nav-logo {
            height: 36px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .nav-logo:hover {
            transform: scale(1.05);
            filter: brightness(1.1);
        }

        html:not(.dark) .nav-logo {
            filter: brightness(0.9) contrast(1.1);
        }

        html:not(.dark) .nav-logo:hover {
            filter: brightness(1) contrast(1.2);
        }

        html.dark .nav-logo {
            filter: brightness(1.1) contrast(1.1);
        }

        .logo-text-fallback {
            display: none;
            align-items: center;
            gap: 8px;
        }

        .logo-text-fallback i {
            color: #38BDF8;
            font-size: 1.2rem;
        }

        .logo-text-fallback span {
            color: #38BDF8;
            font-weight: 700;
            font-size: 0.9rem;
        }

        html:not(.dark) .logo-text-fallback i {
            color: #2563EB;
        }

        html:not(.dark) .logo-text-fallback span {
            color: #2563EB;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-links a {
            color: #94A3B8;
            text-decoration: none;
            font-size: 0.7rem;
            font-weight: 500;
            transition: color 0.2s;
            padding: 4px 12px;
            border-radius: 20px;
            background: rgba(56, 189, 248, 0.05);
            border: 1px solid transparent;
        }

        html:not(.dark) .nav-links a {
            background: #F1F5F9;
        }

        .nav-links a:hover {
            color: #38BDF8;
            border-color: #38BDF8;
        }

        html:not(.dark) .nav-links a:hover {
            color: #2563EB;
            border-color: #2563EB;
        }

        .nav-links a.active {
            color: #38BDF8;
            border-color: #38BDF8;
            background: rgba(56, 189, 248, 0.1);
        }

        html:not(.dark) .nav-links a.active {
            color: #2563EB;
            border-color: #2563EB;
            background: #EFF6FF;
        }

        .nav-links .divider {
            color: #2D3748;
            font-size: 0.6rem;
        }

        html:not(.dark) .nav-links .divider {
            color: #E2E8F0;
        }

        .theme-toggle {
            background: #1e293b;
            color: #e2e8f0;
            border: 1px solid #334155;
            border-radius: 50%;
            width: 34px;
            height: 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        html:not(.dark) .theme-toggle {
            background: #ffffff;
            color: #1e293b;
            border-color: #e2e8f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .theme-toggle:hover {
            transform: scale(1.05);
        }

        .main-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 24px 20px;
            flex: 1 0 auto;
            width: 100%;
        }

        /* Kiosk Header */
        .kiosk-header {
            background: #2563EB;
            color: white;
            text-align: center;
            padding: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            flex-shrink: 0;
        }

        .kiosk-header i { margin-right: 6px; }

        /* Steps */
        .steps {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-bottom: 28px;
        }

        .step { text-align: center; }
        .step-circle {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: #1E293B;
            border: 2px solid #2D3748;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 8px;
            font-weight: 700;
            font-size: 1.1rem;
            color: #94A3B8;
            transition: all 0.3s ease;
        }

        html:not(.dark) .step-circle {
            background: #FFFFFF;
            border-color: #E2E8F0;
            color: #94A3B8;
        }

        .step.active .step-circle {
            background: #2563EB;
            color: white;
            border-color: #2563EB;
        }

        .step.completed .step-circle {
            background: #0D9488;
            color: white;
            border-color: #0D9488;
        }

        .step-label { 
            font-size: 0.75rem; 
            color: #94A3B8; 
            font-weight: 500;
        }

        html:not(.dark) .step-label {
            color: #64748B;
        }

        /* Alert */
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }

        .alert-danger {
            background: rgba(255, 111, 97, 0.1);
            color: #FF6F61;
            border-left: 3px solid #FF6F61;
        }

        html:not(.dark) .alert-danger {
            background: #FEF2F0;
            color: #FF6F61;
        }

        /* Form Card */
        .form-card {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        html:not(.dark) .form-card {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 16px 24px;
            border-bottom: 1px solid #2D3748;
            background: #1E293B;
        }

        html:not(.dark) .card-header {
            background: #F8FAFC;
            border-color: #E2E8F0;
        }

        .card-header h2 { 
            font-size: 1.1rem; 
            font-weight: 700; 
            color: #F3F4F6;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        html:not(.dark) .card-header h2 {
            color: #0F172A;
        }

        .card-header h2 i {
            color: #38BDF8;
        }

        html:not(.dark) .card-header h2 i {
            color: #2563EB;
        }

        .card-body { padding: 24px; }

        .form-section { margin-bottom: 20px; }
        .form-section-title {
            font-size: 0.7rem;
            font-weight: 700;
            color: #F3F4F6;
            margin-bottom: 14px;
            padding-bottom: 8px;
            border-bottom: 2px solid #2D3748;
            display: flex;
            align-items: center;
            gap: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        html:not(.dark) .form-section-title {
            color: #0F172A;
            border-bottom-color: #E2E8F0;
        }

        .form-section-title i { 
            color: #38BDF8; 
        }

        html:not(.dark) .form-section-title i {
            color: #2563EB;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            margin-bottom: 16px;
        }

        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group.full-width { grid-column: span 2; }

        .form-label {
            font-size: 0.7rem;
            font-weight: 600;
            color: #94A3B8;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        html:not(.dark) .form-label {
            color: #475569;
        }

        .form-label.required:after { content: " *"; color: #FF6F61; }

        .form-control {
            padding: 10px 14px;
            border: 1px solid #2D3748;
            border-radius: 10px;
            font-family: inherit;
            font-size: 0.9rem;
            transition: all 0.2s;
            background: #1E293B;
            color: #F3F4F6;
        }

        html:not(.dark) .form-control {
            background: #FFFFFF;
            color: #1E293B;
            border-color: #E2E8F0;
        }

        .form-control:focus {
            outline: none;
            border-color: #2563EB;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-control.error {
            border-color: #FF6F61;
            box-shadow: 0 0 0 3px rgba(255, 111, 97, 0.1);
        }

        .form-control option {
            background: #1E293B;
            color: #F3F4F6;
        }

        html:not(.dark) .form-control option {
            background: #FFFFFF;
            color: #1E293B;
        }

        /* Validation hint */
        .hint-text {
            font-size: 0.65rem;
            color: #94A3B8;
            margin-top: 4px;
        }

        html:not(.dark) .hint-text {
            color: #64748B;
        }

        .error-text {
            font-size: 0.65rem;
            color: #FF6F61;
            margin-top: 4px;
            display: none;
        }

        .error-text.show {
            display: block;
        }

        /* Special Conditions */
        .checkbox-group {
            background: #1E293B;
            border-radius: 10px;
            padding: 10px 14px;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        html:not(.dark) .checkbox-group {
            background: #F1F5F9;
        }

        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .checkbox-item input {
            width: 18px;
            height: 18px;
            accent-color: #0D9488;
            cursor: pointer;
        }

        .checkbox-item label { 
            font-size: 0.85rem; 
            cursor: pointer;
            color: #F3F4F6;
            font-weight: 500;
        }

        html:not(.dark) .checkbox-item label {
            color: #1E293B;
        }

        /* Military Note */
        .military-note {
            background: rgba(56, 189, 248, 0.08);
            border-left: 3px solid #38BDF8;
            padding: 10px 14px;
            border-radius: 8px;
            margin: 12px 0;
            font-size: 0.8rem;
            display: none;
            color: #94A3B8;
        }

        html:not(.dark) .military-note {
            background: #EFF6FF;
            color: #475569;
            border-left-color: #2563EB;
        }

        /* Priority Preview */
        .priority-preview {
            background: rgba(56, 189, 248, 0.05);
            border: 1px solid #2D3748;
            border-radius: 10px;
            padding: 10px 16px;
            margin: 12px 0;
            display: none;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
        }

        html:not(.dark) .priority-preview {
            background: #F0F9FF;
            border-color: #BAE6FD;
        }

        .priority-preview.show { display: flex; }
        
        .priority-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
        }

        .priority-PR1 { background: #FF6F61; color: white; }
        .priority-PR2 { background: #FFB84D; color: #1E293B; }
        .priority-PR3 { background: #0D9488; color: white; }

        /* Terms */
        .terms-checkbox {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 16px 0;
            padding: 12px 16px;
            background: #1E293B;
            border-radius: 10px;
        }

        html:not(.dark) .terms-checkbox {
            background: #F1F5F9;
        }

        .terms-checkbox input { width: 18px; height: 18px; accent-color: #0D9488; cursor: pointer; }

        .terms-checkbox label { 
            font-size: 0.85rem; 
            cursor: pointer;
            color: #94A3B8;
            font-weight: 500;
        }

        html:not(.dark) .terms-checkbox label {
            color: #475569;
        }

        /* Button */
        .btn-register {
            background: #0D9488;
            color: white;
            border: none;
            padding: 14px 24px;
            border-radius: 40px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            font-size: 1rem;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-register:hover {
            background: #0F766E;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.3);
        }

        .btn-military { background: #FF6F61; }
        .btn-military:hover { background: #e55a4e; box-shadow: 0 4px 12px rgba(255, 111, 97, 0.3); }

        /* Footer */
        .footer {
            background: #141B2B;
            border-top: 1px solid #2D3748;
            padding: 12px 24px;
            transition: all 0.3s ease;
            flex-shrink: 0;
            margin-top: auto;
        }

        html:not(.dark) .footer {
            background: #FFFFFF;
            border-top: 1px solid #E2E8F0;
        }

        .footer-container {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 0.7rem;
        }

        .footer-copyright {
            color: #64748B;
        }

        html:not(.dark) .footer-copyright {
            color: #94A3B8;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
            .form-group.full-width { grid-column: span 1; }
            .steps { gap: 20px; }
            .step-circle { width: 36px; height: 36px; font-size: 0.9rem; }
            .step-label { font-size: 0.65rem; }
            .card-header { padding: 14px 18px; }
            .card-body { padding: 18px; }
            .nav-bar { flex-direction: column; align-items: stretch; gap: 6px; padding: 10px 16px; }
            .nav-links { justify-content: center; flex-wrap: wrap; }
            .nav-left { justify-content: center; }
            .footer-container { flex-direction: column; text-align: center; }
            .main-container { padding: 16px 12px; }
            .checkbox-group { gap: 12px; }
            .nav-logo { height: 28px; }
        }

        @media (max-width: 480px) {
            .card-header h2 { font-size: 0.95rem; }
            .form-control { font-size: 0.8rem; padding: 8px 12px; }
            .checkbox-item label { font-size: 0.75rem; }
            .btn-register { font-size: 0.9rem; padding: 12px 20px; }
            .step-circle { width: 32px; height: 32px; font-size: 0.8rem; }
            .nav-logo { height: 24px; }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar - Top -->
    <nav class="nav-bar">
        <div class="nav-left">
            <a href="index.php">
                <img src="../assets/images/logo.png" alt="CESH Logo" class="nav-logo" 
                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="logo-text-fallback">
                    <i class="fas fa-hospital"></i>
                    <span>CESH</span>
                </div>
            </a>
        </div>
        <div class="nav-links">
            <a href="track-queue.php"><i class="fas fa-search"></i> Track Queue</a>
            <a href="self-register.php" class="active"><i class="fas fa-user-plus"></i> Register</a>
            <span class="divider">|</span>
            <a href="../index.php"><i class="fas fa-lock"></i> Staff Login</a>
            <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
                <i class="fas <?php echo $is_dark ? 'fa-sun' : 'fa-moon'; ?>"></i>
            </button>
        </div>
    </nav>

    <!-- Kiosk Header -->
    <div class="kiosk-header">
        <i class="fas fa-desktop"></i> SELF-REGISTRATION KIOSK
    </div>

    <!-- Main Content -->
    <main class="main-container">
        <!-- Steps -->
        <div class="steps">
            <div class="step active">
                <div class="step-circle">1</div>
                <div class="step-label">Register</div>
            </div>
            <div class="step">
                <div class="step-circle">2</div>
                <div class="step-label">Get Ticket</div>
            </div>
        </div>

        <?php if ($error_message): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <!-- Registration Form -->
        <div class="form-card">
            <div class="card-header">
                <h2><i class="fas fa-notes-medical"></i> Patient Information</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="" id="registrationForm" novalidate>
                    <!-- Personal Information -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="fas fa-user-circle"></i> Personal Information
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label required">First Name</label>
                                <input type="text" name="first_name" class="form-control" required autocomplete="off" value="<?php echo isset($form_data['first_name']) ? htmlspecialchars($form_data['first_name']) : ''; ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label required">Last Name</label>
                                <input type="text" name="last_name" class="form-control" required autocomplete="off" value="<?php echo isset($form_data['last_name']) ? htmlspecialchars($form_data['last_name']) : ''; ?>">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label required">Date of Birth</label>
                                <input type="date" name="dob" id="dob" class="form-control" required 
                                       max="<?php echo $max_dob; ?>" min="<?php echo $min_dob; ?>"
                                       value="<?php echo isset($form_data['dob']) ? htmlspecialchars($form_data['dob']) : ''; ?>">
                                <div class="hint-text">Must be at least 1 day old (not today or future)</div>
                                <div id="dobError" class="error-text">Invalid date of birth</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label required">Gender</label>
                                <select name="gender" class="form-control" required>
                                    <option value="">Select</option>
                                    <option value="Male" <?php echo (isset($form_data['gender']) && $form_data['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo (isset($form_data['gender']) && $form_data['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                    <option value="Other" <?php echo (isset($form_data['gender']) && $form_data['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Contact Number</label>
                                <input type="tel" name="contact" id="contact" class="form-control" 
                                       placeholder="09123456789" autocomplete="off"
                                       value="<?php echo isset($form_data['contact']) ? htmlspecialchars($form_data['contact']) : ''; ?>"
                                       maxlength="11">
                                <div class="hint-text">Must be 11 digits starting with 09 (e.g., 09123456789)</div>
                                <div id="contactError" class="error-text">Invalid phone number format</div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" id="email" class="form-control" 
                                       placeholder="patient@email.com" autocomplete="off"
                                       value="<?php echo isset($form_data['email']) ? htmlspecialchars($form_data['email']) : ''; ?>">
                                <div class="hint-text">Optional - For notifications and communication</div>
                                <div id="emailError" class="error-text">Please enter a valid email address</div>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group full-width">
                                <label class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" placeholder="Complete address" autocomplete="off" value="<?php echo isset($form_data['address']) ? htmlspecialchars($form_data['address']) : ''; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Patient Classification -->
                    <div class="form-section">
                        <div class="form-section-title">
                            <i class="fas fa-tags"></i> Classification
                        </div>



                        <div class="form-row">
    <div class="form-group">
        <label class="form-label required">Patient Type</label>
        <div style="background: #1E293B; padding: 10px 14px; border-radius: 10px; border: 1px solid #2D3748; font-weight: 600; color: #F3F4F6;">
            <i class="fas fa-shield-alt" style="color: #FF6F61;"></i> Military Personnel
        </div>
        <input type="hidden" name="patient_type" value="military">
        <div style="font-size: 0.75rem; color: #94A3B8; margin-top: 6px;">
            <i class="fas fa-info-circle"></i> Military personnel will be queued for ALL clinics.
        </div>
    </div>
</div>
                        
                        
                        
                        <div class="military-note" id="militaryNote">
                            <i class="fas fa-shield-alt"></i> Military personnel will be processed through ALL clinics automatically.
                        </div>
                        
                        <div class="priority-preview" id="priorityPreview">
                            <div>
                                <i class="fas fa-info-circle"></i> 
                                <strong>Priority Level:</strong>
                                <span id="priorityDescription" style="margin-left: 6px; color: #94A3B8; font-size: 0.8rem;">Regular Patient</span>
                            </div>
                            <div>
                                <span id="priorityBadge" class="priority-badge priority-PR3">PR3</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Terms -->
                    <div class="terms-checkbox">
                        <input type="checkbox" id="agreeTerms" required>
                        <label for="agreeTerms">I confirm that the information provided is true and correct.</label>
                    </div>
                    
                    <button type="submit" name="self_register" class="btn-register" id="registerBtn">
                        <i class="fas fa-check-circle"></i> Register & Get Ticket
                    </button>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-copyright">
                <i class="fas fa-shield-alt"></i> <?php echo date('Y'); ?> 4th Infantry Division, Camp Evangelista Station Hospital
            </div>
        </div>
    </footer>

    <script>
        // Theme toggle
        function toggleTheme() {
            var html = document.documentElement;
            var isDark = html.classList.contains('dark');
            if (isDark) {
                html.classList.remove('dark');
                document.cookie = "theme=light; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-moon';
            } else {
                html.classList.add('dark');
                document.cookie = "theme=dark; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-sun';
            }
        }

        // ============================================
        // CLIENT-SIDE VALIDATION
        // ============================================
        
        // Validate Philippine phone number
        function validatePhone(phone) {
            var clean = phone.replace(/[^0-9]/g, '');
            if (clean.length === 0) return { valid: true, cleaned: '' }; // Empty is allowed (optional field)
            if (clean.length !== 11) return { valid: false, message: 'Phone number must be exactly 11 digits.' };
            if (!/^09[0-9]{9}$/.test(clean)) {
                return { valid: false, message: 'Phone number must start with 09 (e.g., 09123456789).' };
            }
            return { valid: true, cleaned: clean };
        }

        // Validate date of birth
        function validateDOB(dob) {
            if (!dob) return { valid: false, message: 'Date of birth is required.' };
            
            var dobDate = new Date(dob);
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            
            // Check if date is today or in the future
            if (dobDate >= today) {
                return { valid: false, message: 'Date of birth cannot be today or in the future.' };
            }
            
            // Check if age exceeds 120 years
            var minDate = new Date();
            minDate.setFullYear(minDate.getFullYear() - 120);
            if (dobDate < minDate) {
                return { valid: false, message: 'Age cannot exceed 120 years.' };
            }
            
            return { valid: true };
        }

        // Validate email
        function validateEmail(email) {
            if (email === '') return { valid: true };
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return { valid: emailRegex.test(email) };
        }

        // Real-time validation for contact number
        document.getElementById('contact')?.addEventListener('input', function() {
            var value = this.value;
            var errorEl = document.getElementById('contactError');
            var hintEl = this.parentElement.querySelector('.hint-text');
            
            if (value.length > 0) {
                var validation = validatePhone(value);
                if (!validation.valid) {
                    this.classList.add('error');
                    if (errorEl) {
                        errorEl.textContent = validation.message;
                        errorEl.classList.add('show');
                    }
                    if (hintEl) hintEl.style.display = 'none';
                } else {
                    this.classList.remove('error');
                    if (errorEl) errorEl.classList.remove('show');
                    if (hintEl) hintEl.style.display = 'block';
                }
            } else {
                this.classList.remove('error');
                if (errorEl) errorEl.classList.remove('show');
                if (hintEl) hintEl.style.display = 'block';
            }
        });

        // Real-time validation for date of birth
        document.getElementById('dob')?.addEventListener('change', function() {
            var value = this.value;
            var errorEl = document.getElementById('dobError');
            
            if (value) {
                var validation = validateDOB(value);
                if (!validation.valid) {
                    this.classList.add('error');
                    if (errorEl) {
                        errorEl.textContent = validation.message;
                        errorEl.classList.add('show');
                    }
                } else {
                    this.classList.remove('error');
                    if (errorEl) errorEl.classList.remove('show');
                }
            }
        });

        // Real-time validation for email
        document.getElementById('email')?.addEventListener('input', function() {
            var value = this.value;
            var errorEl = document.getElementById('emailError');
            var hintEl = this.parentElement.querySelector('.hint-text');
            
            if (value.length > 0) {
                var validation = validateEmail(value);
                if (!validation.valid) {
                    this.classList.add('error');
                    if (errorEl) {
                        errorEl.textContent = 'Please enter a valid email address';
                        errorEl.classList.add('show');
                    }
                    if (hintEl) hintEl.style.display = 'none';
                } else {
                    this.classList.remove('error');
                    if (errorEl) errorEl.classList.remove('show');
                    if (hintEl) hintEl.style.display = 'block';
                }
            } else {
                this.classList.remove('error');
                if (errorEl) errorEl.classList.remove('show');
                if (hintEl) hintEl.style.display = 'block';
            }
        });

        // Form submission validation
        document.getElementById('registrationForm')?.addEventListener('submit', function(e) {
            var isValid = true;
            
            // Validate DOB
            var dob = document.getElementById('dob').value;
            var dobValidation = validateDOB(dob);
            if (!dobValidation.valid) {
                document.getElementById('dob').classList.add('error');
                var dobError = document.getElementById('dobError');
                if (dobError) {
                    dobError.textContent = dobValidation.message;
                    dobError.classList.add('show');
                }
                isValid = false;
            }
            
            // Validate contact
            var contact = document.getElementById('contact').value;
            if (contact.length > 0) {
                var phoneValidation = validatePhone(contact);
                if (!phoneValidation.valid) {
                    document.getElementById('contact').classList.add('error');
                    var contactError = document.getElementById('contactError');
                    if (contactError) {
                        contactError.textContent = phoneValidation.message;
                        contactError.classList.add('show');
                    }
                    isValid = false;
                }
            }
            
            // Validate email
            var email = document.getElementById('email').value;
            if (email.length > 0) {
                var emailValidation = validateEmail(email);
                if (!emailValidation.valid) {
                    document.getElementById('email').classList.add('error');
                    var emailError = document.getElementById('emailError');
                    if (emailError) {
                        emailError.textContent = 'Please enter a valid email address';
                        emailError.classList.add('show');
                    }
                    isValid = false;
                }
            }
            
            // Validate terms
            var terms = document.getElementById('agreeTerms');
            if (!terms.checked) {
                terms.style.outline = '2px solid #FF6F61';
                isValid = false;
                setTimeout(function() {
                    terms.style.outline = 'none';
                }, 3000);
            }
            
            if (!isValid) {
                e.preventDefault();
                // Scroll to first error
                var firstError = document.querySelector('.form-control.error');
                if (firstError) {
                    firstError.focus();
                }
            }
        });

        // Priority Preview
        function updatePriorityPreview() {
            var patientType = document.getElementById('patientType').value;
            var isPwd = document.getElementById('isPwd').checked;
            var isSenior = document.getElementById('isSenior').checked;
            var isPregnant = document.getElementById('isPregnant').checked;
            var militaryNote = document.getElementById('militaryNote');
            var clinicSelection = document.getElementById('clinicSelection');
            var registerBtn = document.getElementById('registerBtn');
            
            var priority = 'PR3';
            var priorityClass = 'priority-PR3';
            var description = 'Regular Patient';
            
            if (patientType === 'military') {
                priority = 'PR1';
                priorityClass = 'priority-PR1';
                description = 'Military Personnel';
                militaryNote.style.display = 'block';
                clinicSelection.style.display = 'none';
                registerBtn.classList.add('btn-military');
            } else {
                militaryNote.style.display = 'none';
                clinicSelection.style.display = 'block';
                registerBtn.classList.remove('btn-military');
                
                if (isPwd || isSenior || isPregnant) {
                    priority = 'PR2';
                    priorityClass = 'priority-PR2';
                    var conditions = [];
                    if (isPwd) conditions.push('PWD');
                    if (isSenior) conditions.push('Senior');
                    if (isPregnant) conditions.push('Pregnant');
                    description = 'Priority (' + conditions.join(', ') + ')';
                }
            }
            
            var preview = document.getElementById('priorityPreview');
            var badge = document.getElementById('priorityBadge');
            var desc = document.getElementById('priorityDescription');
            
            if (patientType || isPwd || isSenior || isPregnant) {
                preview.classList.add('show');
                badge.className = 'priority-badge ' + priorityClass;
                badge.textContent = priority;
                desc.textContent = description;
            } else {
                preview.classList.remove('show');
            }
        }
        
        document.getElementById('patientType')?.addEventListener('change', updatePriorityPreview);
        document.getElementById('isPwd')?.addEventListener('change', updatePriorityPreview);
        document.getElementById('isSenior')?.addEventListener('change', updatePriorityPreview);
        document.getElementById('isPregnant')?.addEventListener('change', updatePriorityPreview);
        
        // Auto-calculate age and auto-check senior
        document.getElementById('dob')?.addEventListener('change', function() {
            var dob = new Date(this.value);
            var today = new Date();
            var age = today.getFullYear() - dob.getFullYear();
            var monthDiff = today.getMonth() - dob.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) age--;
            if (age >= 60 && !document.getElementById('isSenior').checked) {
                document.getElementById('isSenior').checked = true;
                updatePriorityPreview();
            }
        });
        
        // Initial update
        updatePriorityPreview();
    </script>
</body>
</html>