<?php
// patient-portal/track-queue.php - Track Queue Status with Medical Journey Roadmap
// Camp Evangelista Station Hospital

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$queueManager = new QueueManager($db);

$queue_info = null;
$error = '';
$searched = false;
$search_term = '';
$all_clinics = [];
$completed_clinics = [];
$pending_clinics = [];
$current_clinic = null;
$continue_message = '';
$success_message = '';

// ============================================
// HELPER FUNCTIONS
// ============================================

function getAllClinics($db) {
    $query = "SELECT id, name, is_active FROM clinics ORDER BY clinic_order ASC, id ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getClinicsByIds($db, $clinic_ids) {
    $clinic_ids = array_values(array_unique(array_map('intval', $clinic_ids)));
    if (empty($clinic_ids)) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($clinic_ids), '?'));
    $stmt = $db->prepare("SELECT id, name, is_active FROM clinics WHERE id IN ($placeholders)");
    $stmt->execute($clinic_ids);
    $clinics_by_id = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $clinic) {
        $clinics_by_id[(int) $clinic['id']] = $clinic;
    }

    $ordered_clinics = [];
    foreach ($clinic_ids as $clinic_id) {
        if (isset($clinics_by_id[$clinic_id])) {
            $ordered_clinics[] = $clinics_by_id[$clinic_id];
        }
    }
    return $ordered_clinics;
}

function getCompletedClinics($db, $transaction_token) {
    $query = "SELECT DISTINCT q.clinic_id, c.name, q.status, q.completed_at
              FROM queue_entries q
              JOIN clinics c ON q.clinic_id = c.id
              WHERE q.transaction_token = :transaction_token
              AND q.status = 'completed'
              ORDER BY q.completed_at ASC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':transaction_token', $transaction_token);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCurrentClinic($db, $transaction_token) {
    $query = "SELECT q.clinic_id, c.name, q.status
              FROM queue_entries q
              JOIN clinics c ON q.clinic_id = c.id
              WHERE q.transaction_token = :transaction_token
              AND q.status IN ('called', 'in-progress')
              ORDER BY q.registered_at DESC
              LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':transaction_token', $transaction_token);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getPendingClinics($db, $transaction_token, $all_clinic_ids, $completed_ids, $current_clinic_id = null) {
    $pending = [];
    foreach ($all_clinic_ids as $clinic_id) {
        if (in_array($clinic_id, $completed_ids)) {
            continue;
        }
        if ($current_clinic_id && $clinic_id == $current_clinic_id) {
            continue;
        }
        
        $query = "SELECT q.status, q.queue_number,
                         (SELECT COUNT(*) + 1 FROM queue_entries ahead
                          WHERE clinic_id = q.clinic_id 
                          AND ahead.status IN ('waiting', 'called')
                          AND DATE(ahead.registered_at) = DATE(q.registered_at)
                          AND ahead.registered_at < q.registered_at) as position
                  FROM queue_entries q
                      WHERE q.transaction_token = :transaction_token
              AND q.clinic_id = :clinic_id
              AND q.status IN ('waiting', 'called', 'in-progress')
              ORDER BY q.registered_at DESC
              LIMIT 1";
        $stmt = $db->prepare($query);
                $stmt->bindParam(':transaction_token', $transaction_token);
        $stmt->bindParam(':clinic_id', $clinic_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            $pending[] = [
                'clinic_id' => $clinic_id,
                'status' => $result['status'],
                'queue_number' => $result['queue_number'],
                'position' => $result['position'] ?? '?'
            ];
        } else {
            $pending[] = [
                'clinic_id' => $clinic_id,
                'status' => 'pending',
                'queue_number' => null,
                'position' => null
            ];
        }
    }
    return $pending;
}

// ============================================
// SEARCH LOGIC
// ============================================

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $searched = true;
    $search_term = trim($_GET['token']);
    
    $query = "SELECT q.*, p.id as patient_id, p.first_name, p.last_name, p.patient_type, 
                     c.name as clinic_name,
                     TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes
              FROM queue_entries q
              JOIN patients p ON q.patient_id = p.id
              JOIN clinics c ON q.clinic_id = c.id
                WHERE q.transaction_token = :token
                ORDER BY CASE
                          WHEN DATE(q.registered_at) = CURDATE()
                              AND q.status IN ('waiting', 'called', 'in-progress') THEN 0
                          WHEN q.status IN ('waiting', 'called', 'in-progress') THEN 1
                          ELSE 2
                       END,
                       q.registered_at DESC
                LIMIT 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':token', $search_term);
    $stmt->execute();
    
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $queue_info = $row;
        
        // ============================================
        // CHECK FOR INCOMPLETE JOURNEY
        // ============================================
        if ($queue_info && $queue_info['patient_type'] == 'military') {
            $patient_id = $queue_info['patient_id'];
            
            // Check if the patient already has an active clinic entry today.
            $check_query = "SELECT COUNT(*) FROM queue_entries 
                            WHERE patient_id = :patient_id 
                            AND status IN ('waiting', 'called', 'in-progress')
                            AND DATE(registered_at) = CURDATE()";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':patient_id', $patient_id);
            $check_stmt->execute();
            $has_incomplete = $check_stmt->fetchColumn() > 0;
            
            // Check if patient has a pending journey.
            $journey_query = "SELECT * FROM patient_journey 
                              WHERE patient_id = :patient_id 
                              AND DATE(created_at) = DATE(:registered_at)
                              AND status = 'pending'
                              ORDER BY id DESC LIMIT 1";
            $journey_stmt = $db->prepare($journey_query);
            $journey_stmt->bindParam(':patient_id', $patient_id);
            $journey_stmt->bindParam(':registered_at', $queue_info['registered_at']);
            $journey_stmt->execute();
            $journey = $journey_stmt->fetch(PDO::FETCH_ASSOC);
            
        }
        
        // ============================================
        // BUILD JOURNEY DATA (Military)
        // ============================================
        if ($queue_info['patient_type'] == 'military') {
            $all_clinics = getAllClinics($db);
            $completed_clinics = getCompletedClinics($db, $queue_info['transaction_token']);
            $current_clinic = getCurrentClinic($db, $queue_info['transaction_token']);
            
            $completed_ids = array_column($completed_clinics, 'clinic_id');
            $all_clinic_ids = array_column($all_clinics, 'id');
            $current_clinic_id = $current_clinic ? $current_clinic['clinic_id'] : null;
            
            $pending_clinics = getPendingClinics($db, $queue_info['transaction_token'], $all_clinic_ids, $completed_ids, $current_clinic_id);
        }
    } else {
        $error = 'Invalid tracking token. Please check your token and try again.';
    }
}
elseif (isset($_GET['q']) && !empty($_GET['q'])) {
    $searched = true;
    $search_term = trim($_GET['q']);
    
    $query = "SELECT q.*, p.id as patient_id, p.first_name, p.last_name, p.patient_type, 
                     c.name as clinic_name,
                     TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes
              FROM queue_entries q
              JOIN patients p ON q.patient_id = p.id
              JOIN clinics c ON q.clinic_id = c.id
              WHERE q.queue_number = :queue_number";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':queue_number', $search_term);
    $stmt->execute();
    
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $queue_info = $row;
        
        if ($queue_info['patient_type'] == 'military') {
            $all_clinics = getAllClinics($db);
            $completed_clinics = getCompletedClinics($db, $queue_info['transaction_token']);
            $current_clinic = getCurrentClinic($db, $queue_info['transaction_token']);
            
            $completed_ids = array_column($completed_clinics, 'clinic_id');
            $all_clinic_ids = array_column($all_clinics, 'id');
            $current_clinic_id = $current_clinic ? $current_clinic['clinic_id'] : null;
            
            $pending_clinics = getPendingClinics($db, $queue_info['transaction_token'], $all_clinic_ids, $completed_ids, $current_clinic_id);
        }
    } else {
        $error = 'Queue number not found. Please check and try again.';
    }
}
elseif (isset($_POST['track'])) {
    $searched = true;
    $search_term = trim($_POST['search_term']);
    
    $query = "SELECT q.*, p.id as patient_id, p.first_name, p.last_name, p.patient_type, 
                     c.name as clinic_name,
                     TIMESTAMPDIFF(MINUTE, q.registered_at, NOW()) as waiting_minutes
              FROM queue_entries q
              JOIN patients p ON q.patient_id = p.id
              JOIN clinics c ON q.clinic_id = c.id
                WHERE q.queue_number = :search_term OR q.transaction_token = :search_term
                ORDER BY CASE
                          WHEN DATE(q.registered_at) = CURDATE()
                              AND q.status IN ('waiting', 'called', 'in-progress') THEN 0
                          WHEN q.status IN ('waiting', 'called', 'in-progress') THEN 1
                          ELSE 2
                       END,
                       q.registered_at DESC
                LIMIT 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':search_term', $search_term);
    $stmt->execute();
    
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $queue_info = $row;
        
        if ($queue_info['patient_type'] == 'military') {
            $all_clinics = getAllClinics($db);
            $completed_clinics = getCompletedClinics($db, $queue_info['transaction_token']);
            $current_clinic = getCurrentClinic($db, $queue_info['transaction_token']);
            
            $completed_ids = array_column($completed_clinics, 'clinic_id');
            $all_clinic_ids = array_column($all_clinics, 'id');
            $current_clinic_id = $current_clinic ? $current_clinic['clinic_id'] : null;
            
            $pending_clinics = getPendingClinics($db, $queue_info['transaction_token'], $all_clinic_ids, $completed_ids, $current_clinic_id);
        }
    } else {
        $error = 'No record found. Please check your queue number or token and try again.';
    }
}

// Load the saved selected-clinic journey for dependent patients.
if ($queue_info && $queue_info['patient_type'] !== 'military') {
    $journey_query = "SELECT * FROM patient_journey
                      WHERE patient_id = :patient_id
                      AND DATE(created_at) = DATE(:registered_at)
                      ORDER BY id DESC LIMIT 1";
    $journey_stmt = $db->prepare($journey_query);
    $journey_stmt->bindParam(':patient_id', $queue_info['patient_id']);
    $journey_stmt->bindParam(':registered_at', $queue_info['registered_at']);
    $journey_stmt->execute();
    $journey = $journey_stmt->fetch(PDO::FETCH_ASSOC);

    if ($journey) {
        $journey_clinics = json_decode($journey['clinic_sequence'], true);
        $all_clinics = is_array($journey_clinics) ? getClinicsByIds($db, $journey_clinics) : [];
        $completed_clinics = getCompletedClinics($db, $queue_info['transaction_token']);
        $current_clinic = getCurrentClinic($db, $queue_info['transaction_token']);

        $completed_ids = array_column($completed_clinics, 'clinic_id');
        $all_clinic_ids = array_column($all_clinics, 'id');
        $current_clinic_id = $current_clinic ? $current_clinic['clinic_id'] : null;
        $pending_clinics = getPendingClinics($db, $queue_info['transaction_token'], $all_clinic_ids, $completed_ids, $current_clinic_id);
    }
}

// Get clinic wait times (always show)
$query = "SELECT c.id, c.name, c.is_active, c.capacity_per_hour,
                 COUNT(CASE WHEN q.status = 'waiting' THEN 1 END) as waiting_count,
                 COUNT(CASE WHEN q.status = 'in-progress' THEN 1 END) as in_progress_count,
                 COUNT(CASE WHEN q.status = 'completed' AND DATE(q.registered_at) = CURDATE() THEN 1 END) as completed_today
          FROM clinics c
          LEFT JOIN queue_entries q ON c.id = q.clinic_id AND DATE(q.registered_at) = CURDATE()
          GROUP BY c.id
          ORDER BY c.name";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
$active_clinic_count = count(array_filter($clinics, function ($clinic) {
    return (int) $clinic['is_active'] === 1;
}));

$journey_progress = 0;
if ($queue_info && !empty($all_clinics)) {
    $total_clinics = count($all_clinics);
    $journey_clinic_ids = array_column($all_clinics, 'id');
    $completed_count = count(array_intersect($journey_clinic_ids, $completed_ids ?? []));
    $journey_progress = ($completed_count / $total_clinics) * 100;
}

$is_dark = isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark';
if (!isset($_COOKIE['theme'])) {
    $is_dark = true;
}
?>

<!DOCTYPE html>
<html lang="en" class="<?php echo $is_dark ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Track Queue | Patient Portal | Camp Evangelista Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
              <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
  
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0A0F1E;
            color: #F3F4F6;
            line-height: 1.5;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        html:not(.dark) body {
            background: #F0F4F8;
            color: #1E293B;
        }
        .nav-bar {
            background: #141B2B;
            border-bottom: 1px solid #2D3748;
            padding: 10px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            transition: all 0.3s ease;
            position: sticky;
            top: 0;
            z-index: 100;
            flex-shrink: 0;
        }
        html:not(.dark) .nav-bar {
            background: #FFFFFF;
            border-bottom: 1px solid #E2E8F0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .nav-left { display: flex; align-items: center; }
        .nav-left a { display: flex; align-items: center; gap: 10px; text-decoration: none; }
        .nav-logo {
            height: 36px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        .nav-logo:hover { transform: scale(1.05); filter: brightness(1.1); }
        html:not(.dark) .nav-logo { filter: brightness(0.9) contrast(1.1); }
        html:not(.dark) .nav-logo:hover { filter: brightness(1) contrast(1.2); }
        html.dark .nav-logo { filter: brightness(1.1) contrast(1.1); }
        .logo-text-fallback { display: none; align-items: center; gap: 8px; }
        .logo-text-fallback i { color: #38BDF8; font-size: 1.2rem; }
        .logo-text-fallback span { color: #38BDF8; font-weight: 700; font-size: 0.9rem; }
        html:not(.dark) .logo-text-fallback i { color: #2563EB; }
        html:not(.dark) .logo-text-fallback span { color: #2563EB; }
        .nav-links { display: flex; align-items: center; gap: 12px; }
        .nav-links a {
            color: #94A3B8;
            text-decoration: none;
            font-size: 0.7rem;
            font-weight: 500;
            transition: color 0.2s;
            padding: 4px 12px;
            border-radius: 20px;
            background: rgba(56, 189, 248, 0.05);
            border: 1px solid transparent;
        }
        html:not(.dark) .nav-links a { background: #F1F5F9; }
        .nav-links a:hover { color: #38BDF8; border-color: #38BDF8; }
        html:not(.dark) .nav-links a:hover { color: #2563EB; border-color: #2563EB; }
        .nav-links a.active { color: #38BDF8; border-color: #38BDF8; background: rgba(56, 189, 248, 0.1); }
        html:not(.dark) .nav-links a.active { color: #2563EB; border-color: #2563EB; background: #EFF6FF; }
        .nav-links .divider { color: #2D3748; font-size: 0.6rem; }
        html:not(.dark) .nav-links .divider { color: #E2E8F0; }
        .theme-toggle {
            background: #1e293b;
            color: #e2e8f0;
            border: 1px solid #334155;
            border-radius: 50%;
            width: 34px;
            height: 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }
        html:not(.dark) .theme-toggle {
            background: #ffffff;
            color: #1e293b;
            border-color: #e2e8f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .theme-toggle:hover { transform: scale(1.05); }
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 24px;
            flex: 1 0 auto;
            width: 100%;
        }
        .search-section {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            padding: 20px 24px;
            margin-bottom: 24px;
            transition: all 0.3s ease;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 16px;
        }
        html:not(.dark) .search-section {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }
        .search-section .search-icon { color: #38BDF8; font-size: 1.1rem; }
        html:not(.dark) .search-section .search-icon { color: #2563EB; }
        .search-section .search-title { font-weight: 600; font-size: 0.95rem; color: #F3F4F6; margin-right: 4px; }
        html:not(.dark) .search-section .search-title { color: #0F172A; }
        .search-section .search-subtitle { font-size: 0.75rem; color: #94A3B8; }
        html:not(.dark) .search-section .search-subtitle { color: #64748B; }
        .search-form-wrapper { flex: 1; display: flex; gap: 10px; min-width: 280px; }
        .search-input-wrapper { flex: 1; position: relative; }
        .search-input-wrapper i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #38BDF8;
        }
        html:not(.dark) .search-input-wrapper i { color: #2563EB; }
        .search-input {
            width: 100%;
            padding: 10px 14px 10px 40px;
            border: 1px solid #2D3748;
            border-radius: 12px;
            font-family: inherit;
            font-size: 0.85rem;
            transition: all 0.2s;
            background: #1E293B;
            color: #F3F4F6;
        }
        html:not(.dark) .search-input {
            background: #FFFFFF;
            color: #1E293B;
            border-color: #E2E8F0;
        }
        .search-input:focus {
            outline: none;
            border-color: #2563EB;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        .btn-search {
            background: #0D9488;
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 0.85rem;
            white-space: nowrap;
        }
        .btn-search:hover { background: #0F766E; transform: translateY(-1px); }
        .continue-modal[hidden] { display: none; }
        .continue-modal {
            position: fixed;
            inset: 0;
            z-index: 200;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .continue-modal-backdrop {
            position: absolute;
            inset: 0;
            background: rgba(2, 6, 23, 0.72);
        }
        .continue-modal-content {
            position: relative;
            width: min(100%, 440px);
            padding: 28px;
            border: 1px solid #334155;
            border-radius: 16px;
            background: #141B2B;
            color: #F3F4F6;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35);
        }
        html:not(.dark) .continue-modal-content { background: #FFFFFF; color: #0F172A; border-color: #E2E8F0; }
        .continue-modal-close {
            position: absolute;
            top: 8px;
            right: 12px;
            border: 0;
            background: transparent;
            color: #94A3B8;
            font-size: 1.5rem;
            cursor: pointer;
        }
        .continue-modal-icon { color: #38BDF8; font-size: 2rem; margin-bottom: 12px; }
        .continue-modal-content h3 { font-size: 1.05rem; margin-bottom: 8px; }
        .continue-modal-content p { color: #94A3B8; font-size: 0.78rem; margin-bottom: 22px; }
        .continue-modal-actions { display: flex; justify-content: center; align-items: center; gap: 10px; }
        .continue-modal-cancel {
            padding: 10px 20px;
            border: 1px solid #475569;
            border-radius: 12px;
            background: transparent;
            color: #CBD5E1;
            cursor: pointer;
            font: inherit;
            font-size: 0.85rem;
        }
        html:not(.dark) .continue-modal-cancel { color: #334155; border-color: #CBD5E1; }
        .alert {
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.8rem;
        }
        .alert-danger {
            background: rgba(255, 111, 97, 0.1);
            color: #FF6F61;
            border-left: 3px solid #FF6F61;
        }
        html:not(.dark) .alert-danger { background: #FEF2F0; color: #FF6F61; }
        .alert-info {
            background: rgba(56, 189, 248, 0.08);
            color: #38BDF8;
            border-left: 3px solid #38BDF8;
        }
        html:not(.dark) .alert-info { background: #EFF6FF; color: #2563EB; }
        .clinics-section {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 24px;
        }
        html:not(.dark) .clinics-section {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }
        .clinics-header {
            padding: 14px 20px;
            border-bottom: 1px solid #2D3748;
            background: #1E293B;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }
        html:not(.dark) .clinics-header {
            background: #F8FAFC;
            border-bottom-color: #E2E8F0;
        }
        .clinics-header h3 {
            color: #F3F4F6;
            font-size: 0.95rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        html:not(.dark) .clinics-header h3 { color: #0F172A; }
        .clinics-header h3 i { color: #38BDF8; }
        html:not(.dark) .clinics-header h3 i { color: #2563EB; }
        .clinics-header .badge-count {
            background: rgba(56, 189, 248, 0.1);
            color: #38BDF8;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        html:not(.dark) .clinics-header .badge-count { background: #EFF6FF; color: #2563EB; }
        .clinics-grid {
            padding: 16px 20px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 10px;
            max-height: 350px;
            overflow-y: auto;
        }
        .clinic-card {
            background: #1E293B;
            border-radius: 10px;
            padding: 12px 16px;
            transition: all 0.2s;
            border: 1px solid transparent;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }
        html:not(.dark) .clinic-card { background: #F1F5F9; }
        .clinic-card:hover { border-color: #38BDF8; }
        .clinic-card.closed { opacity: 0.72; border-color: #475569; }
        .clinic-card.closed:hover { border-color: #64748B; }
        html:not(.dark) .clinic-card:hover { border-color: #2563EB; }
        .clinic-card .clinic-info { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
        .clinic-card .clinic-name { font-weight: 700; color: #F3F4F6; font-size: 0.85rem; }
        html:not(.dark) .clinic-card .clinic-name { color: #0F172A; }
        .clinic-card .clinic-stats { font-size: 0.65rem; color: #94A3B8; display: flex; gap: 12px; flex-wrap: wrap; }
        html:not(.dark) .clinic-card .clinic-stats { color: #64748B; }
        .clinic-card .clinic-stats span { display: flex; align-items: center; gap: 4px; }
        .clinic-card .clinic-stats i { font-size: 0.6rem; color: #38BDF8; }
        html:not(.dark) .clinic-card .clinic-stats i { color: #2563EB; }
        .clinic-card .wait-badge {
            background: rgba(56, 189, 248, 0.1);
            color: #38BDF8;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            white-space: nowrap;
            flex-shrink: 0;
        }
        html:not(.dark) .clinic-card .wait-badge { background: #EFF6FF; color: #2563EB; }
        .clinic-card .wait-badge.high { background: rgba(255, 111, 97, 0.15); color: #FF6F61; }
        .clinic-card .wait-badge.medium { background: rgba(255, 184, 77, 0.15); color: #FFB84D; }
        .clinic-card .wait-badge.low { background: rgba(13, 148, 136, 0.15); color: #0D9488; }
        .clinic-card .closed-badge { background: rgba(148, 163, 184, 0.16); color: #CBD5E1; padding: 4px 12px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; white-space: nowrap; }
        html:not(.dark) .clinic-card .closed-badge { background: #E2E8F0; color: #475569; }
        .patient-details-card {
            background: linear-gradient(135deg, #141B2B 0%, #1a2744 100%);
            border: 2px solid #38BDF8;
            border-radius: 16px;
            padding: 24px 32px;
            margin-bottom: 24px;
            transition: all 0.3s ease;
            animation: slideDown 0.4s ease;
            box-shadow: 0 0 30px rgba(56, 189, 248, 0.08);
            position: relative;
            overflow: hidden;
        }
        .patient-details-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #38BDF8, #0D9488, #38BDF8);
            background-size: 200% 100%;
            animation: shimmer 3s ease-in-out infinite;
        }
        @keyframes shimmer { 0%, 100% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        html:not(.dark) .patient-details-card {
            background: linear-gradient(135deg, #FFFFFF 0%, #F0F9FF 100%);
            border-color: #2563EB;
            box-shadow: 0 4px 24px rgba(37, 99, 235, 0.12);
        }
        .patient-details-card .card-badge {
            position: absolute;
            top: 12px;
            right: 16px;
            background: rgba(56, 189, 248, 0.15);
            border: 1px solid rgba(56, 189, 248, 0.2);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 600;
            color: #38BDF8;
            letter-spacing: 0.5px;
        }
        html:not(.dark) .patient-details-card .card-badge { background: #EFF6FF; border-color: #BFDBFE; color: #2563EB; }
        .patient-details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px 32px;
            margin-top: 8px;
        }
        .patient-detail-item {
            display: flex;
            flex-direction: column;
            gap: 4px;
            padding: 8px 12px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.04);
            transition: all 0.2s;
        }
        html:not(.dark) .patient-detail-item { background: rgba(37, 99, 235, 0.03); border-color: rgba(37, 99, 235, 0.06); }
        .patient-detail-item:hover { background: rgba(56, 189, 248, 0.05); border-color: rgba(56, 189, 248, 0.1); }
        html:not(.dark) .patient-detail-item:hover { background: rgba(37, 99, 235, 0.05); border-color: rgba(37, 99, 235, 0.1); }
        .patient-detail-item .label {
            font-size: 0.55rem;
            text-transform: uppercase;
            color: #94A3B8;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        html:not(.dark) .patient-detail-item .label { color: #64748B; }
        .patient-detail-item .value { font-size: 1rem; font-weight: 700; color: #F3F4F6; }
        html:not(.dark) .patient-detail-item .value { color: #0F172A; }
        .patient-detail-item .value .highlight { color: #38BDF8; font-size: 1.1rem; }
        html:not(.dark) .patient-detail-item .value .highlight { color: #2563EB; }
        .patient-detail-item .status-pill {
            display: inline-block;
            padding: 4px 16px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            width: fit-content;
        }
        .patient-detail-item .status-pill.waiting { background: #FFB84D; color: #1E293B; }
        .patient-detail-item .status-pill.called { background: rgba(56, 189, 248, 0.2); color: #38BDF8; }
        html:not(.dark) .patient-detail-item .status-pill.called { background: #EFF6FF; color: #2563EB; }
        .patient-detail-item .status-pill.in-progress { background: #2563EB; color: white; }
        .patient-detail-item .status-pill.completed { background: #0D9488; color: white; }
        .patient-detail-item .priority-badge {
            display: inline-block;
            padding: 2px 12px;
            border-radius: 12px;
            font-size: 0.65rem;
            font-weight: 700;
            width: fit-content;
        }
        .patient-detail-item .priority-badge.PR1 { background: #FF6F61; color: white; }
        .patient-detail-item .priority-badge.PR2 { background: #FFB84D; color: #1E293B; }
        .patient-detail-item .priority-badge.PR3 { background: #0D9488; color: white; }
        .patient-detail-item .waiting-time {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255, 184, 77, 0.1);
            padding: 4px 12px;
            border-radius: 12px;
            border: 1px solid rgba(255, 184, 77, 0.15);
        }
        html:not(.dark) .patient-detail-item .waiting-time { background: #FFFBEB; border-color: #FDE68A; }
        .patient-detail-item .waiting-time .time-number { font-weight: 700; color: #FFB84D; font-size: 1.1rem; }
        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 0;
            align-items: stretch;
        }
        .left-column { display: flex; flex-direction: column; }
        .right-column { display: flex; flex-direction: column; }
        .journey-card {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        html:not(.dark) .journey-card {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }
        .journey-header {
            padding: 14px 20px;
            background: linear-gradient(135deg, #0D9488 0%, #0F766E 100%);
            color: white;
            flex-shrink: 0;
        }
        .journey-header h3 { font-size: 1rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .journey-header p { font-size: 0.7rem; opacity: 0.9; margin-top: 4px; }
        .journey-progress-bar {
            padding: 14px 20px;
            background: #1E293B;
            border-bottom: 1px solid #2D3748;
            flex-shrink: 0;
        }
        html:not(.dark) .journey-progress-bar { background: #F8FAFC; border-bottom-color: #E2E8F0; }
        .journey-stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.7rem;
            color: #94A3B8;
        }
        html:not(.dark) .journey-stats { color: #64748B; }
        .journey-progress-bg { background: #2D3748; height: 8px; border-radius: 4px; overflow: hidden; }
        html:not(.dark) .journey-progress-bg { background: #E2E8F0; }
        .journey-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #0D9488, #38BDF8);
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        .timeline { padding: 14px 20px; flex: 1; overflow-y: auto; max-height: 350px; }
        .timeline-item { display: flex; margin-bottom: 12px; position: relative; }
        .timeline-item:last-child { margin-bottom: 0; }
        .timeline-marker { flex-shrink: 0; width: 36px; position: relative; }
        .timeline-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            background: #1E293B;
            color: #94A3B8;
            border: 2px solid #2D3748;
            transition: all 0.3s;
        }
        html:not(.dark) .timeline-icon { background: #F1F5F9; color: #94A3B8; border-color: #E2E8F0; }
        .timeline-icon.completed { background: #0D9488; border-color: #0D9488; color: white; }
        .timeline-icon.in-progress { background: #2563EB; border-color: #2563EB; color: white; animation: pulse 1.5s infinite; }
        .timeline-icon.pending { background: #1E293B; border-color: #2D3748; color: #64748B; }
        html:not(.dark) .timeline-icon.pending { background: #F1F5F9; border-color: #E2E8F0; color: #94A3B8; }
        .timeline-icon.waiting { background: #FFB84D; border-color: #FFB84D; color: #1E293B; }
        @keyframes pulse { 0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(37, 99, 235, 0.4); } 50% { transform: scale(1.05); box-shadow: 0 0 0 8px rgba(37, 99, 235, 0); } }
        .timeline-line {
            position: absolute;
            left: 14px;
            top: 28px;
            width: 2px;
            height: calc(100% - 28px);
            background: #2D3748;
        }
        html:not(.dark) .timeline-line { background: #E2E8F0; }
        .timeline-item:last-child .timeline-line { display: none; }
        .timeline-content { flex: 1; padding-left: 10px; padding-bottom: 2px; }
        .timeline-clinic-name {
            font-weight: 700;
            color: #F3F4F6;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        html:not(.dark) .timeline-clinic-name { color: #0F172A; }
        .timeline-status { font-size: 0.55rem; padding: 1px 8px; border-radius: 12px; font-weight: 600; }
        .status-completed-badge { background: #0D9488; color: white; }
        .status-inprogress-badge { background: #2563EB; color: white; }
        .status-waiting-badge { background: #FFB84D; color: #1E293B; }
        .status-pending-badge { background: #1E293B; color: #94A3B8; }
        html:not(.dark) .status-pending-badge { background: #F1F5F9; color: #64748B; }
        .timeline-details { font-size: 0.6rem; color: #94A3B8; margin-top: 2px; }
        html:not(.dark) .timeline-details { color: #64748B; }
        .timeline-details i { margin-right: 3px; color: #38BDF8; }
        .completion-check { color: #0D9488; margin-left: 4px; font-size: 0.65rem; }
        .basic-patient-card {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            padding: 30px 20px;
            text-align: center;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 200px;
        }
        html:not(.dark) .basic-patient-card {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }
        .basic-patient-card .icon { font-size: 2.5rem; color: #38BDF8; opacity: 0.3; margin-bottom: 12px; }
        .basic-patient-card h3 { font-size: 1rem; color: #F3F4F6; margin-bottom: 4px; }
        html:not(.dark) .basic-patient-card h3 { color: #0F172A; }
        .basic-patient-card p { color: #94A3B8; font-size: 0.8rem; }
        html:not(.dark) .basic-patient-card p { color: #64748B; }
        .basic-patient-card .strong { color: #F3F4F6; }
        html:not(.dark) .basic-patient-card .strong { color: #0F172A; }
        .no-queue-state {
            background: #141B2B;
            border: 1px solid #2D3748;
            border-radius: 16px;
            padding: 40px 20px;
            text-align: center;
            transition: all 0.3s ease;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 250px;
            margin-bottom: 24px;
        }
        html:not(.dark) .no-queue-state {
            background: #FFFFFF;
            border-color: #E2E8F0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
        }
        .no-queue-state .icon { font-size: 3rem; color: #38BDF8; opacity: 0.4; margin-bottom: 16px; }
        .no-queue-state h3 { font-size: 1.1rem; color: #F3F4F6; margin-bottom: 8px; }
        html:not(.dark) .no-queue-state h3 { color: #0F172A; }
        .no-queue-state p { color: #94A3B8; font-size: 0.85rem; }
        html:not(.dark) .no-queue-state p { color: #64748B; }
        .no-queue-state .examples { margin-top: 16px; display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
        .no-queue-state .examples span {
            background: #1E293B;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            color: #94A3B8;
        }
        html:not(.dark) .no-queue-state .examples span { background: #F1F5F9; color: #64748B; }
        .footer {
            background: #141B2B;
            border-top: 1px solid #2D3748;
            padding: 12px 24px;
            transition: all 0.3s ease;
            flex-shrink: 0;
            margin-top: auto;
        }
        html:not(.dark) .footer {
            background: #FFFFFF;
            border-top: 1px solid #E2E8F0;
        }
        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 0.6rem;
        }
        .footer-copyright { color: #64748B; }
        html:not(.dark) .footer-copyright { color: #94A3B8; }

        @media (max-width: 1024px) {
            .two-column { grid-template-columns: 1fr; }
            .right-column { order: -1; }
            .patient-details-grid { grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px 16px; }
            .patient-details-card { padding: 18px 20px; }
            .clinics-grid { grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); max-height: 300px; }
        }
        @media (max-width: 768px) {
            .main-container { padding: 16px 12px; }
            .search-section { flex-direction: column; align-items: stretch; padding: 16px; }
            .search-form-wrapper { flex-direction: column; min-width: auto; }
            .btn-search { justify-content: center; }
            .clinics-grid { grid-template-columns: 1fr; max-height: 250px; padding: 12px 16px; }
            .nav-bar { flex-direction: column; align-items: stretch; gap: 6px; padding: 10px 16px; }
            .nav-links { justify-content: center; flex-wrap: wrap; }
            .nav-left { justify-content: center; }
            .footer-container { flex-direction: column; text-align: center; }
            .clinic-card { flex-direction: column; align-items: flex-start; gap: 6px; }
            .no-queue-state { min-height: 180px; padding: 24px 16px; }
            .no-queue-state .icon { font-size: 2rem; }
            .patient-details-grid { grid-template-columns: 1fr 1fr; gap: 8px; }
            .patient-details-card { padding: 14px 16px; }
            .patient-detail-item .value { font-size: 0.85rem; }
            .basic-patient-card { min-height: 150px; padding: 20px; }
            .patient-details-card .card-badge { position: relative; top: auto; right: auto; margin-bottom: 8px; align-self: flex-start; }
            .nav-logo { height: 28px; }
        }
        @media (max-width: 480px) {
            .timeline { max-height: 200px; }
            .clinic-card .clinic-stats { flex-direction: column; gap: 4px; }
            .patient-details-grid { grid-template-columns: 1fr; gap: 6px; }
            .clinics-grid { max-height: 200px; }
            .patient-detail-item { padding: 6px 10px; }
            .nav-logo { height: 24px; }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar - Top -->
    <nav class="nav-bar">
        <div class="nav-left">
            <a href="index.php">
                <img src="../assets/images/logo.png" alt="CESH Logo" class="nav-logo" 
                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="logo-text-fallback">
                    <i class="fas fa-hospital"></i>
                    <span>CESH</span>
                </div>
            </a>
        </div>
        <div class="nav-links">
            <a href="track-queue.php" class="active"><i class="fas fa-search"></i> Track Queue</a>
            <a href="self-register.php"><i class="fas fa-user-plus"></i> Register</a>
            <span class="divider">|</span>
            <a href="../index.php"><i class="fas fa-lock"></i> Staff Login</a>
            <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
                <i class="fas <?php echo $is_dark ? 'fa-sun' : 'fa-moon'; ?>"></i>
            </button>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-container">
        <!-- Search Section -->
        <div class="search-section">
            <div>
                <span class="search-icon"><i class="fas fa-search"></i></span>
                <span class="search-title">Track Your Queue</span>
                <span class="search-subtitle">Enter your queue number or transaction token</span>
            </div>
            <div class="search-form-wrapper">
                <form method="POST" class="search-form-wrapper" style="display: flex; gap: 10px; flex: 1;">
                    <div class="search-input-wrapper">
                        <i class="fas fa-ticket-alt"></i>
                        <input type="text" name="search_term" class="search-input" 
                               placeholder="Queue number or transaction token" 
                               value="<?php echo isset($_POST['search_term']) ? htmlspecialchars($_POST['search_term']) : (isset($_GET['q']) ? htmlspecialchars($_GET['q']) : (isset($_GET['token']) ? htmlspecialchars($_GET['token']) : '')); ?>" 
                               required>
                    </div>
                    <button type="submit" name="track" class="btn-search">
                        <i class="fas fa-arrow-right"></i> Track
                    </button>
                </form>
            </div>
        </div>

        <?php if ($searched && !$queue_info && !$error): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Enter your queue number or transaction token from your ticket.
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- Clinics Section -->
        <div class="clinics-section">
            <div class="clinics-header">
                <h3><i class="fas fa-clinic-medical"></i> Available Clinics</h3>
                <span class="badge-count"><i class="fas fa-clock"></i> <?php echo $active_clinic_count; ?> active</span>
            </div>
            <div class="clinics-grid">
                <?php foreach ($clinics as $clinic): 
                    $wait_time = $clinic['waiting_count'] * 8;
                    $badge_class = 'low';
                    if ($wait_time > 30) $badge_class = 'high';
                    elseif ($wait_time > 15) $badge_class = 'medium';
                ?>
                    <div class="clinic-card <?php echo (int) $clinic['is_active'] === 1 ? '' : 'closed'; ?>">
                        <div class="clinic-info">
                            <div class="clinic-name"><?php echo htmlspecialchars($clinic['name']); ?></div>
                            <div class="clinic-stats">
                                <span><i class="fas fa-users"></i> <?php echo $clinic['waiting_count']; ?> waiting</span>
                                <span><i class="fas fa-check-circle"></i> <?php echo $clinic['completed_today']; ?> done</span>
                                <span><i class="fas fa-chart-line"></i> <?php echo $clinic['in_progress_count']; ?> active</span>
                            </div>
                        </div>
                        <?php if ((int) $clinic['is_active'] === 1): ?>
                            <span class="wait-badge <?php echo $badge_class; ?>">
                                <i class="fas fa-clock"></i> ~<?php echo $wait_time; ?> min
                            </span>
                        <?php else: ?>
                            <span class="closed-badge"><i class="fas fa-lock"></i> Closed</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php 
        // SAFETY CHECK: Only show if queue_info exists and is an array
        if (isset($queue_info) && is_array($queue_info) && !empty($queue_info)): 
        ?>
            
            <!-- ============================================ -->
            <!-- DEBUG BOX - VISIBLE ON PAGE -->
            <!-- ============================================ -->
            <?php
            // Check active clinic entries for today.
            $check_query = "SELECT COUNT(*) FROM queue_entries 
                            WHERE transaction_token = :transaction_token
                            AND status IN ('waiting', 'called', 'in-progress')
                            AND DATE(registered_at) = DATE(:registered_at)";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':transaction_token', $queue_info['transaction_token']);
            $check_stmt->bindParam(':registered_at', $queue_info['registered_at']);
            $check_stmt->execute();
            $has_incomplete = $check_stmt->fetchColumn() > 0;
            
            // Check journey
            $journey_query = "SELECT * FROM patient_journey 
                              WHERE patient_id = :patient_id
                              AND DATE(created_at) = DATE(:registered_at)
                              AND status = 'pending'
                              ORDER BY id DESC LIMIT 1";
            $journey_stmt = $db->prepare($journey_query);
            $journey_stmt->bindParam(':patient_id', $queue_info['patient_id']);
            $journey_stmt->bindParam(':registered_at', $queue_info['registered_at']);
            $journey_stmt->execute();
            $journey = $journey_stmt->fetch(PDO::FETCH_ASSOC);
            $journey_clinics = $journey ? json_decode($journey['clinic_sequence'], true) : [];
            $journey_has_remaining = $journey
                && !empty($all_clinics)
                && count(array_diff(array_column($all_clinics, 'id'), $completed_ids ?? [])) > 0;
            ?>
            
       
            
            <!-- Continue Message -->
            <?php if (!empty($continue_message)): ?>
                <div class="alert alert-success" style="background: #0D9488; color: white; padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; font-weight: 600; font-size: 16px;">
                    <?php echo $continue_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($journey && !$has_incomplete && $journey_has_remaining && date('Y-m-d', strtotime($queue_info['registered_at'])) === date('Y-m-d')): ?>
                <div style="margin-bottom: 20px;">
                    <button type="button" class="btn-search" onclick="openContinueModal()">
                        <i class="fas fa-arrow-right"></i> Continue Transaction
                    </button>
                </div>
            <?php endif; ?>

            <?php if ($journey && !$has_incomplete && $journey_has_remaining && date('Y-m-d', strtotime($queue_info['registered_at'])) === date('Y-m-d')): ?>
                <div id="continueModal" class="continue-modal" role="dialog" aria-modal="true" aria-labelledby="continueModalTitle" hidden>
                    <div class="continue-modal-backdrop" onclick="closeContinueModal()"></div>
                    <div class="continue-modal-content">
                        <button type="button" class="continue-modal-close" onclick="closeContinueModal()" aria-label="Close confirmation">&times;</button>
                        <div class="continue-modal-icon"><i class="fas fa-route"></i></div>
                        <h3 id="continueModalTitle">Do you wish to continue your transaction?</h3>
                        <p>Your next clinic will be selected using the current least-congested queue.</p>
                        <div class="continue-modal-actions">
                            <button type="button" class="continue-modal-cancel" onclick="closeContinueModal()">Cancel</button>
                            <a href="continue-journey.php?token=<?php echo urlencode($queue_info['transaction_token']); ?>" class="btn-search">
                                <i class="fas fa-arrow-right"></i> Continue
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        <!-- ============================================
             PATIENT DETAILS CARD
             ============================================ -->
        <div class="patient-details-card">
            <span class="card-badge">
                <i class="fas fa-check-circle"></i> Active
            </span>
            <div class="patient-details-grid">
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-id-card"></i> MRN</span>
                    <span class="value"><?php echo htmlspecialchars($queue_info['mrn'] ?? 'N/A'); ?></span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-user"></i> Patient Name</span>
                    <span class="value"><?php echo htmlspecialchars($queue_info['first_name'] . ' ' . $queue_info['last_name']); ?></span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-ticket-alt"></i> Queue Number</span>
                    <span class="value highlight"><?php echo htmlspecialchars($queue_info['queue_number']); ?></span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-clinic-medical"></i> Assigned Clinic</span>
                    <span class="value"><?php echo htmlspecialchars($queue_info['clinic_name']); ?></span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-chart-line"></i> Current Status</span>
                    <span class="status-pill <?php echo $queue_info['status']; ?>">
                        <?php echo strtoupper(str_replace('-', ' ', $queue_info['status'])); ?>
                    </span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-hourglass-half"></i> Priority Level</span>
                    <span class="priority-badge <?php echo $queue_info['priority_level']; ?>">
                        <?php echo $queue_info['priority_level']; ?> - 
                        <?php if ($queue_info['priority_level'] == 'PR1') echo 'Military';
                        elseif ($queue_info['priority_level'] == 'PR2') echo 'Priority';
                        else echo 'Regular'; ?>
                    </span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-calendar-alt"></i> Registered At</span>
                    <span class="value"><?php echo date('h:i A', strtotime($queue_info['registered_at'])); ?></span>
                </div>
                <div class="patient-detail-item">
                    <span class="label"><i class="fas fa-hourglass-start"></i> Waiting Time</span>
                    <span class="waiting-time">
                        <span class="time-number"><?php echo $queue_info['waiting_minutes'] ?? '0'; ?></span>
                        <span style="font-size: 0.7rem; color: #94A3B8;">minutes</span>
                    </span>
                </div>
            </div>
        </div>

        <!-- Two Column Layout -->
        <div class="two-column">
            <!-- Left Column - Journey -->
            <div class="left-column">
                <?php if (!empty($all_clinics)): ?>
                <div class="journey-card">
                    <div class="journey-header">
                        <h3><i class="fas fa-route"></i> Medical Journey</h3>
                        <p>Track your progress through all required clinics</p>
                    </div>
                    
                    <div class="journey-progress-bar">
                        <div class="journey-stats">
                            <span><i class="fas fa-flag-checkered"></i> Progress</span>
                            <span><strong><?php echo count($completed_clinics); ?></strong> of <strong><?php echo count($all_clinics); ?></strong></span>
                        </div>
                        <div class="journey-progress-bg">
                            <div class="journey-progress-fill" style="width: <?php echo $journey_progress; ?>%;"></div>
                        </div>
                        <div style="text-align: center; margin-top: 6px; font-size: 0.6rem; color: #94A3B8;">
                            <?php if ($journey_progress == 100): ?>
                                <i class="fas fa-trophy" style="color: #FFB84D;"></i> Completed! All assessments done.
                            <?php elseif ($journey_progress > 0): ?>
                                <i class="fas fa-chart-line"></i> Making great progress!
                            <?php else: ?>
                                <i class="fas fa-play-circle"></i> Journey begins here.
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="timeline">
                        <?php 
                        $completed_ids = array_column($completed_clinics, 'clinic_id');
                        $current_clinic_id = $current_clinic ? $current_clinic['clinic_id'] : null;
                        $pending_by_clinic = [];
                        foreach ($pending_clinics as $p) {
                            $pending_by_clinic[$p['clinic_id']] = $p;
                        }
                        
                        foreach ($all_clinics as $index => $clinic):
                            $clinic_id = $clinic['id'];
                            $is_completed = in_array($clinic_id, $completed_ids);
                            $is_current = ($current_clinic_id == $clinic_id);
                            $is_pending = isset($pending_by_clinic[$clinic_id]);
                            $pending_info = $pending_by_clinic[$clinic_id] ?? null;
                            
                            $status_class = '';
                            $status_text = '';
                            $icon = '';
                            $extra_info = '';
                            
                            if (!$clinic['is_active']) {
                                $status_class = 'pending';
                                $status_text = 'Closed';
                                $icon = 'fa-lock';
                                $extra_info = '<i class="fas fa-info-circle"></i> Not reached yet; available when reopened';
                            } elseif ($is_completed) {
                                $status_class = 'completed';
                                $status_text = 'Completed';
                                $icon = 'fa-check-circle';
                                foreach ($completed_clinics as $cc) {
                                    if ($cc['clinic_id'] == $clinic_id) {
                                        $extra_info = '<i class="fas fa-clock"></i> Done at ' . date('h:i A', strtotime($cc['completed_at']));
                                        break;
                                    }
                                }
                            } elseif ($is_current) {
                                $status_class = 'in-progress';
                                $status_text = 'In Progress';
                                $icon = 'fa-spinner fa-pulse';
                                $extra_info = '<i class="fas fa-bell"></i> Currently being attended';
                            } elseif ($pending_info && $pending_info['status'] == 'waiting') {
                                $status_class = 'waiting';
                                $status_text = 'In Queue';
                                $icon = 'fa-hourglass-half';
                                $extra_info = '<i class="fas fa-ticket-alt"></i> Queue #' . $pending_info['queue_number'] . ' | Pos ' . ($pending_info['position'] ?? '?');
                            } else {
                                $status_class = 'pending';
                                $status_text = 'Upcoming';
                                $icon = 'fa-hourglass-start';
                                $extra_info = '<i class="fas fa-info-circle"></i> Will be queued automatically';
                            }
                        ?>
                        <div class="timeline-item">
                            <div class="timeline-marker">
                                <div class="timeline-icon <?php echo $status_class; ?>">
                                    <i class="fas <?php echo $icon; ?>"></i>
                                </div>
                                <?php if ($index < count($all_clinics) - 1): ?>
                                    <div class="timeline-line"></div>
                                <?php endif; ?>
                            </div>
                            <div class="timeline-content">
                                <div class="timeline-clinic-name">
                                    <?php echo htmlspecialchars($clinic['name']); ?>
                                    <span class="timeline-status status-<?php echo $status_class; ?>-badge"><?php echo $status_text; ?></span>
                                    <?php if ($is_completed): ?>
                                        <span class="completion-check"><i class="fas fa-check-circle"></i></span>
                                    <?php endif; ?>
                                </div>
                                <div class="timeline-details"><?php echo $extra_info; ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($journey_progress == 100): ?>
                        <div style="padding: 12px 20px; background: linear-gradient(135deg, #0D9488 0%, #0F766E 100%); color: white; text-align: center; flex-shrink: 0;">
                            <i class="fas fa-trophy" style="font-size: 1.1rem;"></i>
                            <span style="font-weight: 600; font-size: 0.85rem;">Assessment Complete!</span>
                            <span style="font-size: 0.7rem; display: block; opacity: 0.9;">All medical assessments completed. Thank you for your service!</span>
                        </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <!-- Non-military patient - show basic info -->
                <div class="basic-patient-card">
                    <div class="icon"><i class="fas fa-clinic-medical"></i></div>
                    <h3>Dependent Patient</h3>
                    <p>You are registered as a dependent patient.</p>
                    <p style="margin-top: 6px;">Your queue is being processed at <span class="strong"><?php echo htmlspecialchars($queue_info['clinic_name']); ?></span></p>
                    <?php if ($queue_info['status'] != 'completed'): ?>
                        <p style="margin-top: 4px; font-size: 0.7rem; color: #94A3B8;">
                            <i class="fas fa-info-circle"></i> Please wait for your number to be called.
                        </p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Right Column - Clinics -->
            <div class="right-column">
                <div class="clinics-section" style="margin-bottom: 0;">
                    <div class="clinics-header">
                        <h3><i class="fas fa-clinic-medical"></i> All Clinics</h3>
                        <span class="badge-count"><i class="fas fa-clock"></i> <?php echo $active_clinic_count; ?> active</span>
                    </div>
                    <div class="clinics-grid" style="max-height: 350px;">
                        <?php foreach ($clinics as $clinic): 
                            $wait_time = $clinic['waiting_count'] * 8;
                            $badge_class = 'low';
                            if ($wait_time > 30) $badge_class = 'high';
                            elseif ($wait_time > 15) $badge_class = 'medium';
                        ?>
                            <div class="clinic-card <?php echo (int) $clinic['is_active'] === 1 ? '' : 'closed'; ?>">
                                <div class="clinic-info">
                                    <div class="clinic-name"><?php echo htmlspecialchars($clinic['name']); ?></div>
                                    <div class="clinic-stats">
                                        <span><i class="fas fa-users"></i> <?php echo $clinic['waiting_count']; ?> waiting</span>
                                        <span><i class="fas fa-check-circle"></i> <?php echo $clinic['completed_today']; ?> done</span>
                                        <span><i class="fas fa-chart-line"></i> <?php echo $clinic['in_progress_count']; ?> active</span>
                                    </div>
                                </div>
                                <?php if ((int) $clinic['is_active'] === 1): ?>
                                    <span class="wait-badge <?php echo $badge_class; ?>">
                                        <i class="fas fa-clock"></i> ~<?php echo $wait_time; ?> min
                                    </span>
                                <?php else: ?>
                                    <span class="closed-badge"><i class="fas fa-lock"></i> Closed</span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <!-- No queue found - show message -->
            <div class="no-queue-state">
                <div class="icon"><i class="fas fa-search"></i></div>
                <h3>No Queue Found</h3>
                <p>Enter your queue number or transaction token above to track your status.</p>
                <div class="examples">
                    <span><i class="fas fa-ticket-alt"></i> Queue #: M-09-001</span>
                    <span><i class="fas fa-key"></i> Token: TXN-2026...</span>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-copyright">
                <i class="fas fa-shield-alt"></i> <?php echo date('Y'); ?> 4th Infantry Division, Camp Evangelista Station Hospital
            </div>
        </div>
    </footer>

    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var isDark = html.classList.contains('dark');
            if (isDark) {
                html.classList.remove('dark');
                document.cookie = "theme=light; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-moon';
            } else {
                html.classList.add('dark');
                document.cookie = "theme=dark; path=/; max-age=31536000";
                document.querySelector('.theme-toggle i').className = 'fas fa-sun';
            }
        }

        function openContinueModal() {
            var modal = document.getElementById('continueModal');
            if (modal) {
                modal.hidden = false;
                document.body.style.overflow = 'hidden';
            }
        }

        function closeContinueModal() {
            var modal = document.getElementById('continueModal');
            if (modal) {
                modal.hidden = true;
                document.body.style.overflow = '';
            }
        }

        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') closeContinueModal();
        });

        <?php if ($queue_info): ?>
        setTimeout(function() {
            location.reload();
        }, 30000);
        <?php endif; ?>
        
        document.addEventListener('DOMContentLoaded', function() {
            var progressFill = document.querySelector('.journey-progress-fill');
            if (progressFill) {
                var width = progressFill.style.width;
                progressFill.style.width = '0%';
                setTimeout(function() {
                    progressFill.style.width = width;
                }, 100);
            }
        });
    </script>
</body>
</html>