<?php
// api/clinic-queue-action.php - AJAX endpoint for clinic queue operations

// Set error handling to prevent output before JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start output buffering to catch any errors
ob_start();

// Set JSON header FIRST before anything else
header('Content-Type: application/json', true);

try {
    // Start session
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    require_once dirname(__DIR__) . '/config/database.php';
    require_once dirname(__DIR__) . '/includes/QueueManager.php';
    
    // Check request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Invalid request method']);
        exit();
    }
    
    // Access Validation - Staff only
    $allowed_roles = ['admin', 'doctor', 'nurse', 'technician', 'staff'];
    if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], $allowed_roles)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
        exit();
    }
    
    $database = new Database();
    $db = $database->getConnection();
    $queueManager = new QueueManager($db);
    
    $action = isset($_POST['action']) ? trim($_POST['action']) : '';
    $clinic_id = isset($_POST['clinic_id']) ? intval($_POST['clinic_id']) : 0;
    $queue_id = isset($_POST['queue_id']) ? intval($_POST['queue_id']) : 0;
    $new_status = isset($_POST['status']) ? trim($_POST['status']) : '';
    
    // Verify clinic access for non-admin users
    if ($_SESSION['role'] != 'admin' && isset($_SESSION['clinic_id']) && $_SESSION['clinic_id'] != $clinic_id) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Access denied to this clinic']);
        exit();
    }
    
    if ($action == 'call_next') {
        // Call next patient
        if ($clinic_id <= 0) {
            throw new Exception('Invalid clinic ID');
        }
        
        $called_queue_id = $queueManager->callNextPatient($clinic_id);

        if (!$called_queue_id) {
            echo json_encode([
                'success' => false,
                'error' => 'No patients are waiting in this clinic'
            ]);
            exit();
        }

        $called_stmt = $db->prepare("SELECT q.queue_number, c.name AS clinic_name
                                     FROM queue_entries q
                                     JOIN clinics c ON c.id = q.clinic_id
                                     WHERE q.id = ?");
        $called_stmt->execute([$called_queue_id]);
        $called_patient = $called_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get updated queue
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM queue_entries q 
                             WHERE q.clinic_id = ? AND DATE(q.registered_at) = CURDATE() 
                             AND q.status IN ('waiting', 'called', 'in-progress')");
        $stmt->execute([$clinic_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'message' => 'Patient called',
            'queue_number' => $called_patient['queue_number'] ?? null,
            'clinic_name' => $called_patient['clinic_name'] ?? null,
            'queue_count' => $result['count'] ?? 0
        ]);
        
    } else if ($action == 'toggle_clinic') {
        if ($clinic_id <= 0) {
            throw new Exception('Invalid clinic ID');
        }

        $toggle_stmt = $db->prepare("UPDATE clinics SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?");
        $toggle_stmt->execute([$clinic_id]);

        if ($toggle_stmt->rowCount() === 0) {
            throw new Exception('Clinic not found');
        }

        $status_stmt = $db->prepare("SELECT is_active FROM clinics WHERE id = ?");
        $status_stmt->execute([$clinic_id]);

        echo json_encode([
            'success' => true,
            'message' => 'Clinic availability updated',
            'is_active' => (int) $status_stmt->fetchColumn()
        ]);
    } else if ($action == 'update_status') {
        // Update patient status
        if ($queue_id <= 0 || empty($new_status)) {
            throw new Exception('Invalid queue ID or status');
        }
        
        $valid_statuses = ['called', 'in-progress', 'completed', 'no-show'];
        if (!in_array($new_status, $valid_statuses)) {
            throw new Exception('Invalid status: ' . $new_status);
        }
        
        $query = "UPDATE queue_entries SET status = ?";
        if ($new_status == 'no-show') {
            $db->beginTransaction();
            $query = "UPDATE queue_entries SET status = ? WHERE id = ? AND status = 'called'";
            $stmt = $db->prepare($query);
            $stmt->execute([$new_status, $queue_id]);

            if ($stmt->rowCount() === 0) {
                $db->rollBack();
                throw new Exception('Only called patients can be marked as no-show');
            }

            $queue_stmt = $db->prepare("SELECT q.patient_id, q.clinic_id, p.patient_type
                                        FROM queue_entries q
                                        JOIN patients p ON p.id = q.patient_id
                                        WHERE q.id = ?");
            $queue_stmt->execute([$queue_id]);
            $queue_data = $queue_stmt->fetch(PDO::FETCH_ASSOC);

            if ($queue_data && $queue_data['patient_type'] !== 'military') {
                $journey_stmt = $db->prepare("SELECT id, clinic_sequence, current_index
                                              FROM patient_journey
                                              WHERE patient_id = ?
                                              ORDER BY id DESC LIMIT 1 FOR UPDATE");
                $journey_stmt->execute([$queue_data['patient_id']]);
                $journey = $journey_stmt->fetch(PDO::FETCH_ASSOC);
                $clinics = $journey ? json_decode($journey['clinic_sequence'], true) : null;

                if (is_array($clinics)) {
                    $clinic_index = array_search((int) $queue_data['clinic_id'], array_map('intval', $clinics), true);
                    if ($clinic_index !== false) {
                        $rewind_stmt = $db->prepare("UPDATE patient_journey
                                                     SET current_index = LEAST(current_index, ?), status = 'pending'
                                                     WHERE id = ?");
                        $rewind_stmt->execute([$clinic_index, $journey['id']]);
                    }
                }
            }

            $db->commit();

            echo json_encode([
                'success' => true,
                'message' => 'Patient marked as no-show',
                'status' => $new_status
            ]);
            exit();
        }

        if ($new_status == 'completed') {
            $query .= ", completed_at = NOW() WHERE id = ? AND status <> 'completed'";
        } elseif ($new_status == 'called') {
            $query .= ", called_at = NOW() WHERE id = ?";
        } else {
            $query .= " WHERE id = ?";
        }

        $stmt = $db->prepare($query);
        $stmt->execute([$new_status, $queue_id]);
        $next_message = null;

        if ($new_status == 'completed' && $stmt->rowCount() > 0) {
            $queue_query = "SELECT q.patient_id, p.patient_type, q.clinic_id
                            FROM queue_entries q
                            JOIN patients p ON q.patient_id = p.id
                            WHERE q.id = ?";
            $queue_stmt = $db->prepare($queue_query);
            $queue_stmt->execute([$queue_id]);
            $queue_data = $queue_stmt->fetch(PDO::FETCH_ASSOC);

            if ($queue_data) {
                if ($queue_data['patient_type'] == 'military') {
                    $next_result = $queueManager->queueMilitaryForNextClinic(
                        $queue_data['patient_id'],
                        $queue_data['clinic_id']
                    );

                    if ($next_result['success']) {
                        $next_message = "Military patient queued for: " . $next_result['clinic'] . " (least congested)";
                    } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                        $next_message = 'Military patient has completed ALL clinics!';
                    } else {
                        $next_message = 'Error: ' . ($next_result['error'] ?? 'Unknown error');
                    }
                } else {
                    $next_result = $queueManager->queueDependentForNextClinic(
                        $queue_data['patient_id'],
                        $queue_data['clinic_id']
                    );

                    if ($next_result['success']) {
                        $next_message = "Patient queued for: " . $next_result['clinic'] . " (least congested)";
                    } elseif (isset($next_result['all_completed']) && $next_result['all_completed']) {
                        $next_message = 'Patient has completed all clinics!';
                    } else {
                        $next_message = 'Error: ' . ($next_result['error'] ?? 'Unknown error');
                    }
                }

                $_SESSION['next_queue'] = $next_message;
            }
        }

        echo json_encode([
            'success' => true,
            'message' => 'Status updated',
            'status' => $new_status,
            'next_message' => $next_message
        ]);
        
    } else {
        throw new Exception('Unknown action: ' . $action);
    }
    
} catch (Exception $e) {
    if (isset($db) && $db instanceof PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit();
}

// Send the JSON response accumulated in the output buffer.
ob_end_flush();
?>
