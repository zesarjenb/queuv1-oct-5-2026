<?php
// test-email.php - Test email functionality

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>📧 Email Test</h2>";

// ============================================
// CONFIGURE YOUR TEST EMAIL HERE
// ============================================
$test_email = 'mark.adrian.lumongsod@gmail.com'; // CHANGE THIS

echo "<p><strong>Test Email:</strong> " . $test_email . "</p>";

// ============================================
// TEST 1: Check if SimpleEmailSender exists
// ============================================
echo "<h3>Test 1: Checking SimpleEmailSender</h3>";

// Fixed path - go up one directory to find includes
$sender_file = __DIR__ . '/includes/SimpleEmailSender.php';

if (file_exists($sender_file)) {
    echo "✅ includes/SimpleEmailSender.php found at: " . $sender_file . "<br>";
    require_once $sender_file;
} else {
    echo "❌ includes/SimpleEmailSender.php NOT found at: " . $sender_file . "<br>";
    
    // Try alternative path
    $alt_path = '../includes/SimpleEmailSender.php';
    if (file_exists($alt_path)) {
        echo "✅ Found at alternative path: " . $alt_path . "<br>";
        require_once $alt_path;
    } else {
        echo "❌ Also not found at: " . $alt_path . "<br>";
        echo "Please make sure includes/SimpleEmailSender.php exists.<br>";
        exit();
    }
}

// ============================================
// TEST 2: Check if PHPMailer exists
// ============================================
echo "<h3>Test 2: Checking PHPMailer</h3>";

// Try to load PHPMailer from vendor
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    echo "✅ vendor/autoload.php found<br>";
    require_once __DIR__ . '/vendor/autoload.php';
} elseif (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    echo "✅ vendor/autoload.php found at alternative path<br>";
    require_once __DIR__ . '/../vendor/autoload.php';
} else {
    echo "❌ vendor/autoload.php NOT found<br>";
}

if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    echo "✅ PHPMailer found<br>";
} else {
    echo "❌ PHPMailer NOT found<br>";
}

// ============================================
// TEST 3: Send test email
// ============================================
echo "<h3>Test 3: Sending Test Email</h3>";

if (class_exists('SimpleEmailSender')) {
    $emailSender = new SimpleEmailSender();
    
    $patient_name = 'Test Patient';
    $queue_number = 'TEST-001';
    $transaction_token = 'TXN-TEST-' . date('Ymd') . '-12345';
    $clinic_name = 'Test Clinic';
    
    echo "Sending to: " . $test_email . "<br>";
    echo "Patient: " . $patient_name . "<br>";
    echo "Queue: " . $queue_number . "<br>";
    echo "Token: " . $transaction_token . "<br>";
    echo "Clinic: " . $clinic_name . "<br><br>";
    
    $result = $emailSender->sendNotification($test_email, $patient_name, $queue_number, $transaction_token, $clinic_name);
    
    if ($result) {
        echo "✅ <strong style='color: green;'>Email sent successfully to: " . $test_email . "</strong><br>";
        echo "<br>📬 Check your email (and spam folder)!";
    } else {
        echo "❌ <strong style='color: red;'>Failed to send email.</strong><br>";
        echo "<br>Check the error logs for more details.";
    }
} else {
    echo "❌ SimpleEmailSender class not found. Make sure includes/SimpleEmailSender.php is loaded correctly.<br>";
}

echo "<br><br><a href='index.php'>Back to Login</a>";
?>