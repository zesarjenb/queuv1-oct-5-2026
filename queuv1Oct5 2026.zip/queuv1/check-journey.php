<?php
// check-journey.php - Simple journey check

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Simple Journey Check</h2>";

require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// ============================================
// CHECK DATABASE DIRECTLY
// ============================================
$patient_id = 211; // CHANGE THIS

echo "<p><strong>Checking patient ID: " . $patient_id . "</strong></p>";

// Check patient_journey table
$query = "SELECT * FROM patient_journey WHERE patient_id = :patient_id ORDER BY id DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':patient_id', $patient_id);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Patient Journey Table:</h3>";
if (empty($results)) {
    echo "❌ No journeys found<br>";
} else {
    echo "✅ Found " . count($results) . " journey(s):<br>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>patient_id</th><th>current_index</th><th>status</th><th>created_at</th></tr>";
    foreach ($results as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['patient_id'] . "</td>";
        echo "<td>" . $row['current_index'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check queue_entries table
$query2 = "SELECT * FROM queue_entries WHERE patient_id = :patient_id ORDER BY registered_at ASC";
$stmt2 = $db->prepare($query2);
$stmt2->bindParam(':patient_id', $patient_id);
$stmt2->execute();
$queue_results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Queue Entries:</h3>";
if (empty($queue_results)) {
    echo "❌ No queue entries found<br>";
} else {
    echo "✅ Found " . count($queue_results) . " queue entries:<br>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>Queue #</th><th>Clinic ID</th><th>Status</th><th>Registered At</th></tr>";
    foreach ($queue_results as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['queue_number'] . "</td>";
        echo "<td>" . $row['clinic_id'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['registered_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check patient info
$query3 = "SELECT * FROM patients WHERE id = :patient_id";
$stmt3 = $db->prepare($query3);
$stmt3->bindParam(':patient_id', $patient_id);
$stmt3->execute();
$patient = $stmt3->fetch(PDO::FETCH_ASSOC);

echo "<h3>Patient Info:</h3>";
if ($patient) {
    echo "<pre>";
    print_r($patient);
    echo "</pre>";
} else {
    echo "❌ Patient not found<br>";
}
?>