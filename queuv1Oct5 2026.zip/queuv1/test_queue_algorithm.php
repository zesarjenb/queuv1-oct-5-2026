<?php
// test_queue_algorithm.php - Quick test for queue algorithms
require_once 'config/database.php';
require_once 'includes/QueueManager.php';

$database = new Database();
$db = $database->getConnection();
$qm = new QueueManager($db);

echo "<h2>Smart Queueing System - Algorithm Test</h2>";

// Test 1: Priority Determination
echo "<h3>Test 1: Priority Determination</h3>";
$testPatients = [
    ['patient_type' => 'military', 'is_pwd' => 0, 'is_senior' => 0, 'is_pregnant' => 0, 'expected' => 'PR1'],
    ['patient_type' => 'dependent', 'is_pwd' => 1, 'is_senior' => 0, 'is_pregnant' => 0, 'expected' => 'PR2'],
    ['patient_type' => 'dependent', 'is_pwd' => 0, 'is_senior' => 1, 'is_pregnant' => 0, 'expected' => 'PR2'],
    ['patient_type' => 'dependent', 'is_pwd' => 0, 'is_senior' => 0, 'is_pregnant' => 1, 'expected' => 'PR2'],
    ['patient_type' => 'dependent', 'is_pwd' => 0, 'is_senior' => 0, 'is_pregnant' => 0, 'expected' => 'PR3'],
];

echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Patient Type</th><th>PWD</th><th>Senior</th><th>Pregnant</th><th>Expected</th><th>Actual</th><th>Result</th></tr>";
foreach ($testPatients as $tp) {
    $actual = $qm->determinePriority($tp);
    $result = ($actual == $tp['expected']) ? '✅ PASS' : '❌ FAIL';
    echo "<tr>";
    echo "<td>{$tp['patient_type']}</td>";
    echo "<td>{$tp['is_pwd']}</td>";
    echo "<td>{$tp['is_senior']}</td>";
    echo "<td>{$tp['is_pregnant']}</td>";
    echo "<td>{$tp['expected']}</td>";
    echo "<td>$actual</td>";
    echo "<td style='color: " . ($actual == $tp['expected'] ? 'green' : 'red') . ";'>$result</td>";
    echo "</tr>";
}
echo "</table>";

// Test 2: Queue Number Generation
echo "<h3>Test 2: Queue Number Generation</h3>";
$batch_hour = date('Y-m-d H:00:00');
$priorities = ['PR1', 'PR2', 'PR3'];
$prefixes = ['M', 'P', 'R'];
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Priority</th><th>Batch Hour</th><th>Queue Number</th></tr>";
foreach ($priorities as $i => $priority) {
    $queueNum = $qm->generateQueueNumber($priority, $batch_hour);
    $expectedPrefix = $prefixes[$i];
    $valid = (strpos($queueNum, $expectedPrefix) === 0);
    echo "<tr>";
    echo "<td>$priority</td>";
    echo "<td>" . date('H:00', strtotime($batch_hour)) . "</td>";
    echo "<td>$queueNum " . ($valid ? "✅" : "❌") . "</td>";
    echo "</tr>";
}
echo "</table>";

// Test 3: Find Least Congested Clinic
echo "<h3>Test 3: Least Congested Clinics</h3>";
$clinics = $qm->findLeastCongestedClinic();
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Rank</th><th>Clinic Name</th><th>Current Load</th><th>Capacity/hour</th></tr>";
foreach ($clinics as $index => $clinic) {
    echo "<tr>";
    echo "<td>" . ($index + 1) . "</td>";
    echo "<td>{$clinic['name']}</td>";
    echo "<td>{$clinic['current_load']}</td>";
    echo "<td>{$clinic['capacity_per_hour']}</td>";
    echo "</tr>";
}
echo "</table>";

// Test 4: Batch Information
echo "<h3>Test 4: Current Batch Information</h3>";
$batch = $qm->getCurrentBatch();
echo "<pre>";
print_r($batch);
echo "</pre>";
?>