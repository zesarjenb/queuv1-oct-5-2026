<?php
// admin/export-result-print.php - Print-friendly version of results with Logo
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

$result_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($result_id <= 0) {
    die("Invalid result ID.");
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT cr.*, p.first_name, p.last_name, p.mrn, p.date_of_birth, p.gender,
                 c.name as clinic_name, u.full_name as doctor_name
          FROM clinic_results cr
          JOIN patients p ON cr.patient_id = p.id
          JOIN clinics c ON cr.clinic_id = c.id
          LEFT JOIN users u ON cr.submitted_by = u.id
          WHERE cr.id = :result_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':result_id', $result_id);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$result) {
    die("Result not found.");
}

$result_data = json_decode($result['result_data'], true);

// Calculate age
$dob = new DateTime($result['date_of_birth']);
$today = new DateTime();
$age = $today->diff($dob)->y;

// Logo path - adjust based on your actual logo location
$logo_path = dirname(__DIR__) . '/assets/images/logo.png';
$logo_exists = file_exists($logo_path);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $result['last_name']; ?> - Laboratory Result | Camp Evangelista</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Times New Roman', Times, serif;
            background: #fff;
            padding: 20px;
        }
        
        @media print {
            body {
                padding: 0;
            }
            .no-print {
                display: none;
            }
            .print-container {
                box-shadow: none;
                padding: 0;
            }
        }
        
        .print-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        /* Header with Logo */
        .hospital-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #1a3a5c;
            padding-bottom: 15px;
            position: relative;
        }
        
        .logo-container {
            text-align: center;
            margin-bottom: 10px;
        }
        
        .logo-img {
            max-height: 60px;
            width: auto;
        }
        
        .hospital-name {
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 1px;
            color: #1a3a5c;
        }
        
        .hospital-sub {
            font-size: 11px;
            color: #555;
            margin-top: 3px;
        }
        
        /* Alternative: Header with left logo */
        .header-with-logo {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            border-bottom: 2px solid #1a3a5c;
            padding-bottom: 15px;
        }
        
        .header-left-logo {
            flex-shrink: 0;
        }
        
        .header-left-logo img {
            max-height: 60px;
            width: auto;
        }
        
        .header-center-text {
            flex: 1;
            text-align: center;
        }
        
        .header-right-spacer {
            flex-shrink: 0;
            width: 60px;
        }
        
        .report-title {
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            text-decoration: underline;
            margin: 15px 0;
            letter-spacing: 1px;
        }
        
        /* Patient Info */
        .patient-info {
            width: 100%;
            border: 1px solid #333;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 11px;
        }
        
        .patient-info td, .patient-info th {
            border: 1px solid #333;
            padding: 8px 10px;
        }
        
        .patient-info th {
            background: #f0f0f0;
            width: 25%;
            text-align: left;
        }
        
        /* Specimen Section */
        .specimen-section {
            margin-bottom: 15px;
            font-size: 11px;
        }
        
        .specimen-section strong {
            font-weight: bold;
        }
        
        /* Results Table */
        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 10px;
        }
        
        .results-table th, .results-table td {
            border: 1px solid #333;
            padding: 8px 10px;
            text-align: left;
        }
        
        .results-table th {
            background: #f0f0f0;
            font-weight: bold;
            text-align: center;
        }
        
        .results-table td {
            text-align: center;
        }
        
        .results-table td:first-child {
            text-align: left;
        }
        
        /* Interpretation */
        .interpretation-section {
            margin-bottom: 15px;
            font-size: 11px;
        }
        
        .interpretation-section .label {
            font-weight: bold;
            text-decoration: underline;
            margin-bottom: 5px;
        }
        
        /* Signature */
        .signature-section {
            margin-top: 30px;
            text-align: right;
            font-size: 11px;
        }
        
        .signature-line {
            margin-top: 40px;
            width: 250px;
            border-top: 1px solid #333;
            margin-left: auto;
            text-align: center;
            padding-top: 5px;
        }
        
        .btn-print {
            background: #4A90E2;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-bottom: 20px;
            display: inline-block;
            margin-right: 10px;
        }
        
        .btn-print:hover {
            background: #3A7BC8;
        }
        
        .btn-close {
            background: #666;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-bottom: 20px;
            display: inline-block;
        }
        
        .btn-close:hover {
            background: #555;
        }
        
        .watermark {
            text-align: center;
            font-size: 9px;
            color: #999;
            margin-top: 20px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
        
        /* Text logo fallback (if no image) */
        .text-logo {
            font-size: 24px;
            font-weight: bold;
            color: #1a3a5c;
        }
        
        .text-logo-sub {
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" class="btn-print">
            <i class="fas fa-print"></i> Print / Save as PDF
        </button>
        <button onclick="window.close()" class="btn-close">
            Close Window
        </button>
    </div>
    
    <div class="print-container">
        <!-- Header with Logo -->
        <?php if ($logo_exists): ?>
        <!-- Style 1: Logo centered above text -->
        <div class="hospital-header">
            <div class="logo-container">
                <img src="../assets/images/logo.png" alt="Camp Evangelista Hospital Logo" class="logo-img">
            </div>
            <div class="hospital-name">CAMP EVANGELISTA STATION HOSPITAL</div>
            <div class="hospital-sub">4th Infantry Division, Philippine Army</div>
            <div class="hospital-sub">Camp Evangelista, Cagayan de Oro City</div>
        </div>
        <?php else: ?>
        <!-- Fallback: Text-based logo -->
        <div class="hospital-header">
            <div class="text-logo">⚕️ CAMP EVANGELISTA STATION HOSPITAL ⚕️</div>
            <div class="text-logo-sub">4th Infantry Division, Philippine Army | Camp Evangelista, Cagayan de Oro City</div>
        </div>
        <?php endif; ?>
        
        <div class="report-title">PATIENT LABORATORY RESULT REPORT</div>
        
        <!-- Patient Information Table -->
        <table class="patient-info">
            <tr>
                <th>Patient Name:</th>
                <td><?php echo strtoupper($result['last_name'] . ', ' . $result['first_name']); ?></td>
                <th>Age:</th>
                <td><?php echo $age; ?></td>
                <th>Sex:</th>
                <td><?php echo $result['gender']; ?></td>
            </tr>
            <tr>
                <th>Hospital No (MRN):</th>
                <td><?php echo $result['mrn']; ?></td>
                <th>Date of Request:</th>
                <td colspan="2"><?php echo date('Y-m-d', strtotime($result['submitted_at'])); ?></td>
            </tr>
        </table>
        
        <!-- Specimen -->
        <div class="specimen-section">
            <strong>Specimen:</strong> Blood / <?php echo htmlspecialchars($result['clinic_name']); ?>
        </div>
        
        <!-- Test Results Table -->
        <table class="results-table">
            <thead>
                <tr>
                    <th>Parameter</th>
                    <th>Result</th>
                    <th>Reference Range</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $has_data = false;
                if ($result_data && is_array($result_data)): 
                    foreach ($result_data as $key => $value): 
                        if (empty($value)) continue;
                        $has_data = true;
                        $label = ucwords(str_replace('_', ' ', $key));
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($label); ?></td>
                        <td><?php echo htmlspecialchars($value); ?></td>
                        <td style="color: #666;">
                            <?php 
                            // Add reference ranges based on parameter
                            $param_lower = strtolower($key);
                            if (strpos($param_lower, 'blood_pressure') !== false || strpos($param_lower, 'bp') !== false) echo '120/80 mmHg';
                            elseif (strpos($param_lower, 'heart_rate') !== false) echo '60-100 bpm';
                            elseif (strpos($param_lower, 'temperature') !== false) echo '36.5-37.5 °C';
                            elseif (strpos($param_lower, 'respiratory') !== false) echo '12-20 breaths/min';
                            elseif (strpos($param_lower, 'oxygen') !== false) echo '95-100%';
                            elseif (strpos($param_lower, 'bmi') !== false) echo '18.5-24.9 kg/m²';
                            elseif (strpos($param_lower, 'wbc') !== false || strpos($param_lower, 'white_blood') !== false) echo '4.0-10.0 x 10^9/L';
                            elseif (strpos($param_lower, 'rbc') !== false || strpos($param_lower, 'red_blood') !== false) echo '4.5-5.9 x 10^12/L';
                            elseif (strpos($param_lower, 'hemoglobin') !== false || strpos($param_lower, 'hgb') !== false) echo '135-175 g/L';
                            elseif (strpos($param_lower, 'hematocrit') !== false || strpos($param_lower, 'hct') !== false) echo '41.0-53.0 %';
                            elseif (strpos($param_lower, 'platelet') !== false || strpos($param_lower, 'plt') !== false) echo '150-400 x 10^9/L';
                            else echo '—';
                            ?>
                        </td>
                    </tr>
                <?php 
                    endforeach;
                endif; 
                if (!$has_data):
                ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">No laboratory data available. See findings below.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Interpretation / Remarks -->
        <?php if (!empty($result['findings'])): ?>
        <div class="interpretation-section">
            <div class="label">INTERPRETATION / REMARKS:</div>
            <div style="margin-top: 5px; line-height: 1.5;"><?php echo nl2br(htmlspecialchars($result['findings'])); ?></div>
        </div>
        <?php endif; ?>
        
        <!-- Recommendations -->
        <?php if (!empty($result['recommendations'])): ?>
        <div class="interpretation-section">
            <div class="label">RECOMMENDATIONS:</div>
            <div style="margin-top: 5px; line-height: 1.5;"><?php echo nl2br(htmlspecialchars($result['recommendations'])); ?></div>
        </div>
        <?php endif; ?>
        
        <!-- Signature -->
        <div class="signature-section">
            <div class="signature-line">
                <?php echo $result['doctor_name'] ?? 'Medical Officer'; ?><br>
                Medical Officer / Pathologist
            </div>
        </div>
        
        <!-- Footer -->
        <div class="watermark">
            Generated on <?php echo date('F d, Y h:i A'); ?> | This is a computer-generated document.
        </div>
    </div>
    
    <script>
        // Auto-open print dialog when page loads (optional)
        // setTimeout(function() {
        //     window.print();
        // }, 500);
    </script>
</body>
</html>