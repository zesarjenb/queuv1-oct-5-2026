<?php
// admin/setup-2fa.php - Two-Factor Authentication Setup
// Camp Evangelista Station Hospital

session_start();
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/GoogleAuthenticator.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$ga = new GoogleAuthenticator();

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Get user
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Generate new secret if not exists
if (empty($user['twofa_secret'])) {
    $secret = $ga->createSecret();
    $update = "UPDATE users SET twofa_secret = ? WHERE id = ?";
    $update_stmt = $db->prepare($update);
    $update_stmt->execute([$secret, $user_id]);
} else {
    $secret = $user['twofa_secret'];
}

// Handle enable/disable
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['enable'])) {
        $code = $_POST['code'] ?? '';
        if ($ga->verifyCode($secret, $code, 2)) {
            $update = "UPDATE users SET twofa_enabled = 1 WHERE id = ?";
            $update_stmt = $db->prepare($update);
            $update_stmt->execute([$user_id]);
            $message = '2FA enabled successfully!';
            
            // Refresh user data
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = 'Invalid verification code';
        }
    } elseif (isset($_POST['disable'])) {
        $update = "UPDATE users SET twofa_enabled = 0 WHERE id = ?";
        $update_stmt = $db->prepare($update);
        $update_stmt->execute([$user_id]);
        $message = '2FA disabled';
        
        // Refresh user data
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$qr_url = $ga->getQRCodeUrl($user['username'], $secret, 'CampEvangelista Hospital');

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2FA Setup | 4ID Station Hospital | Camp Evangelista</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login Monitor</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300 flex items-center justify-center">
        
        <div class="w-full max-w-lg">
            <!-- Header -->
            <div class="mb-6">
                <a href="users.php" class="inline-flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-sky-600 dark:hover:text-sky-400 text-sm font-medium transition-colors mb-4">
                    <i class="fas fa-arrow-left"></i> Back to User Management
                </a>
                <h1 class="text-slate-900 dark:text-white text-2xl font-extrabold tracking-tight">Two-Factor Authentication</h1>
                <p class="text-slate-500 dark:text-slate-400 text-sm font-medium mt-1">Secure your account with an additional layer of protection</p>
            </div>

            <!-- Main Card -->
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-2xl shadow-sm overflow-hidden">
                
                <!-- Card Header -->
                <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex items-center gap-3">
                    <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-xl flex items-center justify-center text-sky-600 dark:text-sky-400">
                        <i class="fas fa-shield-alt text-lg"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white">Security Settings</h3>
                        <p class="text-[0.6rem] font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wider">Two-Factor Authentication</p>
                    </div>
                </div>

                <!-- Card Body -->
                <div class="p-6">
                    <?php if ($message): ?>
                        <div class="mb-4 p-3 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs font-bold flex items-center gap-2.5">
                            <i class="fas fa-check-circle text-sm"></i> <?php echo $message; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="mb-4 p-3 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-400 rounded-xl text-xs font-bold flex items-center gap-2.5">
                            <i class="fas fa-exclamation-circle text-sm"></i> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($user['twofa_enabled']): ?>
                        <!-- 2FA Enabled State -->
                        <div class="text-center py-4">
                            <div class="w-20 h-20 bg-emerald-50 dark:bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                                <i class="fas fa-check-circle text-4xl text-emerald-500"></i>
                            </div>
                            <h4 class="text-lg font-bold text-slate-900 dark:text-white mb-1">2FA is Active</h4>
                            <p class="text-sm text-slate-500 dark:text-slate-400">Your account is protected by two-factor authentication.</p>
                            <div class="mt-2 inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-full text-xs font-bold">
                                <i class="fas fa-shield-alt"></i> Secured
                            </div>
                        </div>
                        
                        <form method="POST" class="mt-4">
                            <button type="submit" name="disable" class="w-full bg-rose-500 hover:bg-rose-600 text-white font-bold text-sm py-3 px-4 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2">
                                <i class="fas fa-ban"></i> Disable Two-Factor Authentication
                            </button>
                        </form>
                    <?php else: ?>
                        <!-- 2FA Setup State -->
                        <div class="mb-6 p-4 bg-sky-50 dark:bg-sky-500/10 border border-sky-200 dark:border-sky-500/20 rounded-xl flex items-start gap-3">
                            <i class="fas fa-info-circle text-sky-600 dark:text-sky-400 text-lg mt-0.5"></i>
                            <div>
                                <p class="text-xs font-semibold text-slate-700 dark:text-slate-300">Setup Instructions</p>
                                <ol class="text-xs text-slate-500 dark:text-slate-400 mt-1 space-y-1 list-decimal list-inside">
                                    <li>Install <strong class="text-slate-700 dark:text-slate-300">Google Authenticator</strong> on your mobile device</li>
                                    <li>Scan the QR code below or enter the secret key manually</li>
                                    <li>Enter the 6-digit verification code to activate</li>
                                </ol>
                            </div>
                        </div>
                        
                        <!-- QR Code -->
                        <div class="flex flex-col items-center mb-6">
                            <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                                <img src="https://chart.googleapis.com/chart?chs=250x250&chld=M|0&cht=qr&chl=<?php echo urlencode($qr_url); ?>" 
                                     alt="QR Code" class="w-48 h-48 object-contain">
                            </div>
                            <p class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-3">Scan QR Code with Authenticator App</p>
                        </div>
                        
                        <!-- Secret Key -->
                        <div class="mb-6">
                            <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">Secret Key (Manual Entry)</label>
                            <div class="flex items-center gap-3">
                                <input type="text" value="<?php echo $secret; ?>" readonly class="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-sm rounded-xl focus:outline-none focus:border-sky-500 transition-all">
                                <button onclick="copySecret()" class="px-3 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 rounded-xl transition-colors" title="Copy Secret Key">
                                    <i class="fas fa-copy text-sm"></i>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Verification Form -->
                        <form method="POST">
                            <div class="mb-4">
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">Verification Code</label>
                                <div class="relative">
                                    <input type="text" name="code" placeholder="Enter 6-digit code" maxlength="6" required 
                                           class="w-full px-4 py-3 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-lg tracking-widest rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all text-center">
                                    <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                        <span class="text-slate-400 text-xs font-bold">6 digits</span>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="enable" class="w-full bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm py-3 px-4 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2">
                                <i class="fas fa-check"></i> Enable Two-Factor Authentication
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Security Notice -->
            <div class="mt-4 text-center text-[0.6rem] font-medium text-slate-400 dark:text-slate-500">
                <i class="fas fa-lock mr-1"></i> Your security is our priority. 2FA adds an extra layer of protection.
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        const themeToggleBtn = document.getElementById('themeToggleBtn');
        const themeToggleIcon = document.getElementById('themeToggleIcon');
        const htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            if(themeToggleIcon) themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            if(themeToggleIcon) themeToggleIcon.className = 'fas fa-moon text-base';
        }

        if(themeToggleBtn) {
            themeToggleBtn.addEventListener('click', () => {
                if (htmlElement.classList.contains('dark')) {
                    htmlElement.classList.remove('dark');
                    if(themeToggleIcon) themeToggleIcon.className = 'fas fa-moon text-base';
                    localStorage.setItem('theme', 'light');
                } else {
                    htmlElement.classList.add('dark');
                    if(themeToggleIcon) themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                    localStorage.setItem('theme', 'dark');
                }
            });
        }

        // Copy Secret Key
        function copySecret() {
            const secretInput = document.querySelector('input[value="<?php echo $secret; ?>"]');
            if (secretInput) {
                secretInput.select();
                document.execCommand('copy');
                // Show feedback
                const btn = secretInput.nextElementSibling;
                const originalHtml = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check text-green-500"></i>';
                setTimeout(() => {
                    btn.innerHTML = originalHtml;
                }, 2000);
            }
        }

        // Mobile Menu
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', (e) => {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Profile Dropdown
        const profileMenuBtn = document.getElementById('profileMenuBtn');
        const profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', () => profileDropdown.classList.add('hidden'));
        }

        // Live Clock
        function updateDateTime() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const dateEl = document.getElementById('currentDate');
            const timeEl = document.getElementById('currentTime');
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-US', options);
            if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Inactivity Timer
        const INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        let inactivityTimer;
        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            inactivityTimer = setTimeout(function() {
                window.location.href = '../logout.php';
            }, INACTIVITY_TIMEOUT);
        }
        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'click'];
        events.forEach(event => document.addEventListener(event, resetInactivityTimer, false));
        resetInactivityTimer();
    </script>

</body>
</html>