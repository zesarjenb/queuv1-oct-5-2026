<?php
// admin/patient-view.php - View Patient Information (Read Only)
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($patient_id <= 0) {
    header('Location: patients.php');
    exit();
}

// Get patient data
$query = "SELECT * FROM patients WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $patient_id);
$stmt->execute();
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    header('Location: patients.php');
    exit();
}

// Get queue history
$queue_query = "SELECT q.*, c.name as clinic_name
                FROM queue_entries q
                JOIN clinics c ON q.clinic_id = c.id
                WHERE q.patient_id = :patient_id
                ORDER BY q.registered_at DESC
                LIMIT 20";
$queue_stmt = $db->prepare($queue_query);
$queue_stmt->bindParam(':patient_id', $patient_id);
$queue_stmt->execute();
$queue_history = $queue_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get medical history
$medical_query = "SELECT * FROM medical_history 
                  WHERE patient_id = :patient_id 
                  ORDER BY recorded_at DESC
                  LIMIT 10";
$medical_stmt = $db->prepare($medical_query);
$medical_stmt->bindParam(':patient_id', $patient_id);
$medical_stmt->execute();
$medical_history = $medical_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get documents
$doc_query = "SELECT * FROM documents 
              WHERE patient_id = :patient_id 
              ORDER BY uploaded_at DESC
              LIMIT 10";
$doc_stmt = $db->prepare($doc_query);
$doc_stmt->bindParam(':patient_id', $patient_id);
$doc_stmt->execute();
$documents = $doc_stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate age
function calculateAge($dob) {
    if (!$dob || $dob == '0000-00-00') return '—';
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}

// Get patient status (with fallback)
$patient_status = isset($patient['status']) ? $patient['status'] : 'Active';

// Determine priority level
$priority = 'PR3';
if ($patient['patient_type'] == 'military') {
    $priority = 'PR1';
} elseif ($patient['is_pwd'] || $patient['is_senior'] || $patient['is_pregnant']) {
    $priority = 'PR2';
}

$priority_info = [
    'PR1' => ['text' => 'PR1 - Military Personnel', 'color' => '#FF6F61', 'bg' => '#FEF2F0'],
    'PR2' => ['text' => 'PR2 - Priority (PWD/Senior/Pregnant)', 'color' => '#FFB84D', 'bg' => '#FFF8ED'],
    'PR3' => ['text' => 'PR3 - Regular Patient', 'color' => '#009688', 'bg' => '#E0F2F1']
];

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo ($current_theme === 'dark') ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Details | <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?> | Camp Evangelista</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
             <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
   
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="dashboard.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="patients.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patients</span>
                        </a>
                    </li>
                    <li>
                        <a href="queue-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-line text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Queue Monitor</span>
                        </a>
                    </li>
                    <li>
                        <a href="clinic-congestion.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-pie text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Clinic Congestion</span>
                        </a>
                    </li>
                    <li>
                        <a href="reports.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-chart-bar text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-users-cog text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="login-monitor.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-history text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Login Monitor</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Patient Record Ledger</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Read-only profile archive registry and diagnostic ledger history</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate">System Administrator</p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5">HOSP-HQ COM</p>
                        </div>
                        <div class="p-1.5">
                            <a href="../logout.php" onclick="return confirm('Confirm Dashboard Exit?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Back Button -->
        <div class="mb-5">
            <a href="patients.php" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-600 dark:text-slate-300 text-xs font-bold uppercase tracking-wider px-4 py-2.5 rounded-xl shadow-sm transition-all">
                <i class="fas fa-arrow-left text-sky-500"></i> Return to Registry
            </a>
        </div>

        <!-- Patient Summary -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-700/60">
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 bg-sky-50 dark:bg-sky-500/10 border border-sky-100 dark:border-sky-500/20 text-sky-600 dark:text-sky-400 rounded-full flex items-center justify-center text-2xl font-black shadow-inner">
                        <?php echo strtoupper(substr($patient['first_name'] ?? '', 0, 1) . substr($patient['last_name'] ?? '', 0, 1)); ?>
                    </div>
                    <div>
                        <h2 class="text-slate-900 dark:text-white text-lg font-extrabold tracking-tight leading-snug"><?php echo htmlspecialchars(($patient['first_name'] ?? '') . ' ' . ($patient['last_name'] ?? '')); ?></h2>
                        <p class="text-slate-500 dark:text-slate-400 text-xs font-medium mt-0.5">
                            <i class="fas fa-id-card mr-1"></i>MRN: <?php echo htmlspecialchars($patient['mrn'] ?? 'N/A'); ?> | 
                            <i class="fas fa-calendar-alt mr-1 ml-2"></i><?php echo isset($patient['date_of_birth']) ? date('M d, Y', strtotime($patient['date_of_birth'])) : 'N/A'; ?> | 
                            <i class="fas fa-venus-mars ml-2 mr-1"></i><?php echo htmlspecialchars($patient['gender'] ?? 'N/A'); ?>
                        </p>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <span class="px-3 py-1.5 rounded-full text-xs font-bold" style="background: <?php echo $priority_info[$priority]['bg']; ?>; color: <?php echo $priority_info[$priority]['color']; ?>;">
                        <?php echo $priority_info[$priority]['text']; ?>
                    </span>
                    <span class="px-3 py-1.5 rounded-full text-xs font-bold <?php echo $patient_status == 'Active' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'; ?>">
                        <i class="fas <?php echo $patient_status == 'Active' ? 'fa-check-circle' : 'fa-archive'; ?>"></i> <?php echo $patient_status; ?>
                    </span>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="p-4 bg-slate-50/50 dark:bg-slate-800/20 flex flex-wrap gap-3">
                <a href="patient-edit.php?id=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all">
                    <i class="fas fa-edit"></i> Edit Patient
                </a>
                <a href="medical_history.php?patient_id=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">
                    <i class="fas fa-notes-medical text-sky-500"></i> Medical History
                </a>
                <a href="patient-results.php?id=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">
                    <i class="fas fa-file-alt text-sky-500"></i> Lab Results
                </a>
                <a href="../staff/registration.php?edit=<?php echo $patient_id; ?>" class="inline-flex items-center gap-2 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold px-4 py-2 rounded-xl transition-all">
                    <i class="fas fa-calendar-plus text-sky-500"></i> Schedule Appointment
                </a>
            </div>
        </div>

        <!-- Personal Information -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-user-md text-sky-500 text-sm"></i> Personal Information
                </h3>
            </div>
            <div class="p-5">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Full Name</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Date of Birth</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo date('F d, Y', strtotime($patient['date_of_birth'])); ?> (<?php echo calculateAge($patient['date_of_birth']); ?> years)</div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Gender</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo $patient['gender']; ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Patient Type</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo ucfirst($patient['patient_type']); ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Contact Number</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo htmlspecialchars($patient['contact_number'] ?: '—'); ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
    <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Email Address</div>
    <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo htmlspecialchars($patient['email'] ?: '—'); ?></div>
</div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Address</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo htmlspecialchars($patient['address'] ?: '—'); ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Primary Physician</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1"><?php echo htmlspecialchars($patient['primary_physician'] ?: '—'); ?></div>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-3">
                        <div class="text-[0.6rem] font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">Priority Conditions</div>
                        <div class="text-sm font-bold text-slate-900 dark:text-white mt-1">
                            <?php 
                            $conditions = array();
                            if ($patient['is_pwd']) $conditions[] = 'PWD';
                            if ($patient['is_senior']) $conditions[] = 'Senior Citizen';
                            if ($patient['is_pregnant']) $conditions[] = 'Pregnant';
                            echo !empty($conditions) ? implode(', ', $conditions) : 'None';
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Medical History -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-notes-medical text-sky-500 text-sm"></i> Recent Medical History
                </h3>
                <a href="medical_history.php?patient_id=<?php echo $patient_id; ?>" class="text-[0.6rem] font-bold text-sky-500 hover:text-sky-600 transition-colors">View All →</a>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($medical_history)): ?>
                    <div class="text-center py-8 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-notes-medical text-2xl mb-2 block opacity-50"></i>
                        <span class="text-xs font-medium">No medical history records found</span>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700/60 text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">Date</th>
                                <th class="py-3 px-4">Diagnosis</th>
                                <th class="py-3 px-4">Medications</th>
                                <th class="py-3 px-4">Allergies</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($medical_history as $record): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?php echo date('M d, Y', strtotime($record['recorded_at'])); ?></td>
                                    <td class="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200"><?php echo nl2br(htmlspecialchars(substr($record['diagnosis'] ?? '', 0, 100))); ?></td>
                                    <td class="py-3 px-4 text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars(substr($record['medications'] ?? '', 0, 50)); ?></td>
                                    <td class="py-3 px-4 text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars(substr($record['allergies'] ?? '', 0, 50)); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Queue History -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-history text-sky-500 text-sm"></i> Queue History
                </h3>
                <span class="text-[0.6rem] font-bold text-slate-400 dark:text-slate-500"><i class="fas fa-clock"></i> Last 20 visits</span>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($queue_history)): ?>
                    <div class="text-center py-8 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-inbox text-2xl mb-2 block opacity-50"></i>
                        <span class="text-xs font-medium">No queue history found</span>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700/60 text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">Date</th>
                                <th class="py-3 px-4">Time</th>
                                <th class="py-3 px-4">Queue #</th>
                                <th class="py-3 px-4">Clinic</th>
                                <th class="py-3 px-4">Priority</th>
                                <th class="py-3 px-4 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($queue_history as $queue): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?php echo date('M d, Y', strtotime($queue['registered_at'])); ?></td>
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?php echo date('h:i A', strtotime($queue['registered_at'])); ?></td>
                                    <td class="py-3 px-4 font-mono font-bold text-sky-600 dark:text-sky-400"><?php echo htmlspecialchars($queue['queue_number']); ?></td>
                                    <td class="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($queue['clinic_name']); ?></td>
                                        <td class="py-3 px-4">
                                            <span class="px-2 py-0.5 rounded-full text-[0.6rem] font-bold <?php echo ($queue['priority_level'] == 'PR1') ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400' : (($queue['priority_level'] == 'PR2') ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'); ?>">
                                                <?php echo htmlspecialchars($queue['priority_level']); ?>
                                            </span>
                                        </td>
                                    <td class="py-3 px-4 text-right">
                                        <?php
                                            $status_class = 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400';
                                            if ($queue['status'] == 'completed') {
                                                $status_class = 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
                                            } elseif ($queue['status'] == 'in-progress') {
                                                $status_class = 'bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 animate-pulse';
                                            }
                                        ?>
                                        <span class="px-2 py-0.5 rounded-full text-[0.6rem] font-bold <?php echo $status_class; ?>">
                                            <?php echo ucfirst($queue['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Documents -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-file-alt text-sky-500 text-sm"></i> Documents
                </h3>
                <a href="patient-documents.php?patient_id=<?php echo $patient_id; ?>" class="text-[0.6rem] font-bold text-sky-500 hover:text-sky-600 transition-colors">View All →</a>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($documents)): ?>
                    <div class="text-center py-8 text-slate-400 dark:text-slate-500">
                        <i class="fas fa-file-alt text-2xl mb-2 block opacity-50"></i>
                        <span class="text-xs font-medium">No documents found</span>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700/60 text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">Uploaded</th>
                                <th class="py-3 px-4">File Name</th>
                                <th class="py-3 px-4">Type</th>
                                <th class="py-3 px-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium text-slate-700 dark:text-slate-300">
                            <?php foreach ($documents as $doc): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?php echo date('M d, Y', strtotime($doc['uploaded_at'])); ?></td>
                                    <td class="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($doc['file_name']); ?></td>
                                    <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[0.6rem] font-bold"><?php echo htmlspecialchars($doc['document_type'] ?: 'Document'); ?></span></td>
                                    <td class="py-3 px-4 text-right">
                                        <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" class="inline-flex items-center gap-1.5 text-[0.6rem] font-bold text-sky-500 hover:text-sky-600 transition-colors">
                                            <i class="fas fa-download"></i> View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
        } else {
            htmlElement.classList.remove('dark');
            themeToggleIcon.className = 'fas fa-moon text-base';
        }

        themeToggleBtn.addEventListener('click', function() {
            if (htmlElement.classList.contains('dark')) {
                htmlElement.classList.remove('dark');
                themeToggleIcon.className = 'fas fa-moon text-base';
                localStorage.setItem('theme', 'light');
            } else {
                htmlElement.classList.add('dark');
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function() {
                profileDropdown.classList.add('hidden');
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
            document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = '<div class="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700"><i class="fas fa-clock text-5xl text-rose-500 mb-5"></i><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Session Expired</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-5">You have been logged out due to inactivity.</p><div class="w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden"><div class="bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full"></div></div></div></div>';
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = '<div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4"><div class="bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in"><i class="fas fa-hourglass-half text-5xl text-amber-500 mb-4"></i><h3 class="text-lg font-bold text-slate-900 dark:text-white mb-1">Session About to Expire</h3><p class="text-slate-500 dark:text-slate-400 text-sm mb-3">You will be logged out due to inactivity.</p><p id="countdownText" class="text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4">2:00</p><button onclick="keepSessionAlive()" class="w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm"><i class="fas fa-mouse-pointer mr-1.5"></i> Keep Session Active</button></div></div>';
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>