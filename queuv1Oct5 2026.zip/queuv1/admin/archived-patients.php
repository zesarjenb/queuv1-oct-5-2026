<?php
// admin/archived-patients.php - Archived Patient Records
// Camp Evangelista Station Hospital

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/SessionManager.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$message = '';

if (isset($_GET['restore'])) {
    $id = (int) $_GET['restore'];
    $stmt = $db->prepare("UPDATE patients SET status = 'Active' WHERE id = ? AND status = 'Archived'");
    $stmt->execute([$id]);
    $message = $stmt->rowCount() > 0
        ? 'Patient record restored to the active directory.'
        : 'Patient record was already active or not found.';
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$per_page = 10;
$where = " WHERE p.status = 'Archived'";
$params = [];

if ($search !== '') {
    $where .= " AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.mrn LIKE ? OR p.contact_number LIKE ?)";
    $search_param = "%{$search}%";
    array_push($params, $search_param, $search_param, $search_param, $search_param);
}

$count_stmt = $db->prepare("SELECT COUNT(*) FROM patients p" . $where);
$count_stmt->execute($params);
$archived_count = (int) $count_stmt->fetchColumn();
$total_pages = max(1, (int) ceil($archived_count / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;

$query = "SELECT p.*, (SELECT COUNT(*) FROM queue_entries WHERE patient_id = p.id) AS total_visits
          FROM patients p" . $where . "
          ORDER BY p.last_name ASC, p.first_name ASC
          LIMIT " . $per_page . " OFFSET " . $offset;
$stmt = $db->prepare($query);
$stmt->execute($params);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pagination_url = function ($target_page) use ($search) {
    $params = ['page' => $target_page];
    if ($search !== '') {
        $params['search'] = $search;
    }
    return 'archived-patients.php?' . http_build_query($params);
};

$current_theme = 'light';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $current_theme === 'dark' ? 'dark' : ''; ?>">
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">

<head>
    <script>
        (function () {
            if (localStorage.getItem('theme') === 'dark') {
                document.documentElement.classList.add('dark');
            }
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archived Patients | 4ID Station Hospital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { darkMode: 'class' };
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased">
    <main class="max-w-7xl mx-auto p-5 md:p-8">
        <header class="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80">
            <div>
                <div class="flex items-center gap-3 mb-2">
                    <a href="patients.php" class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 text-slate-500 hover:text-sky-500 transition-colors" title="Back to Patients Directory">
                        <i class="fas fa-arrow-left text-sm"></i>
                    </a>
                    <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">Archived Patients</h1>
                </div>
                <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Recover archived patient records when they are needed again</p>
            </div>
            <div class="flex items-center gap-3">
                <button id="themeToggleBtn" type="button" class="w-10 h-10 inline-flex items-center justify-center rounded-xl bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-sky-500 transition-colors" title="Toggle Light/Dark Mode" aria-label="Toggle Light/Dark Mode">
                    <i id="themeToggleIcon" class="fas fa-moon"></i>
                </button>
                <a href="patients.php" class="inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-sky-600 dark:bg-sky-500 text-white font-bold text-[0.65rem] uppercase tracking-wider hover:bg-sky-700 dark:hover:bg-sky-600 transition-colors">
                    <i class="fas fa-users mr-2"></i> Active Directory
                </a>
            </div>
        </header>

        <?php if ($message !== ''): ?>
            <div class="p-4 mb-6 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold">
                <i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <section class="bg-white dark:bg-[#1f2937] p-4 rounded-xl border border-slate-300 dark:border-slate-700/70 shadow-sm mb-6">
            <form method="GET" action="archived-patients.php" class="flex flex-col sm:flex-row gap-3">
                <div class="relative flex-1">
                    <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
                    <input type="text" name="search" value="<?= htmlspecialchars($search); ?>" placeholder="Search archived patients..." class="w-full pl-9 pr-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 rounded-xl focus:outline-none focus:border-sky-500 text-xs">
                </div>
                <button type="submit" class="px-5 py-2.5 rounded-xl bg-sky-50 dark:bg-sky-500/10 border border-sky-300 dark:border-sky-500/20 text-sky-600 dark:text-sky-400 font-bold text-[0.65rem] uppercase tracking-wider">Search</button>
                <?php if ($search !== ''): ?>
                    <a href="archived-patients.php" class="inline-flex items-center justify-center px-3 py-2 text-[0.65rem] uppercase font-bold tracking-wider text-rose-500">Reset</a>
                <?php endif; ?>
            </form>
        </section>

        <section class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3">
                <h2 class="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white"><i class="fas fa-archive text-amber-500 mr-2"></i> Archived Records</h2>
                <span class="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400"><?= number_format($archived_count); ?> total</span>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($patients)): ?>
                    <div class="py-12 text-center text-slate-400 dark:text-slate-500">
                        <i class="fas fa-box-open text-4xl mb-3 block opacity-50"></i>
                        <p class="text-sm font-bold uppercase tracking-wider">No archived patient records found</p>
                    </div>
                <?php else: ?>
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-300 dark:border-slate-700/80 text-slate-400 text-[0.6rem] font-bold uppercase tracking-wider">
                                <th class="py-3 px-4">MRN</th>
                                <th class="py-3 px-4">Patient Name</th>
                                <th class="py-3 px-4">Type</th>
                                <th class="py-3 px-4">Contact</th>
                                <th class="py-3 px-4 text-center">Visits</th>
                                <th class="py-3 px-4 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700/60 text-xs font-medium">
                            <?php foreach ($patients as $patient): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                                    <td class="py-3 px-4 font-mono font-bold text-sky-600 dark:text-sky-400"><?= htmlspecialchars($patient['mrn']); ?></td>
                                    <td class="py-3 px-4 font-semibold text-slate-900 dark:text-white"><?= htmlspecialchars($patient['last_name'] . ', ' . $patient['first_name'] . ' ' . ($patient['middle_name'] ?? '')); ?></td>
                                    <td class="py-3 px-4 text-slate-600 dark:text-slate-300"><?= htmlspecialchars(ucfirst($patient['patient_type'])); ?></td>
                                    <td class="py-3 px-4 text-slate-500 dark:text-slate-400"><?= htmlspecialchars($patient['contact_number'] ?: 'N/A'); ?></td>
                                    <td class="py-3 px-4 text-center font-mono font-bold text-slate-700 dark:text-slate-300"><?= number_format($patient['total_visits']); ?></td>
                                    <td class="py-3 px-4 text-center whitespace-nowrap">
                                        <a href="patient-view.php?id=<?= (int) $patient['id']; ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-sky-500 border border-slate-200 dark:border-slate-700/60 transition-colors" title="View File"><i class="fas fa-eye text-xs"></i></a>
                                        <button type="button" onclick="restorePatient(<?= (int) $patient['id']; ?>, '<?= htmlspecialchars(addslashes($patient['first_name'] . ' ' . $patient['last_name'])); ?>')" class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600 hover:text-white border border-emerald-200 dark:border-emerald-700/60 transition-colors" title="Restore"><i class="fas fa-undo text-xs"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <?php if ($archived_count > 0): ?>
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-4 border-t border-slate-200 dark:border-slate-700/60">
                    <p class="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400">Showing <?= number_format($offset + 1); ?>-<?= number_format($offset + count($patients)); ?> of <?= number_format($archived_count); ?> records</p>
                    <?php if ($total_pages > 1): ?>
                        <nav class="flex items-center gap-1" aria-label="Archived patient pagination">
                            <?php if ($page > 1): ?><a href="<?= htmlspecialchars($pagination_url($page - 1)); ?>" class="px-3 h-8 inline-flex items-center rounded-lg border border-slate-300 dark:border-slate-700 text-[0.65rem] font-bold uppercase text-slate-500 hover:text-sky-500">Previous</a><?php endif; ?>
                            <?php for ($page_number = 1; $page_number <= $total_pages; $page_number++): ?>
                                <a href="<?= htmlspecialchars($pagination_url($page_number)); ?>" class="w-8 h-8 inline-flex items-center justify-center rounded-lg text-[0.7rem] font-bold <?= $page_number === $page ? 'bg-sky-600 text-white' : 'text-slate-500 dark:text-slate-400 hover:bg-sky-50 dark:hover:bg-sky-500/10'; ?>"><?= $page_number; ?></a>
                            <?php endfor; ?>
                            <?php if ($page < $total_pages): ?><a href="<?= htmlspecialchars($pagination_url($page + 1)); ?>" class="px-3 h-8 inline-flex items-center rounded-lg border border-slate-300 dark:border-slate-700 text-[0.65rem] font-bold uppercase text-slate-500 hover:text-sky-500">Next</a><?php endif; ?>
                        </nav>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <script>
        const themeToggleBtn = document.getElementById('themeToggleBtn');
        const themeToggleIcon = document.getElementById('themeToggleIcon');
        const htmlElement = document.documentElement;

        function updateThemeIcon() {
            themeToggleIcon.className = htmlElement.classList.contains('dark') ? 'fas fa-sun text-amber-400' : 'fas fa-moon';
        }

        updateThemeIcon();
        themeToggleBtn.addEventListener('click', () => {
            htmlElement.classList.toggle('dark');
            localStorage.setItem('theme', htmlElement.classList.contains('dark') ? 'dark' : 'light');
            updateThemeIcon();
        });

        function restorePatient(id, label) {
            if (confirm(`Restore the patient record for "${label}" to the active directory?`)) {
                window.location.href = `archived-patients.php?restore=${id}`;
            }
        }
    </script>
</body>
</html>
