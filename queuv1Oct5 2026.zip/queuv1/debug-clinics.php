<?php
// debug-clinics.php - Check clinics in database

require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<h2>🔍 Clinic Database Debug</h2>";

// Check 1: Count total clinics
$query = "SELECT COUNT(*) as total FROM clinics";
$result = $db->query($query)->fetch(PDO::FETCH_ASSOC);
echo "<h3>Total Clinics in Database: " . $result['total'] . "</h3>";

// Check 2: List all clinics
$query = "SELECT id, name, is_active, capacity_per_hour FROM clinics ORDER BY id";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>All Clinics:</h3>";
if (empty($clinics)) {
    echo "<p style='color: red;'>❌ NO CLINICS FOUND IN DATABASE!</p>";
} else {
    echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Name</th><th>Active</th><th>Capacity</th></tr>";
    foreach ($clinics as $clinic) {
        $active = $clinic['is_active'] ? '✅ Yes' : '❌ No';
        echo "<tr>";
        echo "<td>" . $clinic['id'] . "</td>";
        echo "<td>" . $clinic['name'] . "</td>";
        echo "<td>" . $active . "</td>";
        echo "<td>" . $clinic['capacity_per_hour'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check 3: Check if only active clinics are showing
$query = "SELECT COUNT(*) as active FROM clinics WHERE is_active = 1";
$result = $db->query($query)->fetch(PDO::FETCH_ASSOC);
echo "<h3>Active Clinics: " . $result['active'] . "</h3>";

// Check 4: Show the exact query being used
echo "<h3>Query being used:</h3>";
echo "<pre style='background: #f4f4f4; padding: 10px; border-radius: 5px;'>";
echo "SELECT 
    c.id,
    c.name,
    c.capacity_per_hour,
    COUNT(CASE WHEN q.status IN ('waiting', 'called') AND DATE(q.registered_at) = CURDATE() THEN 1 END) as waiting_count,
    COUNT(CASE WHEN q.status = 'in-progress' AND DATE(q.registered_at) = CURDATE() THEN 1 END) as in_progress_count,
    COUNT(CASE WHEN q.status = 'completed' AND DATE(q.registered_at) = CURDATE() THEN 1 END) as completed_count
FROM clinics c
LEFT JOIN queue_entries q ON c.id = q.clinic_id
WHERE c.is_active = 1
GROUP BY c.id
ORDER BY waiting_count ASC";
echo "</pre>";

// Check 5: Run the actual query and show results
echo "<h3>Query Results:</h3>";
$query = "SELECT 
    c.id,
    c.name,
    c.capacity_per_hour,
    COUNT(CASE WHEN q.status IN ('waiting', 'called') AND DATE(q.registered_at) = CURDATE() THEN 1 END) as waiting_count,
    COUNT(CASE WHEN q.status = 'in-progress' AND DATE(q.registered_at) = CURDATE() THEN 1 END) as in_progress_count,
    COUNT(CASE WHEN q.status = 'completed' AND DATE(q.registered_at) = CURDATE() THEN 1 END) as completed_count
FROM clinics c
LEFT JOIN queue_entries q ON c.id = q.clinic_id
WHERE c.is_active = 1
GROUP BY c.id
ORDER BY waiting_count ASC";
$results = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

if (empty($results)) {
    echo "<p style='color: red;'>❌ Query returned no results!</p>";
} else {
    echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Name</th><th>Waiting</th><th>In Progress</th><th>Completed</th></tr>";
    foreach ($results as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['waiting_count'] . "</td>";
        echo "<td>" . $row['in_progress_count'] . "</td>";
        echo "<td>" . $row['completed_count'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>