<?php
require_once dirname(__DIR__) . '/config/database.php';

$clinic_id = filter_input(INPUT_GET, 'clinic_id', FILTER_VALIDATE_INT);
if (!$clinic_id) {
    http_response_code(400);
    exit('A valid clinic_id is required.');
}

$database = new Database();
$db = $database->getConnection();
$clinic_stmt = $db->prepare('SELECT id, name FROM clinics WHERE id = ?');
$clinic_stmt->execute([$clinic_id]);
$clinic = $clinic_stmt->fetch(PDO::FETCH_ASSOC);

if (!$clinic) {
    http_response_code(404);
    exit('Clinic not found.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($clinic['name']); ?> Display</title>
            <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root { --ink: #1e293b; --muted: #64748b; --panel: #ffffff; --line: #e2e8f0; --accent: #2563eb; --blue: #2563eb; --hot: #f59e0b; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; color: var(--ink); background: #f0f4f8; font-family: 'Plus Jakarta Sans', sans-serif; padding: 20px; }
        .shell { max-width: 1920px; margin: auto; padding-bottom: 70px; }
        .hospital-header { background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); border: 1px solid var(--line); border-radius: 24px; padding: 30px; position: relative; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, .05); }
        .hospital-header::before { content: ''; position: absolute; inset: 0 0 auto; height: 4px; background: linear-gradient(90deg, var(--blue), var(--accent)); }
        .header-top { display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap; }
        .hospital-title h1 { margin: 0; color: #0f172a; font-size: clamp(30px, 5vw, 52px); font-weight: 800; line-height: 1.1; }
        .hospital-title h2 { margin: 5px 0 0; color: var(--accent); font-size: clamp(18px, 2.5vw, 28px); font-weight: 500; }
        .hospital-badge { background: rgba(37, 99, 235, .1); border: 1px solid var(--accent); border-radius: 50px; padding: 12px 20px; color: var(--accent); font-weight: 700; }
        .clock { margin-left: 14px; color: #1e293b; font-family: 'JetBrains Mono', monospace; font-size: 14px; font-weight: 500; }
        .status-dot { display: inline-block; width: 8px; height: 8px; margin-left: 8px; border-radius: 50%; background: #22c55e; animation: blink 1.5s infinite; }
        .clinic-grid { display: grid; grid-template-columns: minmax(0, 1fr); margin-top: 30px; }
        .clinic-display-card { background: var(--panel); border: 1px solid var(--line); border-radius: 20px; overflow: hidden; box-shadow: 0 2px 8px rgba(0, 0, 0, .02); }
        .clinic-header { background: #f8fafc; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; gap: 15px; border-bottom: 1px solid var(--line); }
        .clinic-name { color: #0f172a; font-size: clamp(18px, 3vw, 28px); font-weight: 700; text-transform: uppercase; }
        .clinic-batch { background: var(--blue); color: #fff; border-radius: 20px; padding: 7px 14px; font-size: 13px; font-weight: 700; }
        .clinic-body { display: grid; grid-template-columns: minmax(0, 1.4fr) minmax(280px, .6fr); gap: 24px; padding: 24px; }
        .current-patient { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 15px; padding: 24px; min-height: 280px; }
        .current-label, .next-label { color: var(--muted); font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; }
        .current-label i, .next-label i { color: var(--accent); margin-right: 5px; }
        .current-number { color: var(--accent); font-family: 'JetBrains Mono', monospace; font-size: clamp(80px, 16vw, 210px); font-weight: 800; line-height: 1; margin: 35px 0 12px; }
        .current-name { color: var(--ink); font-size: clamp(16px, 2vw, 24px); font-weight: 500; }
        .next-patients { padding: 10px 0; }
        .next-label { margin-bottom: 15px; display: block; }
        .queue-list { list-style: none; margin: 0; padding: 0; }
        .queue-item { display: flex; align-items: center; gap: 12px; padding: 13px 0; border-bottom: 1px solid #f1f5f9; color: #0f172a; font-family: 'JetBrains Mono', monospace; font-size: 21px; font-weight: 700; }
        .position { width: 28px; height: 28px; display: grid; place-items: center; border-radius: 8px; background: #f1f5f9; color: var(--muted); font-family: 'Plus Jakarta Sans', sans-serif; font-size: 13px; }
        .empty { padding: 35px 0; color: #64748b; font-size: 14px; font-style: italic; }
        .audio { margin-top: 22px; background: transparent; border: 1px solid var(--accent); border-radius: 8px; color: var(--accent); cursor: pointer; font: inherit; font-weight: 700; padding: 11px 15px; }
        .audio.enabled { background: var(--accent); color: #ffffff; }
        .clinic-footer { background: #f8fafc; }
        .clinic-footer { background: rgba(255, 255, 255, .02); padding: 16px 24px; border-top: 1px solid var(--line); color: var(--muted); font-size: 13px; text-align: right; }
        footer { margin-top: 22px; color: var(--muted); font-size: 12px; text-align: center; }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: .4; } }
        @media (max-width: 760px) { body { padding: 12px; } .hospital-header { padding: 22px; } .clinic-body { grid-template-columns: 1fr; } .current-patient { min-height: 240px; } .current-number { font-size: 27vw; } .clinic-header { align-items: start; flex-direction: column; } }
    </style>
</head>
<body>
    <main class="shell">
        <div class="hospital-header">
            <div class="header-top">
                <div class="hospital-title">
                    <h1>CAMP EVANGELISTA</h1>
                    <h2>STATION HOSPITAL</h2>
                </div>
                <div class="hospital-badge"><i class="fas fa-shield-alt"></i> 4ID.P.A <span class="status-dot"></span><span class="clock" id="clock"></span></div>
            </div>
        </div>

        <div class="clinic-grid" aria-live="polite">
            <div class="clinic-display-card">
                <div class="clinic-header">
                    <span class="clinic-name"><i class="fas fa-clinic-medical"></i> <?php echo htmlspecialchars($clinic['name']); ?></span>
                    <span class="clinic-batch"><i class="fas fa-broadcast-tower"></i> LIVE DISPLAY</span>
                </div>
                <div class="clinic-body">
                    <div class="current-patient">
                        <div class="current-label" id="currentLabel"><i class="fas fa-bell"></i> Up next</div>
                        <div class="current-number" id="currentNumber">---</div>
                        <div class="current-name" id="currentName">Waiting for next patient</div>
                    </div>
                    <div class="next-patients">
                        <div class="next-label"><i class="fas fa-arrow-right"></i> Next 5 patients</div>
                        <div class="queue-list" id="queueList"><div class="empty"><i class="fas fa-inbox"></i> No patients in queue</div></div>
                        <button class="audio" id="audioButton" type="button"><i class="fas fa-volume-up"></i> Enable announcements</button>
                    </div>
                </div>
                <div class="clinic-footer"><i class="fas fa-users"></i> <span id="waitingCount">0</span> patients waiting</div>
            </div>
        </div>
        <footer><i class="fas fa-sync-alt"></i> Live queue display · Updates automatically</footer>
    </main>
    <script>
        const clinicId = <?php echo (int) $clinic_id; ?>;
        const clinicName = <?php echo json_encode($clinic['name']); ?>;
        let lastAnnouncementTime = '<?php echo date('Y-m-d H:i:s', strtotime('-1 minute')); ?>';
        let audioEnabled = false;
        const speechSupported = 'speechSynthesis' in window;
        let speechQueue = [];
        let isSpeaking = false;
        let isRefreshing = false;
        const number = document.getElementById('currentNumber');
        const name = document.getElementById('currentName');
        const label = document.getElementById('currentLabel');
        const waitingCount = document.getElementById('waitingCount');
        const queueList = document.getElementById('queueList');
        const audioButton = document.getElementById('audioButton');

        function speak(text) {
            if (!('speechSynthesis' in window)) return;
            speechQueue.push(text);
            speakNext();
        }

        function speakNext() {
            if (!audioEnabled || isSpeaking || !speechQueue.length || !('speechSynthesis' in window)) return;
            isSpeaking = true;
            const utterance = new SpeechSynthesisUtterance(speechQueue.shift());
            utterance.lang = 'en-US';
            utterance.rate = 0.88;
            utterance.onend = finishSpeech;
            utterance.onerror = finishSpeech;
            window.speechSynthesis.speak(utterance);
        }

        function finishSpeech() {
            isSpeaking = false;
            speakNext();
        }

        function initializeSpeech() {
            if (!('speechSynthesis' in window)) return;
            window.speechSynthesis.getVoices();
        }

        function enableAudio() {
            if (!speechSupported) return;
            audioEnabled = true;
            audioButton.innerHTML = '<i class="fas fa-volume-up"></i> Announcements enabled';
            audioButton.classList.add('enabled');
            window.speechSynthesis.resume();
            speak('Clinic announcements are enabled.');
        }

        function disableAudio() {
            audioEnabled = false;
            audioButton.innerHTML = '<i class="fas fa-volume-up"></i> Enable announcements';
            audioButton.classList.remove('enabled');
            speechQueue = [];
            if (speechSupported) window.speechSynthesis.cancel();
            isSpeaking = false;
        }

        initializeSpeech();
        setTimeout(initializeSpeech, 500);
        setTimeout(initializeSpeech, 1500);
        if (!speechSupported) {
            audioButton.disabled = true;
            audioButton.textContent = 'Voice announcements unavailable in this browser';
        }
        audioButton.addEventListener('click', () => audioEnabled ? disableAudio() : enableAudio());

        function render(data) {
            waitingCount.textContent = data.waiting_count;
            if (data.current) {
                number.textContent = data.current.queue_number;
                const isServing = data.current.status === 'in-progress';
                label.innerHTML = '<i class="fas fa-' + (isServing ? 'bell' : 'arrow-right') + '"></i> ' + (isServing ? 'Now serving' : 'Up next');
                name.textContent = isServing ? 'Patient currently being served' : 'Please proceed when called';
            } else {
                number.textContent = '--';
                label.innerHTML = '<i class="fas fa-bell"></i> Up next';
                name.textContent = 'Please wait for your number.';
            }
            if (!data.waiting.length) {
                queueList.innerHTML = '<div class="empty">No patients waiting</div>';
                return;
            }
            queueList.innerHTML = data.waiting.map((patient, index) =>
                '<div class="queue-item"><span>' + patient.queue_number + '</span><span class="position">' + (patient.status === 'called' ? 'UP NEXT' : 'NEXT ' + (index + 1)) + '</span></div>'
            ).join('');
        }

        async function refresh() {
            if (isRefreshing) return;
            isRefreshing = true;
            try {
                const response = await fetch('../api/clinic-display.php?clinic_id=' + clinicId + '&since=' + encodeURIComponent(lastAnnouncementTime), { cache: 'no-store' });
                const data = await response.json();
                if (!data.success) return;
                render(data);
                data.announcements.forEach((announcement) => {
                    speak('Attention please. Patient number ' + announcement.queue_number + ', please proceed to ' + clinicName + '.');
                });
                if (data.announcements.length) {
                    lastAnnouncementTime = data.announcements[data.announcements.length - 1].called_at;
                }
            } catch (error) {
                console.error('Clinic display update failed:', error);
            } finally {
                isRefreshing = false;
            }
        }

        function updateClock() { document.getElementById('clock').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
        updateClock();
        refresh();
        setInterval(refresh, 4000);
        setInterval(updateClock, 1000);
    </script>
</body>
</html>
