<?php
// test-registration-email-direct.php - Test registration email directly

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>📧 Direct Registration Email Test</h2>";

// Load SimpleEmailSender
require_once 'includes/SimpleEmailSender.php';

// ============================================
// TEST DATA
// ============================================
$to = 'mark.adrian.lumongsod@gmail.com'; // CHANGE THIS
$patient_name = 'Test Patient';
$queue_number = 'M-09-001';
$transaction_token = 'TXN-TEST-12345';
$clinic_name = 'ALL Clinics (Least Congested Order)';

echo "<p><strong>Sending to:</strong> " . $to . "</p>";
echo "<p><strong>Patient:</strong> " . $patient_name . "</p>";
echo "<p><strong>Queue:</strong> " . $queue_number . "</p>";
echo "<p><strong>Token:</strong> " . $transaction_token . "</p>";
echo "<p><strong>Clinic:</strong> " . $clinic_name . "</p>";

echo "<h3>Sending...</h3>";

$emailSender = new SimpleEmailSender();
$result = $emailSender->sendNotification($to, $patient_name, $queue_number, $transaction_token, $clinic_name);

if ($result) {
    echo "✅ <strong style='color: green;'>Email sent successfully!</strong>";
    echo "<br><br>📬 Check your email: " . $to;
} else {
    echo "❌ <strong style='color: red;'>Failed to send email.</strong>";
}
?>